# Worm King — preparação para Google Play

O projeto já está preparado para ser empacotado como aplicativo Android com Capacitor.

## Identidade Android
- Nome: Worm King
- Package ID: `com.wormking.game`
- Versão inicial: `1.0.0`
- Web output: `dist`

## No computador com Node.js instalado

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio:
1. Abra o projeto `android/`.
2. Configure o `applicationId` como `com.wormking.game` se necessário.
3. Configure uma chave de assinatura própria para a versão de produção.
4. Gere um **Android App Bundle (.aab)** em `Build > Generate Signed Bundle / APK > Android App Bundle`.
5. Teste o AAB/APK em um aparelho Android antes de publicar.

## Google Play Console

Na Play Console, crie o app e envie o `.aab`. Você também precisará preencher os dados da loja, classificação indicativa, segurança de dados, política de privacidade e demais declarações exigidas pela Google.

> Importante: não compartilhe a chave de assinatura. Faça backup dela em local seguro.

## API/Gemini

O projeto contém referência a `GEMINI_API_KEY`. Nunca coloque uma chave secreta diretamente no aplicativo Android. Qualquer segredo incluído no frontend pode ser extraído do APK/AAB. Se a funcionalidade Gemini for usada em produção, coloque a chamada protegida em um backend.

## Mobile polish included
- Android system Back button returns from gameplay/game-over to the main menu.
- Safe-area support for phones with camera cutouts/navigation bars.
- Touch-first CSS behavior to prevent accidental browser zoom/scroll.
- Compact controls for narrow portrait screens.
- Play Store icon source: `assets/worm-king-icon-512.png` (import it with Android Studio > Image Asset).
