import { Worm, Orb, PowerUp, BattleRoyaleZone } from '../types';
import { MAP_SIZE, ROTATION_SPEED } from './constants';

export function updateBotAI(
  bot: Worm,
  allWorms: Worm[],
  orbs: Orb[],
  powerUps: PowerUp[],
  brZone: BattleRoyaleZone | null,
  isBattleRoyale: boolean
): void {
  if (bot.isDead) return;

  const botHead = { x: bot.x, y: bot.y };
  const currentAngle = bot.angle;
  let targetAngle = currentAngle;
  let shouldBoost = false;

  // 1. DANGER CHECK: Boundary check
  const margin = 200;
  if (bot.x < margin) {
    targetAngle = 0; // turn right
  } else if (bot.x > MAP_SIZE - margin) {
    targetAngle = Math.PI; // turn left
  } else if (bot.y < margin) {
    targetAngle = Math.PI / 2; // turn down
  } else if (bot.y > MAP_SIZE - margin) {
    targetAngle = -Math.PI / 2; // turn up
  }

  // 1.1 Battle Royale Zone Avoidance
  if (isBattleRoyale && brZone) {
    const distToCenter = Math.hypot(bot.x - brZone.centerX, bot.y - brZone.centerY);
    if (distToCenter > brZone.radius - 250) {
      // Steer back into circle!
      targetAngle = Math.atan2(brZone.centerY - bot.y, brZone.centerX - bot.x);
      shouldBoost = distToCenter > brZone.radius - 100;
    }
  }

  // 2. IMMEDIATE COLLISION AVOIDANCE (highest priority)
  // Check raycasts / lookahead in front of head
  const lookaheadDist = bot.isBoosting ? 160 : 100;
  const aheadX = bot.x + Math.cos(bot.angle) * lookaheadDist;
  const aheadY = bot.y + Math.sin(bot.angle) * lookaheadDist;

  let nearestObstacleDist = Infinity;
  let avoidAngle = 0;
  let obstacleDetected = false;

  for (const other of allWorms) {
    if (other.isDead || other.id === bot.id) continue;

    // Check against other worm segments
    // sample segments for performance
    const step = Math.max(1, Math.floor(other.segments.length / 40));
    for (let i = 0; i < other.segments.length; i += step) {
      const seg = other.segments[i];
      const dist = Math.hypot(aheadX - seg.x, aheadY - seg.y);
      const safeRadius = seg.radius + 35;

      if (dist < safeRadius && dist < nearestObstacleDist) {
        nearestObstacleDist = dist;
        obstacleDetected = true;

        // Determine if turning left or right is clearer
        const angleToSeg = Math.atan2(seg.y - bot.y, seg.x - bot.x);
        let diff = angleToSeg - bot.angle;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;

        // Turn sharply away from obstacle
        avoidAngle = diff > 0 ? bot.angle - Math.PI * 0.6 : bot.angle + Math.PI * 0.6;
      }
    }
  }

  if (obstacleDetected) {
    targetAngle = avoidAngle;
    bot.targetAngle = targetAngle;
    bot.isBoosting = false; // slow down to turn sharper
    return;
  }

  // 3. OFFENSIVE / HEADSHOT TACTIC
  // If we have an aggressive personality and see a player or smaller worm
  const aggro = bot.aiAggressiveness || 0.5;
  let targetPrey: Worm | null = null;
  let minPreyDist = 450;

  for (const other of allWorms) {
    if (other.isDead || other.id === bot.id) continue;

    const d = Math.hypot(other.x - bot.x, other.y - bot.y);
    if (d < minPreyDist) {
      // Prioritize player or worms smaller than us
      if (other.isPlayer || other.mass <= bot.mass * 1.3) {
        minPreyDist = d;
        targetPrey = other;
      }
    }
  }

  if (targetPrey && Math.random() < aggro) {
    const cx = MAP_SIZE / 2;
    const cy = MAP_SIZE / 2;
    const botDistToCenter = Math.hypot(bot.x - cx, bot.y - cy);
    const preyDistToCenter = Math.hypot(targetPrey.x - cx, targetPrey.y - cy);

    // Se o bot estiver mais perto do centro que o alvo, uma cabeçada frontal matará o bot!
    // Ele então manobra para cortar pela lateral e não bater de frente.
    if (botDistToCenter < preyDistToCenter && minPreyDist < 160) {
      targetAngle = targetPrey.angle + Math.PI * 0.5;
      shouldBoost = false;
    } else {
      // Attempt HEADSHOT or Advantageous Head Clash
      const interceptDist = 75;
      const preyFutureX = targetPrey.x + Math.cos(targetPrey.angle) * interceptDist;
      const preyFutureY = targetPrey.y + Math.sin(targetPrey.angle) * interceptDist;

      targetAngle = Math.atan2(preyFutureY - bot.y, preyFutureX - bot.x);
      
      // Boost if close and cutting in front
      if (minPreyDist < 260 && bot.mass > 60) {
        shouldBoost = true;
      }
    }
  } else {
    // 4. POWER-UP SEEKING
    let nearestPowerUp: PowerUp | null = null;
    let minPowerDist = 500;

    for (const p of powerUps) {
      const d = Math.hypot(p.x - bot.x, p.y - bot.y);
      if (d < minPowerDist) {
        minPowerDist = d;
        nearestPowerUp = p;
      }
    }

    if (nearestPowerUp) {
      targetAngle = Math.atan2(nearestPowerUp.y - bot.y, nearestPowerUp.x - bot.x);
    } else {
      // 5. FOOD / CLUSTER SEEKING
      let bestOrb: Orb | null = null;
      let highestValue = 0;
      const minOrbDist = 380;
      const minOrbDistSq = minOrbDist * minOrbDist;

      // Sample orbs near bot with fast bounding box rejection
      for (let i = 0; i < orbs.length; i += 5) {
        const orb = orbs[i];
        if (!orb) continue;

        const dx = orb.x - bot.x;
        if (dx > minOrbDist || dx < -minOrbDist) continue;
        const dy = orb.y - bot.y;
        if (dy > minOrbDist || dy < -minOrbDist) continue;

        const dSq = dx * dx + dy * dy;
        if (dSq < minOrbDistSq) {
          const d = Math.sqrt(dSq);
          const score = (orb.value * 200) / (d + 20);
          if (score > highestValue) {
            highestValue = score;
            bestOrb = orb;
          }
        }
      }

      if (bestOrb) {
        targetAngle = Math.atan2(bestOrb.y - bot.y, bestOrb.x - bot.x);
        // Boost if large death food pile
        const bdx = bestOrb.x - bot.x;
        const bdy = bestOrb.y - bot.y;
        if (bestOrb.value > 5 && (bdx * bdx + bdy * bdy) < 220 * 220) {
          shouldBoost = bot.mass > 80;
        }
      } else {
        // Wander slightly
        if (!bot.aiTurnTimer || bot.aiTurnTimer <= 0) {
          bot.aiTurnTimer = 60 + Math.random() * 100;
          targetAngle = bot.angle + (Math.random() - 0.5) * 1.5;
        } else {
          bot.aiTurnTimer--;
          targetAngle = bot.targetAngle;
        }
      }
    }
  }

  // Smooth turn towards target angle
  let angleDiff = targetAngle - bot.angle;
  while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
  while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;

  const turnRate = ROTATION_SPEED * (bot.isBoosting ? 1.25 : 1.0);
  bot.angle += Math.sign(angleDiff) * Math.min(Math.abs(angleDiff), turnRate);
  bot.targetAngle = targetAngle;
  bot.isBoosting = shouldBoost && bot.mass > 40;
}
