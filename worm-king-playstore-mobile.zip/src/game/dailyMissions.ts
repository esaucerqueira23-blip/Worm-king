export interface DailyMission {
  id: string;
  titlePt: string;
  titleEn: string;
  descPt: string;
  descEn: string;
  icon: 'Clock' | 'Crosshair' | 'Target' | 'Sparkles' | 'Gamepad2' | 'Flame';
  type: 'survive_time' | 'kills' | 'headshots' | 'orbs' | 'matches';
  target: number;
  current: number;
  rewardCoins: number;
  completed: boolean;
  claimed: boolean;
  isSingleMatch?: boolean; // e.g. survive 2 min in a single run
}

export interface DailyMissionsData {
  dateString: string; // YYYY-MM-DD
  missions: DailyMission[];
  lastUpdated: number;
}

const STORAGE_KEY = 'wormking_daily_missions_v1';

export const DEFAULT_DAILY_MISSIONS: Omit<DailyMission, 'current' | 'completed' | 'claimed'>[] = [
  {
    id: 'survive_2m',
    titlePt: 'Sobreviva por 2 minutos',
    titleEn: 'Survive for 2 minutes',
    descPt: 'Fique vivo por pelo menos 120 segundos contínuos em uma partida.',
    descEn: 'Stay alive for at least 120 continuous seconds in a single run.',
    icon: 'Clock',
    type: 'survive_time',
    target: 120, // 120 seconds
    rewardCoins: 250,
    isSingleMatch: true,
  },
  {
    id: 'kills_10',
    titlePt: 'Alcance 10 kills',
    titleEn: 'Reach 10 kills',
    descPt: 'Elimine 10 minhocas adversárias na arena hoje.',
    descEn: 'Eliminate 10 rival worms in the arena today.',
    icon: 'Crosshair',
    type: 'kills',
    target: 10,
    rewardCoins: 300,
  },
  {
    id: 'headshots_3',
    titlePt: 'Acerte 3 Headshots na Cabeça',
    titleEn: 'Score 3 Headshots',
    descPt: 'Elimine 3 adversários em colisão direta cabeça-com-cabeça.',
    descEn: 'Eliminate 3 opponents in direct head-to-head collisions.',
    icon: 'Target',
    type: 'headshots',
    target: 3,
    rewardCoins: 350,
  },
  {
    id: 'eat_orbs_300',
    titlePt: 'Devore 300 orbes de massa',
    titleEn: 'Devour 300 mass orbs',
    descPt: 'Colete 300 orbes de energia brilhante na arena.',
    descEn: 'Collect 300 glowing energy orbs in the arena.',
    icon: 'Sparkles',
    type: 'orbs',
    target: 300,
    rewardCoins: 200,
  },
  {
    id: 'play_3_matches',
    titlePt: 'Dispute 3 batalhas',
    titleEn: 'Play 3 battles',
    descPt: 'Entre e compita em 3 partidas em qualquer modo.',
    descEn: 'Join and compete in 3 matches across any mode.',
    icon: 'Gamepad2',
    type: 'matches',
    target: 3,
    rewardCoins: 200,
  },
];

function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function loadDailyMissions(): DailyMissionsData {
  const today = getTodayDateString();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data: DailyMissionsData = JSON.parse(raw);
      if (data && data.dateString === today && Array.isArray(data.missions) && data.missions.length > 0) {
        return data;
      }
    }
  } catch (err) {
    console.warn('Failed to load daily missions:', err);
  }

  // Generate new missions for today
  const freshMissions: DailyMission[] = DEFAULT_DAILY_MISSIONS.map((template) => ({
    ...template,
    current: 0,
    completed: false,
    claimed: false,
  }));

  const freshData: DailyMissionsData = {
    dateString: today,
    missions: freshMissions,
    lastUpdated: Date.now(),
  };

  saveDailyMissions(freshData);
  return freshData;
}

export function saveDailyMissions(data: DailyMissionsData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.warn('Failed to save daily missions:', err);
  }
}

/**
 * Updates daily missions progress.
 * Returns any missions that were just completed during this call.
 */
export function recordMissionProgress(
  type: DailyMission['type'],
  value: number,
  isAbsoluteValue = false
): { updatedMissions: DailyMission[]; newlyCompleted: DailyMission[] } {
  const data = loadDailyMissions();
  const newlyCompleted: DailyMission[] = [];
  let hasChanges = false;

  data.missions = data.missions.map((m) => {
    if (m.type !== type || m.completed) return m;

    let newCurrent = m.current;
    if (isAbsoluteValue) {
      newCurrent = Math.max(m.current, Math.floor(value));
    } else {
      newCurrent = m.current + Math.floor(value);
    }

    newCurrent = Math.min(newCurrent, m.target);

    if (newCurrent !== m.current) {
      hasChanges = true;
      const isNowCompleted = newCurrent >= m.target;
      if (isNowCompleted && !m.completed) {
        newlyCompleted.push({ ...m, current: newCurrent, completed: true });
      }
      return {
        ...m,
        current: newCurrent,
        completed: isNowCompleted,
      };
    }
    return m;
  });

  if (hasChanges) {
    data.lastUpdated = Date.now();
    saveDailyMissions(data);
  }

  return { updatedMissions: data.missions, newlyCompleted };
}

/**
 * Claims a specific completed mission's coins.
 * Returns the amount of coins rewarded.
 */
export function claimMissionReward(missionId: string): number {
  const data = loadDailyMissions();
  let reward = 0;

  data.missions = data.missions.map((m) => {
    if (m.id === missionId && m.completed && !m.claimed) {
      reward = m.rewardCoins;
      return { ...m, claimed: true };
    }
    return m;
  });

  if (reward > 0) {
    data.lastUpdated = Date.now();
    saveDailyMissions(data);
  }

  return reward;
}

/**
 * Claims all completed and unclaimed missions.
 * Returns total coins earned.
 */
export function claimAllMissionRewards(): number {
  const data = loadDailyMissions();
  let totalReward = 0;

  data.missions = data.missions.map((m) => {
    if (m.completed && !m.claimed) {
      totalReward += m.rewardCoins;
      return { ...m, claimed: true };
    }
    return m;
  });

  if (totalReward > 0) {
    data.lastUpdated = Date.now();
    saveDailyMissions(data);
  }

  return totalReward;
}

/**
 * Returns formatted time until next daily reset at 00:00 local time
 */
export function getTimeUntilDailyReset(): {
  hours: number;
  minutes: number;
  seconds: number;
  formatted: string;
} {
  const now = new Date();
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
  const diffMs = Math.max(0, tomorrow.getTime() - now.getTime());

  const totalSeconds = Math.floor(diffMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const formatted = `${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;

  return { hours, minutes, seconds, formatted };
}
