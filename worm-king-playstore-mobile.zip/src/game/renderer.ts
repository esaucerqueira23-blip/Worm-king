import {
  Worm,
  WormSkin,
  Orb,
  PowerUp,
  Particle,
  FloatingText,
  Projectile,
  BattleRoyaleZone,
  GameMode,
} from '../types';
import { MAP_SIZE } from './constants';

export class GameRenderer {
  private ctx: CanvasRenderingContext2D;
  private width: number = 0;
  private height: number = 0;
  private cameraX: number = 0;
  private cameraY: number = 0;
  private cameraZoom: number = 1.0;
  private animTime: number = 0;
  private cartoonGridPattern: CanvasPattern | null = null;
  private skinImageCache: Map<string, HTMLImageElement> = new Map();

  private getSkinImage(url?: string): HTMLImageElement | null {
    if (!url) return null;
    let img = this.skinImageCache.get(url);
    if (!img) {
      img = new Image();
      img.src = url;
      this.skinImageCache.set(url, img);
    }
    return img.complete && img.naturalWidth > 0 ? img : null;
  }

  private drawFittedImage(
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    cx: number,
    cy: number,
    radius: number,
    skin: WormSkin
  ) {
    const iw = img.naturalWidth || 100;
    const ih = img.naturalHeight || 100;
    const fit = skin.customImageFit || 'cover';
    const scale = Math.max(0.3, Math.min(3.0, skin.customImageScale || 1.0));
    const rotation = (((skin.customImageRotation || 0) % 360) * Math.PI) / 180;
    const offsetX = (skin.customImageOffsetX || 0) * radius;
    const offsetY = (skin.customImageOffsetY || 0) * radius;

    ctx.save();
    ctx.translate(cx + offsetX, cy + offsetY);
    if (rotation !== 0) {
      ctx.rotate(rotation);
    }

    if (fit === 'contain') {
      const maxDim = Math.max(iw, ih);
      const dw = (iw / maxDim) * radius * 2.2 * scale;
      const dh = (ih / maxDim) * radius * 2.2 * scale;
      ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
    } else {
      // Cover (aspect-ratio preserving crop)
      // Preserves 1:1 circle proportions for both vertical phone photos (9:16 / 3:4) and horizontal PC images (16:9 / 4:3)
      const minDim = Math.min(iw, ih) / scale;
      const sx = Math.max(0, Math.min(iw - minDim, (iw - minDim) / 2));
      const sy = Math.max(0, Math.min(ih - minDim, (ih - minDim) / 2));
      const targetSize = radius * 2.25;
      ctx.drawImage(
        img,
        sx,
        sy,
        minDim,
        minDim,
        -targetSize / 2,
        -targetSize / 2,
        targetSize,
        targetSize
      );
    }
    ctx.restore();
  }

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
    this.initCartoonPattern();
  }

  // Cheerful 2D Honeycomb Cartoon Arena Floor Pattern (Wormate.io style)
  private initCartoonPattern() {
    try {
      const pCanvas = document.createElement('canvas');
      const w = 120;
      const h = 104; // 60 * sqrt(3) ~ 103.92
      pCanvas.width = w;
      pCanvas.height = h;
      const pCtx = pCanvas.getContext('2d');
      if (!pCtx) return;

      // Rich dark chocolate arena floor base
      pCtx.fillStyle = '#130e0a';
      pCtx.fillRect(0, 0, w, h);

      // Helper to draw hexagon
      const drawHex = (hx: number, hy: number, r: number) => {
        pCtx.beginPath();
        for (let a = 0; a < 6; a++) {
          const angle = (Math.PI / 3) * a + Math.PI / 6;
          const x = hx + Math.cos(angle) * r;
          const y = hy + Math.sin(angle) * r;
          if (a === 0) pCtx.moveTo(x, y);
          else pCtx.lineTo(x, y);
        }
        pCtx.closePath();
      };

      const centers = [
        [0, 0], [w, 0], [0, h], [w, h],
        [w / 2, h / 2],
        [w / 2, 0], [w / 2, h],
        [0, h / 2], [w, h / 2],
      ];

      // Hexagon fills with warm chocolate tile
      pCtx.fillStyle = '#18120d';
      for (const [cx, cy] of centers) {
        drawHex(cx, cy, 32);
        pCtx.fill();
      }

      // Honeycomb outline borders
      pCtx.strokeStyle = 'rgba(245, 158, 11, 0.12)';
      pCtx.lineWidth = 1.6;
      for (const [cx, cy] of centers) {
        drawHex(cx, cy, 32);
        pCtx.stroke();
      }

      // Glowing honey crumbs at hexagon vertices
      pCtx.fillStyle = 'rgba(251, 191, 36, 0.22)';
      for (const [cx, cy] of centers) {
        for (let a = 0; a < 6; a++) {
          const angle = (Math.PI / 3) * a + Math.PI / 6;
          const vx = cx + Math.cos(angle) * 32;
          const vy = cy + Math.sin(angle) * 32;
          pCtx.beginPath();
          pCtx.arc(vx, vy, 2.2, 0, Math.PI * 2);
          pCtx.fill();
        }
      }

      this.cartoonGridPattern = this.ctx.createPattern(pCanvas, 'repeat');
    } catch {
      this.cartoonGridPattern = null;
    }
  }

  public setDimensions(width: number, height: number) {
    this.width = width;
    this.height = height;
  }

  public updateCamera(targetX: number, targetY: number, targetMass: number, speedMultiplier: number = 1) {
    // Highly responsive camera tracking with zero visual lag
    const cameraLerp = speedMultiplier >= 5 ? 0.28 : 0.22;
    this.cameraX += (targetX - this.cameraX) * cameraLerp;
    this.cameraY += (targetY - this.cameraY) * cameraLerp;

    // Smooth dynamic zoom out as worm grows and when boosting at high speed tiers (x5, x10)
    const speedZoomFactor = speedMultiplier >= 10 ? 0.78 : speedMultiplier >= 5 ? 0.88 : 1.0;
    const baseZoom = Math.max(0.48, Math.min(1.05, 1.0 - Math.log10(Math.max(1, targetMass / 100)) * 0.28));
    const desiredZoom = baseZoom * speedZoomFactor;
    this.cameraZoom += (desiredZoom - this.cameraZoom) * 0.08;
  }

  public render(
    player: Worm | null,
    worms: Worm[],
    orbs: Orb[],
    powerUps: PowerUp[],
    projectiles: Projectile[],
    particles: Particle[],
    floatingTexts: FloatingText[],
    brZone: BattleRoyaleZone | null,
    gameMode: GameMode,
    screenShake: number
  ) {
    const ctx = this.ctx;
    const w = this.width;
    const h = this.height;

    // Clear background with rich 2D cartoon canvas base
    ctx.fillStyle = '#0e1422';
    ctx.fillRect(0, 0, w, h);

    this.animTime += 0.035;

    ctx.save();

    // Apply Screen Shake if headshot or big collision occurred
    if (screenShake > 0) {
      const shakeX = (Math.random() - 0.5) * screenShake * 18;
      const shakeY = (Math.random() - 0.5) * screenShake * 18;
      ctx.translate(shakeX, shakeY);
    }

    // Camera transform
    ctx.translate(w / 2, h / 2);
    ctx.scale(this.cameraZoom, this.cameraZoom);
    ctx.translate(-this.cameraX, -this.cameraY);

    // Viewport bounds in world coords for culling
    const halfW = (w / 2) / this.cameraZoom + 100;
    const halfH = (h / 2) / this.cameraZoom + 100;
    const minX = this.cameraX - halfW;
    const maxX = this.cameraX + halfW;
    const minY = this.cameraY - halfH;
    const maxY = this.cameraY + halfH;

    // 1. Draw 2D Cartoon Grid Background
    this.drawGrid(minX, maxX, minY, maxY);

    // 2. Draw 2D Cartoon Arena Boundaries
    this.drawMapBoundary();

    // 2.5 Draw Center Headshot Arena Zone (Alvo Cartunado)
    this.drawCenterHeadshotZone(minX, maxX, minY, maxY);

    // 3. Draw Battle Royale Zone if active
    if (gameMode === 'battle_royale' && brZone) {
      this.drawBattleRoyaleZone(brZone);
    }

    // 4. Draw Food Orbs (Comidinhas)
    this.drawOrbs(orbs, minX, maxX, minY, maxY);

    // 5. Draw Power-Ups (Badges Cartunados)
    this.drawPowerUps(powerUps, minX, maxX, minY, maxY);

    // 6. Draw Projectiles (Bolas de Energia Cartunadas)
    this.drawProjectiles(projectiles);

    // 7. Draw Worms (Dead/dying first, then bots, then player on top)
    const sortedWorms = [...worms].sort((a, b) => {
      if (a.isPlayer) return 1;
      if (b.isPlayer) return -1;
      return a.mass - b.mass;
    });

    for (const worm of sortedWorms) {
      // Cull worms far away
      if (
        worm.x + 300 < minX ||
        worm.x - 300 > maxX ||
        worm.y + 300 < minY ||
        worm.y - 300 > maxY
      ) {
        continue;
      }
      this.drawWorm(worm);
    }

    // 7.5 Draw Player Tactical Headshot Trajectory Guide (Targeting center)
    if (player && !player.isDead) {
      this.drawPlayerHeadshotGuide(player, worms);
    }

    // 8. Draw Particles (Nuvens de fumaça, estrelas de ação e brilhos)
    this.drawParticles(particles);

    // 9. Draw Floating Combat Text (Balões estilo Gibi: HEADSHOT, KILLS, etc.)
    this.drawFloatingTexts(floatingTexts);

    ctx.restore();
  }

  // Draw 2D Cartoon Playground Grid
  private drawGrid(minX: number, maxX: number, minY: number, maxY: number) {
    const ctx = this.ctx;

    if (this.cartoonGridPattern) {
      ctx.save();
      ctx.fillStyle = this.cartoonGridPattern;
      const gx = Math.max(0, minX);
      const gy = Math.max(0, minY);
      const gw = Math.min(MAP_SIZE, maxX) - gx;
      const gh = Math.min(MAP_SIZE, maxY) - gy;
      ctx.fillRect(gx, gy, gw, gh);
      ctx.restore();
    } else {
      const gridSize = 140;
      const startX = Math.floor(Math.max(0, minX) / gridSize) * gridSize;
      const endX = Math.min(MAP_SIZE, Math.ceil(maxX / gridSize) * gridSize);
      const startY = Math.floor(Math.max(0, minY) / gridSize) * gridSize;
      const endY = Math.min(MAP_SIZE, Math.ceil(maxY / gridSize) * gridSize);

      ctx.lineWidth = 1.5;
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
      ctx.beginPath();
      for (let x = startX; x <= endX; x += gridSize) {
        ctx.moveTo(x, Math.max(0, minY));
        ctx.lineTo(x, Math.min(MAP_SIZE, maxY));
      }
      for (let y = startY; y <= endY; y += gridSize) {
        ctx.moveTo(Math.max(0, minX), y);
        ctx.lineTo(Math.min(MAP_SIZE, maxX), y);
      }
      ctx.stroke();
    }
  }

  // Draw 2D Cartoon Arena Outer Boundary Walls (Chunky Comic Barrier)
  private drawMapBoundary() {
    const ctx = this.ctx;
    ctx.save();

    // 1. Chunky Outer Comic Ink Outline
    ctx.strokeStyle = '#090d16';
    ctx.lineWidth = 18;
    ctx.strokeRect(0, 0, MAP_SIZE, MAP_SIZE);

    // 2. Playful Cartoon Hazard Stripes along the perimeter (Vibrant Yellow #facc15 & Deep Ink #0f172a)
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 10;
    ctx.strokeRect(4, 4, MAP_SIZE - 8, MAP_SIZE - 8);

    // Inner comic guard rail
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 3.5;
    ctx.strokeRect(10, 10, MAP_SIZE - 20, MAP_SIZE - 20);

    // 3. Four Cartoon Corner Bumper Posts with Specular Comic Glints
    const cornerRadius = 38;
    const corners: [number, number][] = [
      [0, 0],
      [MAP_SIZE, 0],
      [MAP_SIZE, MAP_SIZE],
      [0, MAP_SIZE],
    ];

    for (const [cx, cy] of corners) {
      ctx.save();
      // Outer ink border
      ctx.beginPath();
      ctx.arc(cx, cy, cornerRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444';
      ctx.fill();
      ctx.lineWidth = 5;
      ctx.strokeStyle = '#090d16';
      ctx.stroke();

      // Top lighter crescent
      ctx.beginPath();
      ctx.arc(cx, cy, cornerRadius * 0.72, 0, Math.PI * 2);
      ctx.fillStyle = '#f87171';
      ctx.fill();

      // White comic gloss sparkle
      ctx.beginPath();
      ctx.arc(cx - (cx === 0 ? -10 : 10), cy - (cy === 0 ? -10 : 10), 7, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  // Draw Battle Royale Toxic Zone (Cartoon Danger Ring)
  private drawBattleRoyaleZone(brZone: BattleRoyaleZone) {
    const ctx = this.ctx;
    ctx.save();

    // Outer toxic storm overlay
    ctx.beginPath();
    ctx.rect(0, 0, MAP_SIZE, MAP_SIZE);
    ctx.arc(brZone.centerX, brZone.centerY, brZone.radius, 0, Math.PI * 2, true);
    ctx.fillStyle = 'rgba(239, 68, 68, 0.28)';
    ctx.fill();

    // 2D Cartoon Danger Border (Bold comic line with white dashed inner guard)
    ctx.beginPath();
    ctx.arc(brZone.centerX, brZone.centerY, brZone.radius, 0, Math.PI * 2);
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 8;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(brZone.centerX, brZone.centerY, brZone.radius - 4, 0, Math.PI * 2);
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 3;
    ctx.setLineDash([16, 12]);
    ctx.lineDashOffset = -this.animTime * 18;
    ctx.stroke();
    ctx.setLineDash([]);

    // Target circle preview
    if (brZone.radius > brZone.targetRadius) {
      ctx.beginPath();
      ctx.arc(brZone.centerX, brZone.centerY, brZone.targetRadius, 0, Math.PI * 2);
      ctx.setLineDash([10, 10]);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.setLineDash([]);
    }

    ctx.restore();
  }

  // Draw Food Items (Wormzilla delicious treats & sweets)
  // Draw Food Items - Adorable Cartoon "Comidinhas" with bold outlines & pop details
  private drawFoodItem(ctx: CanvasRenderingContext2D, orb: Orb) {
    const r = orb.radius;
    const type = orb.foodType || 'donut';
    const ox = orb.x;
    const oy = orb.y;

    ctx.save();

    switch (type) {
      case 'donut': {
        // Dough base with dark cartoon outline
        ctx.beginPath();
        ctx.arc(ox, oy, r, 0, Math.PI * 2);
        ctx.fillStyle = '#f59e0b';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#1e1b4b';
        ctx.stroke();

        // Strawberry / chocolate glaze
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.78, 0, Math.PI * 2);
        ctx.fillStyle = orb.color || '#ec4899';
        ctx.fill();
        ctx.lineWidth = 1.4;
        ctx.strokeStyle = 'rgba(0,0,0,0.4)';
        ctx.stroke();

        // Donut center hole
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.32, 0, Math.PI * 2);
        ctx.fillStyle = '#050814';
        ctx.fill();
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = '#1e1b4b';
        ctx.stroke();

        // Rainbow sprinkles
        const sprinkleColors = ['#ffffff', '#38bdf8', '#fbbf24', '#4ade80'];
        for (let s = 0; s < 4; s++) {
          const sa = (s * Math.PI) / 2 + 0.35;
          const sx = ox + Math.cos(sa) * (r * 0.54);
          const sy = oy + Math.sin(sa) * (r * 0.54);
          ctx.fillStyle = sprinkleColors[s % sprinkleColors.length];
          ctx.fillRect(sx - 1.5, sy - 1.5, 3, 3);
        }
        break;
      }

      case 'watermelon': {
        // Green rind with outline
        ctx.beginPath();
        ctx.arc(ox, oy, r, 0, Math.PI);
        ctx.closePath();
        ctx.fillStyle = '#16a34a';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#052e16';
        ctx.stroke();

        // White inner rind
        ctx.beginPath();
        ctx.arc(ox, oy - 1, r * 0.85, 0, Math.PI);
        ctx.closePath();
        ctx.fillStyle = '#bbf7d0';
        ctx.fill();

        // Red pulp
        ctx.beginPath();
        ctx.arc(ox, oy - 2, r * 0.72, 0, Math.PI);
        ctx.closePath();
        ctx.fillStyle = '#ef4444';
        ctx.fill();

        // Black seeds
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(ox - r * 0.32, oy + r * 0.3, 1.6, 0, Math.PI * 2);
        ctx.arc(ox, oy + r * 0.45, 1.6, 0, Math.PI * 2);
        ctx.arc(ox + r * 0.32, oy + r * 0.3, 1.6, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'strawberry': {
        // Strawberry body
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = '#f43f5e';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#4c0519';
        ctx.stroke();

        // Tiny yellow seeds
        ctx.fillStyle = '#fef08a';
        for (let i = -1; i <= 1; i++) {
          ctx.beginPath();
          ctx.arc(ox + i * (r * 0.35), oy + (Math.abs(i) === 1 ? -2 : 2), 1.3, 0, Math.PI * 2);
          ctx.fill();
        }

        // Green leaves on top
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(ox - 3, oy - r * 0.75, 2.5, 0, Math.PI * 2);
        ctx.arc(ox, oy - r * 0.85, 2.8, 0, Math.PI * 2);
        ctx.arc(ox + 3, oy - r * 0.75, 2.5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'pizza': {
        // Crust slice
        ctx.beginPath();
        ctx.moveTo(ox, oy + r * 0.95);
        ctx.lineTo(ox - r * 0.85, oy - r * 0.75);
        ctx.lineTo(ox + r * 0.85, oy - r * 0.75);
        ctx.closePath();
        ctx.fillStyle = '#facc15';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#713f12';
        ctx.stroke();

        // Crust top border
        ctx.lineWidth = 3.5;
        ctx.strokeStyle = '#d97706';
        ctx.beginPath();
        ctx.moveTo(ox - r * 0.85, oy - r * 0.75);
        ctx.lineTo(ox + r * 0.85, oy - r * 0.75);
        ctx.stroke();

        // Pepperoni slices
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(ox - 2.5, oy - 1, 2.8, 0, Math.PI * 2);
        ctx.arc(ox + 3, oy + 3, 2.5, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'lollipop': {
        // White stick
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(ox, oy);
        ctx.lineTo(ox + r * 0.9, oy + r * 1.3);
        ctx.stroke();

        // Candy disk with outline
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = orb.color || '#ec4899';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#0f172a';
        ctx.stroke();

        // Swirl line
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2.0;
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.48, 0.4, Math.PI * 1.6);
        ctx.stroke();
        break;
      }

      case 'icecream': {
        // Popsicle stick
        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = 3.0;
        ctx.beginPath();
        ctx.moveTo(ox, oy + r * 0.4);
        ctx.lineTo(ox, oy + r * 1.25);
        ctx.stroke();

        // Popsicle body
        ctx.beginPath();
        ctx.rect(ox - r * 0.6, oy - r * 0.85, r * 1.2, r * 1.25);
        ctx.fillStyle = orb.color || '#06b6d4';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#0f172a';
        ctx.stroke();

        // Drip highlight
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.beginPath();
        ctx.arc(ox - r * 0.25, oy - r * 0.4, 2, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'burger': {
        // Bottom bun
        ctx.beginPath();
        ctx.arc(ox, oy + r * 0.2, r * 0.8, 0, Math.PI);
        ctx.fillStyle = '#d97706';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#451a03';
        ctx.stroke();

        // Patty
        ctx.fillStyle = '#78350f';
        ctx.fillRect(ox - r * 0.75, oy + r * 0.05, r * 1.5, r * 0.25);

        // Cheese & Lettuce
        ctx.fillStyle = '#22c55e';
        ctx.fillRect(ox - r * 0.8, oy - r * 0.12, r * 1.6, r * 0.15);
        ctx.fillStyle = '#facc15';
        ctx.fillRect(ox - r * 0.7, oy - r * 0.02, r * 1.4, r * 0.1);

        // Top rounded bun with sesame seeds
        ctx.beginPath();
        ctx.arc(ox, oy - r * 0.15, r * 0.8, Math.PI, 0);
        ctx.fillStyle = '#f59e0b';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#451a03';
        ctx.stroke();

        // Sesame dots
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(ox - 3, oy - r * 0.4, 1.2, 0, Math.PI * 2);
        ctx.arc(ox + 2, oy - r * 0.45, 1.2, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'cookie': {
        // Golden cookie disk
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = '#d97706';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#451a03';
        ctx.stroke();

        // Chocolate chips
        ctx.fillStyle = '#451a03';
        ctx.beginPath();
        ctx.arc(ox - 3, oy - 2.5, 2.0, 0, Math.PI * 2);
        ctx.arc(ox + 3.5, oy - 1.5, 1.8, 0, Math.PI * 2);
        ctx.arc(ox, oy + 3.5, 2.0, 0, Math.PI * 2);
        ctx.fill();
        break;
      }

      case 'cake': {
        // Layered Strawberry Cake slice
        ctx.beginPath();
        ctx.moveTo(ox - r * 0.85, oy + r * 0.7);
        ctx.lineTo(ox + r * 0.85, oy + r * 0.7);
        ctx.lineTo(ox, oy - r * 0.85);
        ctx.closePath();
        ctx.fillStyle = '#fde047';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#451a03';
        ctx.stroke();

        // White cream layer
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(ox - r * 0.55, oy + r * 0.1, r * 1.1, r * 0.22);

        // Pink frosting on top
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(ox, oy - r * 0.85, r * 0.35, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = '#4c0519';
        ctx.stroke();
        break;
      }

      case 'croissant': {
        // Golden curved croissant
        ctx.beginPath();
        ctx.ellipse(ox, oy, r * 0.9, r * 0.5, 0, 0, Math.PI * 2);
        ctx.fillStyle = '#d97706';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#451a03';
        ctx.stroke();

        // Flaky folds
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.arc(ox - r * 0.35, oy, r * 0.35, -Math.PI / 2, Math.PI / 2);
        ctx.arc(ox + r * 0.35, oy, r * 0.35, -Math.PI / 2, Math.PI / 2);
        ctx.stroke();
        break;
      }

      case 'cherry': {
        // Green stems
        ctx.strokeStyle = '#15803d';
        ctx.lineWidth = 2.0;
        ctx.beginPath();
        ctx.moveTo(ox, oy - r * 0.9);
        ctx.lineTo(ox - r * 0.35, oy + 1);
        ctx.moveTo(ox, oy - r * 0.9);
        ctx.lineTo(ox + r * 0.4, oy + 1);
        ctx.stroke();

        // Leaf
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(ox + 3, oy - r * 0.95, 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Two cherry balls
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(ox - r * 0.35, oy + 1, r * 0.45, 0, Math.PI * 2);
        ctx.arc(ox + r * 0.4, oy + 1, r * 0.45, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#450a0a';
        ctx.stroke();
        break;
      }

      case 'apple': {
        // Apple body
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = orb.color?.includes('green') || orb.color?.includes('emerald') ? '#22c55e' : '#ef4444';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#450a0a';
        ctx.stroke();

        // Gloss
        ctx.beginPath();
        ctx.arc(ox - r * 0.3, oy - r * 0.3, r * 0.25, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.fill();

        // Brown stem & green leaf
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(ox, oy - r * 0.7);
        ctx.lineTo(ox + 2, oy - r * 1.15);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(ox + 3, oy - r * 1.0, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#16a34a';
        ctx.fill();
        break;
      }

      case 'cupcake': {
        // Cup base
        ctx.beginPath();
        ctx.moveTo(ox - r * 0.75, oy);
        ctx.lineTo(ox - r * 0.55, oy + r * 0.85);
        ctx.lineTo(ox + r * 0.55, oy + r * 0.85);
        ctx.lineTo(ox + r * 0.75, oy);
        ctx.closePath();
        ctx.fillStyle = '#b45309';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#451a03';
        ctx.stroke();

        // Frosting dome
        ctx.beginPath();
        ctx.arc(ox, oy - r * 0.15, r * 0.75, 0, Math.PI * 2);
        ctx.fillStyle = orb.color || '#f472b6';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#1e1b4b';
        ctx.stroke();

        // Cherry on top
        ctx.beginPath();
        ctx.arc(ox, oy - r * 0.75, r * 0.3, 0, Math.PI * 2);
        ctx.fillStyle = '#ef4444';
        ctx.fill();
        break;
      }

      case 'candy': {
        // Bonbon wrapper tips
        ctx.fillStyle = orb.glowColor || orb.color || '#ec4899';
        ctx.beginPath();
        ctx.moveTo(ox - r * 1.5, oy - r * 0.45);
        ctx.lineTo(ox - r * 0.6, oy);
        ctx.lineTo(ox - r * 1.5, oy + r * 0.45);
        ctx.closePath();
        ctx.fill();
        ctx.lineWidth = 1.8;
        ctx.strokeStyle = '#0f172a';
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(ox + r * 1.5, oy - r * 0.45);
        ctx.lineTo(ox + r * 0.6, oy);
        ctx.lineTo(ox + r * 1.5, oy + r * 0.45);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Center sweet
        ctx.beginPath();
        ctx.arc(ox, oy, r * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = orb.color || '#a855f7';
        ctx.fill();
        ctx.lineWidth = 2.0;
        ctx.strokeStyle = '#0f172a';
        ctx.stroke();

        // Spiral shine
        ctx.beginPath();
        ctx.arc(ox - r * 0.25, oy - r * 0.25, r * 0.28, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.fill();
        break;
      }

      case 'star':
      default: {
        ctx.beginPath();
        ctx.arc(ox, oy, r, 0, Math.PI * 2);
        ctx.fillStyle = orb.color || '#facc15';
        ctx.fill();
        ctx.lineWidth = 2.2;
        ctx.strokeStyle = '#1e1b4b';
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(ox - r * 0.3, oy - r * 0.3, r * 0.35, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.fill();
        break;
      }
    }

    ctx.restore();
  }

  // Draw Orbs - Wormzilla radiant cartoon "comidinhas"
  private drawOrbs(orbs: Orb[], minX: number, maxX: number, minY: number, maxY: number) {
    const ctx = this.ctx;
    const defaultFoodList: NonNullable<Orb['foodType']>[] = [
      'donut',
      'watermelon',
      'strawberry',
      'pizza',
      'candy',
      'burger',
      'icecream',
      'cookie',
      'cherry',
      'apple',
      'lollipop',
      'cupcake',
    ];

    for (let i = 0; i < orbs.length; i++) {
      const orb = orbs[i];
      if (orb.x < minX || orb.x > maxX || orb.y < minY || orb.y > maxY) {
        continue;
      }

      ctx.save();

      // Outer glowing jelly aura
      if (orb.value > 1) {
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius * 1.45, 0, Math.PI * 2);
        ctx.fillStyle = orb.glowColor || orb.color;
        ctx.globalAlpha = 0.26;
        ctx.fill();
      }

      // High performance outer glow for rich snacks (zero shadowBlur lag)
      if (orb.value > 4) {
        ctx.beginPath();
        ctx.arc(orb.x, orb.y, orb.radius * 1.8, 0, Math.PI * 2);
        ctx.fillStyle = orb.glowColor || orb.color;
        ctx.globalAlpha = 0.18;
        ctx.fill();
      }

      ctx.globalAlpha = 1.0;

      // Ensure every orb is drawn as a delicious comidinha!
      if (!orb.foodType) {
        orb.foodType = defaultFoodList[orb.id % defaultFoodList.length];
      }

      this.drawFoodItem(ctx, orb);

      ctx.restore();
    }
  }

  // Draw Power-Ups
  private drawPowerUps(powerUps: PowerUp[], minX: number, maxX: number, minY: number, maxY: number) {
    const ctx = this.ctx;

    for (const p of powerUps) {
      if (p.x < minX || p.x > maxX || p.y < minY || p.y > maxY) continue;

      ctx.save();
      ctx.translate(p.x, p.y);

      // Pulsing outer halo
      const pulseScale = 1 + Math.sin(p.pulse) * 0.15;
      const r = p.radius * pulseScale;

      let color = '#38bdf8';
      let icon = '⚡';
      if (p.type === 'magnet') {
        color = '#ec4899';
        icon = '🧲';
      } else if (p.type === 'curvinha') {
        color = '#06b6d4';
        icon = '🌀';
      } else if (p.type === 'speed_x10') {
        color = '#f43f5e';
        icon = '🚀';
      } else if (p.type === 'multiplier') {
        color = '#eab308';
        icon = '2X';
      } else if (p.type === 'plasma') {
        color = '#8b5cf6';
        icon = '💥';
      }

      // Outer glow circle (double stroke for vibrant glow without shadowBlur)
      ctx.beginPath();
      ctx.arc(0, 0, r + 8, 0, Math.PI * 2);
      ctx.strokeStyle = color;
      ctx.lineWidth = 5;
      ctx.globalAlpha = 0.35;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, r + 6, 0, Math.PI * 2);
      ctx.strokeStyle = color;
      ctx.lineWidth = 2.5;
      ctx.globalAlpha = 1.0;
      ctx.stroke();

      // Background disc
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.fill();

      // Icon
      ctx.font = `bold ${Math.floor(r * 0.9)}px Outfit, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(icon, 0, 1);

      ctx.restore();
    }
  }

  // Draw Projectiles (Plasma blasts)
  private drawProjectiles(projectiles: Projectile[]) {
    const ctx = this.ctx;
    for (const p of projectiles) {
      ctx.save();
      // Outer soft aura
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius * 1.6, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = 0.32;
      ctx.fill();

      // Main core
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = 1.0;
      ctx.fill();

      // Trail
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - p.vx * 3, p.y - p.vy * 3);
      ctx.strokeStyle = p.color;
      ctx.lineWidth = p.radius;
      ctx.stroke();

      ctx.restore();
    }
  }

  // Draw individual worm (Spine, segments, head, eyes, accessories, names)
  private drawWorm(worm: Worm) {
    const ctx = this.ctx;
    const segs = worm.segments;
    if (segs.length === 0) return;

    ctx.save();

    // Handle dying alpha fade
    if (worm.isDead && worm.deadAlpha !== undefined) {
      ctx.globalAlpha = Math.max(0, worm.deadAlpha);
    }

    const skin = worm.skin;
    const isCurvinha = !!worm.isCurvinha || (worm.activePowerUps.curvinha > 0);
    const speedMult = worm.speedMultiplier || (worm.activePowerUps.speed_x10 > 0 ? 10 : 2);

    // Curvinha drift aura (Zero-lag layered alpha glow)
    if (isCurvinha && !worm.isDead) {
      ctx.save();
      ctx.beginPath();
      for (let i = 0; i < Math.min(segs.length, 10); i++) {
        const s = segs[i];
        ctx.arc(s.x, s.y, s.radius * 1.45, 0, Math.PI * 2);
      }
      ctx.fillStyle = '#06b6d4';
      ctx.globalAlpha = 0.22;
      ctx.fill();

      ctx.beginPath();
      for (let i = 0; i < Math.min(segs.length, 8); i++) {
        const s = segs[i];
        ctx.arc(s.x, s.y, s.radius * 1.25, 0, Math.PI * 2);
      }
      ctx.fillStyle = '#22d3ee';
      ctx.globalAlpha = 0.45;
      ctx.fill();
      ctx.restore();
    }

    // High Speed Hyper Boost Trail (X5, X10)
    if (worm.isBoosting && !worm.isDead && speedMult >= 5) {
      ctx.save();
      ctx.beginPath();
      for (let i = 0; i < Math.min(segs.length, 16); i++) {
        const s = segs[i];
        ctx.arc(s.x, s.y, s.radius * (speedMult >= 10 ? 1.65 : 1.45), 0, Math.PI * 2);
      }
      ctx.fillStyle = speedMult >= 10 ? '#f43f5e' : '#f59e0b';
      ctx.globalAlpha = 0.35;
      ctx.fill();
      ctx.restore();
    }

    // 1. Draw Boost Trail / Plasma Glow if boosting
    if (worm.isBoosting && !worm.isDead) {
      ctx.save();
      ctx.beginPath();
      for (let i = 0; i < Math.min(segs.length, 12); i++) {
        const s = segs[i];
        ctx.arc(s.x, s.y, s.radius * 1.35, 0, Math.PI * 2);
      }
      ctx.fillStyle = skin.accentColor;
      ctx.globalAlpha = 0.3;
      ctx.fill();
      ctx.restore();
    }

    // 2. Draw Body Segments from tail to neck (Cartoon Graphic Style)
    const customImg = this.getSkinImage(skin.customImageUrl);
    const applyToBody =
      customImg &&
      (!skin.customImageApplyMode ||
        skin.customImageApplyMode === 'head_and_body' ||
        skin.customImageApplyMode === 'body_only');
    const applyToHead =
      customImg &&
      (!skin.customImageApplyMode ||
        skin.customImageApplyMode === 'head_and_body' ||
        skin.customImageApplyMode === 'head_only');

    for (let i = segs.length - 1; i >= 0; i--) {
      const seg = segs[i];
      const isAlt = (i % 4) < 2;
      const color = isAlt ? skin.primaryColor : skin.secondaryColor;

      ctx.save();

      // Base body circle
      ctx.beginPath();
      ctx.arc(seg.x, seg.y, seg.radius, 0, Math.PI * 2);

      if (applyToBody && customImg) {
        ctx.fillStyle = color;
        ctx.fill();
        ctx.clip();

        // Draw custom image with aspect ratio fit & adjustments (works for mobile & PC)
        this.drawFittedImage(ctx, customImg, seg.x, seg.y, seg.radius, skin);

        // Cartoon Cel-Shading Shadow on lower crescent
        ctx.beginPath();
        ctx.arc(seg.x + seg.radius * 0.22, seg.y + seg.radius * 0.26, seg.radius * 0.95, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
        ctx.fill();

        // Glossy Cartoon Pop-Highlight (candy/vinyl shine bean)
        ctx.save();
        ctx.translate(seg.x - seg.radius * 0.32, seg.y - seg.radius * 0.32);
        ctx.rotate(-Math.PI / 4);
        ctx.beginPath();
        ctx.ellipse(0, 0, seg.radius * 0.3, seg.radius * 0.14, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(seg.radius * 0.22, seg.radius * 0.18, seg.radius * 0.08, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fill();
        ctx.restore();
      } else if (skin.pattern === 'patriota') {
        // Deep obsidian body base
        ctx.fillStyle = isAlt ? '#0a0d14' : '#111827';
        ctx.fill();

        // Bright Neon Green Rim Glow with high-efficiency concentric stroke (no shadowBlur lag)
        ctx.save();
        ctx.beginPath();
        ctx.arc(seg.x, seg.y, seg.radius * 0.94, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(34, 197, 94, 0.45)';
        ctx.lineWidth = Math.max(4.5, seg.radius * 0.24);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(seg.x, seg.y, seg.radius * 0.94, 0, Math.PI * 2);
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = Math.max(2.2, seg.radius * 0.12);
        ctx.stroke();
        ctx.restore();

        // Brazilian Flag Shield or Golden Trophy on segments
        if (i % 6 === 2) {
          // Brazilian Flag 🇧🇷
          ctx.save();
          ctx.translate(seg.x, seg.y);
          const flagR = seg.radius * 0.44;
          ctx.fillStyle = '#16a34a';
          ctx.fillRect(-flagR, -flagR * 0.7, flagR * 2, flagR * 1.4);
          ctx.fillStyle = '#facc15';
          ctx.beginPath();
          ctx.moveTo(0, -flagR * 0.6);
          ctx.lineTo(flagR * 0.8, 0);
          ctx.lineTo(0, flagR * 0.6);
          ctx.lineTo(-flagR * 0.8, 0);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#1d4ed8';
          ctx.beginPath();
          ctx.arc(0, 0, flagR * 0.32, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (i % 6 === 5) {
          // Golden Trophy 🏆
          ctx.save();
          ctx.translate(seg.x, seg.y);
          const tr = seg.radius * 0.36;
          ctx.font = `${Math.floor(tr * 2)}px sans-serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🏆', 0, 0);
          ctx.restore();
        }
      } else {
        // Vibrant cartoon base fill
        ctx.fillStyle = color;
        ctx.fill();

        // Cartoon Cel-Shading underside crescent
        ctx.save();
        ctx.clip();
        ctx.beginPath();
        ctx.arc(seg.x + seg.radius * 0.2, seg.y + seg.radius * 0.28, seg.radius * 0.95, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
        ctx.fill();

        // Cute cartoon ventral belly stripe on alternating segments
        if (i % 2 === 0) {
          ctx.beginPath();
          ctx.arc(seg.x, seg.y + seg.radius * 0.58, seg.radius * 0.5, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(9, 13, 22, 0.4)';
          ctx.lineWidth = Math.max(1, seg.radius * 0.08);
          ctx.stroke();
        }
        ctx.restore();

        // Glossy Cartoon Pop-Highlight (candy / vinyl toy shine)
        ctx.save();
        ctx.translate(seg.x - seg.radius * 0.32, seg.y - seg.radius * 0.32);
        ctx.rotate(-Math.PI / 4);
        ctx.beginPath();
        ctx.ellipse(0, 0, seg.radius * 0.32, seg.radius * 0.15, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(seg.radius * 0.24, seg.radius * 0.18, seg.radius * 0.08, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fill();
        ctx.restore();
      }

      // Bold Cartoon Ink Outline
      ctx.beginPath();
      ctx.arc(seg.x, seg.y, seg.radius, 0, Math.PI * 2);
      ctx.lineWidth = Math.max(2.2, seg.radius * 0.16);
      ctx.strokeStyle = '#090d16';
      ctx.stroke();

      // Tail Tip Cartoon Detail
      if (i === segs.length - 1) {
        ctx.beginPath();
        ctx.arc(seg.x, seg.y, seg.radius * 0.6, 0, Math.PI * 2);
        ctx.fillStyle = skin.accentColor;
        ctx.fill();
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = Math.max(1.8, seg.radius * 0.12);
        ctx.stroke();
      }

      ctx.restore();
    }

    // 3. Draw Head (Cartoony Graphic Style)
    const headRadius = segs[0].radius * 1.15;
    ctx.save();
    ctx.translate(worm.x, worm.y);
    ctx.rotate(worm.angle);

    // 3a. Animated Cute Forked Tongue (Linguinha de cobra cartunada)
    const flickSpeed = worm.isBoosting ? 18 : 8;
    const flickWave = Math.sin(this.animTime * flickSpeed);
    if (flickWave > -0.1 || worm.isBoosting) {
      const tongueExtension =
        (worm.isBoosting ? 1.35 : 1.0) *
        Math.max(0.3, (flickWave + 1) / 2) *
        headRadius *
        0.75;
      const tongueWiggle = Math.sin(this.animTime * 24) * 2;
      const tx = headRadius * 0.88;

      ctx.save();
      ctx.translate(tx, 0);
      ctx.beginPath();
      // Base of tongue
      ctx.moveTo(0, -headRadius * 0.08);
      ctx.lineTo(tongueExtension * 0.65, -headRadius * 0.08 + tongueWiggle);
      // Fork tip left
      ctx.lineTo(tongueExtension, -headRadius * 0.22 + tongueWiggle);
      ctx.lineTo(tongueExtension * 0.68, tongueWiggle);
      // Fork tip right
      ctx.lineTo(tongueExtension, headRadius * 0.22 + tongueWiggle);
      ctx.lineTo(tongueExtension * 0.65, headRadius * 0.08 + tongueWiggle);
      ctx.lineTo(0, headRadius * 0.08);
      ctx.closePath();
      ctx.fillStyle = '#f43f5e'; // Bubblegum cartoon pink
      ctx.fill();
      ctx.lineWidth = Math.max(1.5, headRadius * 0.06);
      ctx.strokeStyle = '#090d16'; // Ink outline
      ctx.stroke();
      ctx.restore();
    }

    // Feathery collar behind head for owl mask
    if (skin.accessory === 'owl_mask') {
      ctx.save();
      ctx.fillStyle = '#ea580c';
      ctx.strokeStyle = '#7c2d12';
      ctx.lineWidth = Math.max(1.8, headRadius * 0.08);
      for (let angle = Math.PI * 0.58; angle <= Math.PI * 1.42; angle += 0.22) {
        ctx.save();
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.ellipse(headRadius * 0.98, 0, headRadius * 0.36, headRadius * 0.18, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      }
      ctx.restore();
    }

    // 3b. Head Base Circle & Shading
    if (applyToHead && customImg) {
      // Draw custom image in head circle
      ctx.save();
      ctx.beginPath();
      ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
      ctx.fillStyle = skin.primaryColor;
      ctx.fill();
      ctx.clip();

      // Draw custom image with aspect ratio fit & adjustments
      this.drawFittedImage(ctx, customImg, 0, 0, headRadius, skin);

      // Cartoon Cel-Shading Shadow on underside
      ctx.beginPath();
      ctx.arc(headRadius * 0.2, headRadius * 0.25, headRadius * 0.95, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
      ctx.fill();

      // Cartoon Head Glossy Highlight Bean
      ctx.save();
      ctx.translate(-headRadius * 0.35, -headRadius * 0.35);
      ctx.rotate(-Math.PI / 4);
      ctx.beginPath();
      ctx.ellipse(0, 0, headRadius * 0.36, headRadius * 0.16, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.fill();
      ctx.restore();

      ctx.restore();
    } else {
      // Base vibrant cartoon head fill
      ctx.beginPath();
      ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
      ctx.fillStyle = skin.primaryColor;
      ctx.fill();

      // Cartoon Cel-Shading underside crescent
      ctx.save();
      ctx.beginPath();
      ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
      ctx.clip();
      ctx.beginPath();
      ctx.arc(headRadius * 0.2, headRadius * 0.25, headRadius * 0.95, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
      ctx.fill();
      ctx.restore();

      // Cartoon Head Glossy Highlight Bean
      ctx.save();
      ctx.translate(-headRadius * 0.35, -headRadius * 0.35);
      ctx.rotate(-Math.PI / 4);
      ctx.beginPath();
      ctx.ellipse(0, 0, headRadius * 0.36, headRadius * 0.16, 0, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(headRadius * 0.25, headRadius * 0.2, headRadius * 0.09, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fill();
      ctx.restore();
    }

    // 3c. Bold Cartoon Ink Outline for Head
    ctx.beginPath();
    ctx.arc(0, 0, headRadius, 0, Math.PI * 2);
    ctx.lineWidth = Math.max(3.0, headRadius * 0.18);
    ctx.strokeStyle = '#090d16';
    ctx.stroke();

    // 3d. Rosy Cartoon Cheeks (Bochechinhas fofas)
    ctx.save();
    ctx.fillStyle = 'rgba(251, 113, 133, 0.45)';
    ctx.beginPath();
    ctx.ellipse(headRadius * 0.22, -headRadius * 0.62, headRadius * 0.2, headRadius * 0.13, Math.PI / 12, 0, Math.PI * 2);
    ctx.ellipse(headRadius * 0.22, headRadius * 0.62, headRadius * 0.2, headRadius * 0.13, -Math.PI / 12, 0, Math.PI * 2);
    ctx.fill();

    // Cute comic blush slashes (//)
    ctx.strokeStyle = '#e11d48';
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.18, -headRadius * 0.67);
    ctx.lineTo(headRadius * 0.26, -headRadius * 0.57);
    ctx.moveTo(headRadius * 0.23, -headRadius * 0.69);
    ctx.lineTo(headRadius * 0.31, -headRadius * 0.59);
    ctx.moveTo(headRadius * 0.18, headRadius * 0.57);
    ctx.lineTo(headRadius * 0.26, headRadius * 0.67);
    ctx.moveTo(headRadius * 0.23, headRadius * 0.55);
    ctx.lineTo(headRadius * 0.31, headRadius * 0.65);
    ctx.stroke();
    ctx.restore();

    // 3e. Cartoon Mouth (Sorriso / Boquinha)
    ctx.save();
    ctx.strokeStyle = '#090d16';
    ctx.lineWidth = Math.max(1.8, headRadius * 0.09);
    ctx.lineCap = 'round';
    if (worm.isBoosting) {
      // Excited cartoon open mouth grin with cute tiny fangs!
      ctx.beginPath();
      ctx.ellipse(headRadius * 0.55, 0, headRadius * 0.22, headRadius * 0.14, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#be123c';
      ctx.fill();
      ctx.stroke();

      // Cute white fangs
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.moveTo(headRadius * 0.48, -headRadius * 0.09);
      ctx.lineTo(headRadius * 0.58, -headRadius * 0.05);
      ctx.lineTo(headRadius * 0.54, -headRadius * 0.01);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(headRadius * 0.48, headRadius * 0.09);
      ctx.lineTo(headRadius * 0.58, headRadius * 0.05);
      ctx.lineTo(headRadius * 0.54, headRadius * 0.01);
      ctx.closePath();
      ctx.fill();
    } else {
      // Happy curved cartoon smirk
      ctx.beginPath();
      ctx.arc(headRadius * 0.35, 0, headRadius * 0.32, -Math.PI / 4, Math.PI / 4);
      ctx.stroke();
    }
    ctx.restore();

    // 3f. Expressive Big Cartoon Googly Eyes & Eyebrows
    const eyeOffsetX = headRadius * 0.42;
    const eyeOffsetY = headRadius * 0.46;
    const eyeRadius = headRadius * 0.36;
    const pupilRadius = eyeRadius * 0.54;

    if (skin.showEyes !== false) {
      // Sclera (White of the eyes with cartoon ink outline)
      // Left Eye
      ctx.beginPath();
      ctx.arc(eyeOffsetX, -eyeOffsetY, eyeRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.lineWidth = Math.max(2.4, eyeRadius * 0.18);
      ctx.strokeStyle = '#090d16';
      ctx.stroke();

      // Soft bottom cel-shadow in eye
      ctx.save();
      ctx.beginPath();
      ctx.arc(eyeOffsetX, -eyeOffsetY, eyeRadius, 0, Math.PI * 2);
      ctx.clip();
      ctx.beginPath();
      ctx.arc(eyeOffsetX, -eyeOffsetY + eyeRadius * 0.45, eyeRadius * 0.8, 0, Math.PI * 2);
      ctx.fillStyle = '#e2e8f0';
      ctx.fill();
      ctx.restore();

      // Right Eye
      ctx.beginPath();
      ctx.arc(eyeOffsetX, eyeOffsetY, eyeRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.lineWidth = Math.max(2.4, eyeRadius * 0.18);
      ctx.strokeStyle = '#090d16';
      ctx.stroke();

      // Soft bottom cel-shadow in eye
      ctx.save();
      ctx.beginPath();
      ctx.arc(eyeOffsetX, eyeOffsetY, eyeRadius, 0, Math.PI * 2);
      ctx.clip();
      ctx.beginPath();
      ctx.arc(eyeOffsetX, eyeOffsetY + eyeRadius * 0.45, eyeRadius * 0.8, 0, Math.PI * 2);
      ctx.fillStyle = '#e2e8f0';
      ctx.fill();
      ctx.restore();

      // Colorful Iris
      const irisRadius = eyeRadius * 0.72;
      const pupilOffset = worm.isBoosting ? eyeRadius * 0.4 : eyeRadius * 0.32;
      const pupilR = worm.isBoosting ? pupilRadius * 1.25 : pupilRadius;
      const irisColor = skin.accentColor || '#06b6d4';

      // Left Iris
      ctx.beginPath();
      ctx.arc(eyeOffsetX + pupilOffset * 0.7, -eyeOffsetY, irisRadius, 0, Math.PI * 2);
      ctx.fillStyle = irisColor;
      ctx.fill();
      ctx.lineWidth = Math.max(1.2, eyeRadius * 0.08);
      ctx.strokeStyle = '#090d16';
      ctx.stroke();

      // Right Iris
      ctx.beginPath();
      ctx.arc(eyeOffsetX + pupilOffset * 0.7, eyeOffsetY, irisRadius, 0, Math.PI * 2);
      ctx.fillStyle = irisColor;
      ctx.fill();
      ctx.stroke();

      // Pupils (Black Ink)
      ctx.beginPath();
      ctx.arc(eyeOffsetX + pupilOffset, -eyeOffsetY, pupilR, 0, Math.PI * 2);
      ctx.fillStyle = '#090d16';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(eyeOffsetX + pupilOffset, eyeOffsetY, pupilR, 0, Math.PI * 2);
      ctx.fillStyle = '#090d16';
      ctx.fill();

      // Triple Cartoon / Anime Sparkles (Glints)
      // Left Eye Glints
      ctx.beginPath();
      ctx.arc(eyeOffsetX + eyeRadius * 0.48, -eyeOffsetY - eyeRadius * 0.28, pupilRadius * 0.48, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(eyeOffsetX + eyeRadius * 0.2, -eyeOffsetY + eyeRadius * 0.26, pupilRadius * 0.25, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(eyeOffsetX + eyeRadius * 0.6, -eyeOffsetY + eyeRadius * 0.1, pupilRadius * 0.14, 0, Math.PI * 2);
      ctx.fill();

      // Right Eye Glints
      ctx.beginPath();
      ctx.arc(eyeOffsetX + eyeRadius * 0.48, eyeOffsetY - eyeRadius * 0.28, pupilRadius * 0.48, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(eyeOffsetX + eyeRadius * 0.2, eyeOffsetY + eyeRadius * 0.26, pupilRadius * 0.25, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(eyeOffsetX + eyeRadius * 0.6, eyeOffsetY + eyeRadius * 0.1, pupilRadius * 0.14, 0, Math.PI * 2);
      ctx.fill();

      // 3g. Expressive Cartoon Eyebrows
      ctx.save();
      ctx.strokeStyle = '#090d16';
      ctx.lineWidth = Math.max(2.4, headRadius * 0.12);
      ctx.lineCap = 'round';

      if (worm.isBoosting) {
        // Fierce / determined cartoon action eyebrows!
        ctx.beginPath();
        ctx.moveTo(eyeOffsetX - eyeRadius * 0.7, -eyeOffsetY - eyeRadius * 0.95);
        ctx.lineTo(eyeOffsetX + eyeRadius * 0.6, -eyeOffsetY - eyeRadius * 1.35);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(eyeOffsetX - eyeRadius * 0.7, eyeOffsetY + eyeRadius * 0.95);
        ctx.lineTo(eyeOffsetX + eyeRadius * 0.6, eyeOffsetY + eyeRadius * 1.35);
        ctx.stroke();

        // Little flying cartoon sweat droplet when speeding!
        ctx.save();
        ctx.translate(-headRadius * 0.6, -headRadius * 0.9);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(headRadius * 0.15, -headRadius * 0.25, 0, -headRadius * 0.35);
        ctx.quadraticCurveTo(-headRadius * 0.15, -headRadius * 0.25, 0, 0);
        ctx.fillStyle = '#38bdf8';
        ctx.fill();
        ctx.lineWidth = 1;
        ctx.strokeStyle = '#090d16';
        ctx.stroke();
        ctx.restore();
      } else {
        // Happy arched cartoon eyebrows
        ctx.beginPath();
        ctx.arc(eyeOffsetX, -eyeOffsetY - eyeRadius * 0.75, eyeRadius * 0.65, Math.PI * 1.05, Math.PI * 1.85);
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(eyeOffsetX, eyeOffsetY - eyeRadius * 0.05, eyeRadius * 0.65, Math.PI * 1.15, Math.PI * 1.95);
        ctx.stroke();
      }
      ctx.restore();
    }

    // 4. Draw Accessory
    if (skin.accessory === 'crown') {
      this.drawCrown(headRadius);
    } else if (skin.accessory === 'visor') {
      this.drawVisor(headRadius, eyeOffsetX, eyeOffsetY, eyeRadius);
    } else if (skin.accessory === 'horns') {
      this.drawHorns(headRadius);
    } else if (skin.accessory === 'halo') {
      this.drawHalo(headRadius);
    } else if (skin.accessory === 'bandana') {
      this.drawBandana(headRadius);
    } else if (skin.accessory === 'owl_mask') {
      this.drawOwlMask(headRadius);
    }

    ctx.restore();

    // 5. Draw Name Tag & Mass above head
    ctx.save();
    ctx.font = `bold ${Math.max(12, Math.floor(headRadius * 0.85))}px Outfit, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';

    const tagY = worm.y - headRadius - 12;
    const nameText = worm.isPlayer ? `★ ${worm.name} ★` : worm.name;

    // Dark pill background for crisp readability
    const textWidth = ctx.measureText(nameText).width;
    ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
    ctx.beginPath();
    ctx.roundRect(worm.x - textWidth / 2 - 8, tagY - 18, textWidth + 16, 22, 11);
    ctx.fill();
    ctx.strokeStyle = worm.isPlayer ? '#38bdf8' : 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.fillStyle = worm.isPlayer ? '#38bdf8' : '#ffffff';
    ctx.fillText(nameText, worm.x, tagY);
    ctx.restore();

    ctx.restore();
  }

  // Accessories (Cartoon Graphic Style)
  private drawCrown(headRadius: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(-headRadius * 0.35, 0);

    const w = headRadius * 0.95;
    const h = headRadius * 0.65;

    // Crown base & spikes
    ctx.beginPath();
    ctx.moveTo(-h / 2, -w / 2);
    ctx.lineTo(h / 2, -w / 2);
    ctx.lineTo(h * 0.2, -w * 0.2);
    ctx.lineTo(h * 0.85, 0);
    ctx.lineTo(h * 0.2, w * 0.2);
    ctx.lineTo(h / 2, w / 2);
    ctx.lineTo(-h / 2, w / 2);
    ctx.closePath();

    ctx.fillStyle = '#facc15'; // Bright cartoon gold
    ctx.fill();

    // Cel-shading lower half
    ctx.save();
    ctx.clip();
    ctx.fillStyle = 'rgba(217, 119, 6, 0.35)';
    ctx.fillRect(-h / 2, -w / 2, h * 0.5, w);
    ctx.restore();

    // Bold Cartoon Ink Outline
    ctx.lineWidth = Math.max(2.4, headRadius * 0.1);
    ctx.strokeStyle = '#090d16';
    ctx.stroke();

    // Cartoon Rubies on crown base
    const rubyRadius = headRadius * 0.12;
    [-w * 0.3, 0, w * 0.3].forEach((pos) => {
      ctx.beginPath();
      ctx.arc(-h * 0.2, pos, rubyRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444';
      ctx.fill();
      ctx.strokeStyle = '#090d16';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Ruby sparkle
      ctx.beginPath();
      ctx.arc(-h * 0.25, pos - rubyRadius * 0.3, rubyRadius * 0.35, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
    });

    ctx.restore();
  }

  private drawVisor(headRadius: number, eyeX: number, eyeY: number, eyeR: number) {
    const ctx = this.ctx;
    ctx.save();

    // Chunky Cartoon Sunglasses / Visor
    const vx = eyeX - eyeR * 0.6;
    const vy = -eyeY - eyeR * 0.8;
    const vw = eyeR * 2.2;
    const vh = eyeY * 2 + eyeR * 1.6;

    ctx.beginPath();
    ctx.roundRect(vx, vy, vw, vh, 8);
    ctx.fillStyle = '#0f172a'; // Dark retro lens
    ctx.fill();

    // Bold Cartoon Ink Rim
    ctx.lineWidth = Math.max(2.8, eyeR * 0.22);
    ctx.strokeStyle = '#090d16';
    ctx.stroke();

    // Diagonal Cartoon Reflection Glints (Stripes)
    ctx.save();
    ctx.clip();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.beginPath();
    ctx.moveTo(vx, vy + 4);
    ctx.lineTo(vx + vw * 0.5, vy);
    ctx.lineTo(vx + vw * 0.3, vy + vh);
    ctx.lineTo(vx, vy + vh);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.beginPath();
    ctx.moveTo(vx + vw * 0.6, vy);
    ctx.lineTo(vx + vw * 0.8, vy);
    ctx.lineTo(vx + vw * 0.6, vy + vh);
    ctx.lineTo(vx + vw * 0.45, vy + vh);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    ctx.restore();
  }

  private drawHorns(headRadius: number) {
    const ctx = this.ctx;
    ctx.save();

    // Horn left
    ctx.beginPath();
    ctx.moveTo(0, -headRadius * 0.7);
    ctx.quadraticCurveTo(headRadius * 0.6, -headRadius * 1.3, headRadius * 0.95, -headRadius * 1.65);
    ctx.quadraticCurveTo(headRadius * 0.2, -headRadius * 1.0, -headRadius * 0.2, -headRadius * 0.7);
    ctx.closePath();
    ctx.fillStyle = '#ef4444';
    ctx.fill();
    ctx.lineWidth = Math.max(2.4, headRadius * 0.1);
    ctx.strokeStyle = '#090d16';
    ctx.stroke();

    // Ivory tip left
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.6, -headRadius * 1.3);
    ctx.quadraticCurveTo(headRadius * 0.75, -headRadius * 1.45, headRadius * 0.95, -headRadius * 1.65);
    ctx.quadraticCurveTo(headRadius * 0.45, -headRadius * 1.25, headRadius * 0.35, -headRadius * 1.15);
    ctx.closePath();
    ctx.fillStyle = '#fef3c7';
    ctx.fill();

    // Horn right
    ctx.beginPath();
    ctx.moveTo(0, headRadius * 0.7);
    ctx.quadraticCurveTo(headRadius * 0.6, headRadius * 1.3, headRadius * 0.95, headRadius * 1.65);
    ctx.quadraticCurveTo(headRadius * 0.2, headRadius * 1.0, -headRadius * 0.2, headRadius * 0.7);
    ctx.closePath();
    ctx.fillStyle = '#ef4444';
    ctx.fill();
    ctx.lineWidth = Math.max(2.4, headRadius * 0.1);
    ctx.strokeStyle = '#090d16';
    ctx.stroke();

    // Ivory tip right
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.6, headRadius * 1.3);
    ctx.quadraticCurveTo(headRadius * 0.75, headRadius * 1.45, headRadius * 0.95, headRadius * 1.65);
    ctx.quadraticCurveTo(headRadius * 0.45, headRadius * 1.25, headRadius * 0.35, headRadius * 1.15);
    ctx.closePath();
    ctx.fillStyle = '#fef3c7';
    ctx.fill();

    ctx.restore();
  }

  private drawHalo(headRadius: number) {
    const ctx = this.ctx;
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(-headRadius * 0.45, 0, headRadius * 0.38, headRadius * 0.85, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#fef08a';
    ctx.fill();
    ctx.strokeStyle = '#090d16';
    ctx.lineWidth = Math.max(2.4, headRadius * 0.1);
    ctx.stroke();

    // Little cartoon twinkling stars
    const starAngle = this.animTime * 2;
    const sx = -headRadius * 0.45 + Math.cos(starAngle) * headRadius * 0.35;
    const sy = Math.sin(starAngle) * headRadius * 0.8;
    ctx.beginPath();
    ctx.arc(sx, sy, headRadius * 0.1, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();

    ctx.restore();
  }

  private drawBandana(headRadius: number) {
    const ctx = this.ctx;
    ctx.save();

    // Bandana band across head
    ctx.beginPath();
    ctx.arc(0, 0, headRadius * 1.05, -Math.PI / 2.3, Math.PI / 2.3);
    ctx.lineWidth = headRadius * 0.35;
    ctx.strokeStyle = '#dc2626';
    ctx.stroke();

    // Bold Cartoon Ink Outlines
    ctx.beginPath();
    ctx.arc(0, 0, headRadius * 1.22, -Math.PI / 2.3, Math.PI / 2.3);
    ctx.lineWidth = 2.4;
    ctx.strokeStyle = '#090d16';
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, headRadius * 0.88, -Math.PI / 2.3, Math.PI / 2.3);
    ctx.stroke();

    // Fluttering cartoon ribbons trailing behind
    const wiggle = Math.sin(this.animTime * 12) * headRadius * 0.15;
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.moveTo(-headRadius * 0.8, -headRadius * 0.2);
    ctx.quadraticCurveTo(-headRadius * 1.4, -headRadius * 0.4 + wiggle, -headRadius * 1.8, -headRadius * 0.3 + wiggle);
    ctx.lineTo(-headRadius * 1.7, -headRadius * 0.1 + wiggle);
    ctx.quadraticCurveTo(-headRadius * 1.3, -headRadius * 0.15 + wiggle, -headRadius * 0.8, 0);
    ctx.closePath();
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#090d16';
    ctx.stroke();

    ctx.restore();
  }

  // Owl / Falcon Mask (Wormate.io style character head)
  private drawOwlMask(headRadius: number) {
    const ctx = this.ctx;
    ctx.save();

    // 1. Ear tufts (plumicorns) on top & bottom with inner feather layer
    [-1, 1].forEach((dir) => {
      ctx.save();
      ctx.translate(-headRadius * 0.15, dir * headRadius * 0.72);
      ctx.rotate(dir * 0.45);
      // Outer feather
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(-headRadius * 0.5, dir * headRadius * 0.45);
      ctx.lineTo(headRadius * 0.15, dir * headRadius * 0.15);
      ctx.closePath();
      ctx.fillStyle = '#f59e0b';
      ctx.fill();
      ctx.lineWidth = Math.max(1.8, headRadius * 0.08);
      ctx.strokeStyle = '#78350f';
      ctx.stroke();

      // Inner feather tip
      ctx.beginPath();
      ctx.moveTo(-headRadius * 0.1, dir * headRadius * 0.1);
      ctx.lineTo(-headRadius * 0.45, dir * headRadius * 0.4);
      ctx.lineTo(headRadius * 0.05, dir * headRadius * 0.12);
      ctx.closePath();
      ctx.fillStyle = '#fef08a';
      ctx.fill();
      ctx.restore();
    });

    // 2. Forehead feather plume peak
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.35, -headRadius * 0.25);
    ctx.lineTo(headRadius * 0.55, 0);
    ctx.lineTo(headRadius * 0.35, headRadius * 0.25);
    ctx.closePath();
    ctx.fillStyle = '#ea580c';
    ctx.fill();
    ctx.strokeStyle = '#7c2d12';
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.restore();

    // 3. Golden hooked raptor beak in front between eyes
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.42, -headRadius * 0.22);
    ctx.lineTo(headRadius * 1.25, 0);
    ctx.lineTo(headRadius * 0.42, headRadius * 0.22);
    ctx.closePath();
    ctx.fillStyle = '#f59e0b';
    ctx.fill();
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = Math.max(2.0, headRadius * 0.09);
    ctx.stroke();

    // Beak underside shadow
    ctx.save();
    ctx.clip();
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.42, 0);
    ctx.lineTo(headRadius * 1.25, 0);
    ctx.lineTo(headRadius * 0.42, headRadius * 0.22);
    ctx.closePath();
    ctx.fillStyle = 'rgba(120, 53, 15, 0.35)';
    ctx.fill();
    ctx.restore();

    // Beak glossy ridge shine
    ctx.beginPath();
    ctx.moveTo(headRadius * 0.5, -headRadius * 0.1);
    ctx.lineTo(headRadius * 1.05, -headRadius * 0.02);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = Math.max(1.8, headRadius * 0.06);
    ctx.stroke();

    ctx.restore();
  }

  // Draw Particles
  private drawParticles(particles: Particle[]) {
    const ctx = this.ctx;
    for (const p of particles) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.alpha);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      if (p.sparkle) {
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 10;
      }
      ctx.fill();
      ctx.restore();
    }
  }

  // Draw Floating Combat Texts (HEADSHOT, Double Kill, points)
  private drawFloatingTexts(floatingTexts: FloatingText[]) {
    const ctx = this.ctx;
    for (const t of floatingTexts) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, t.alpha);
      ctx.translate(t.x, t.y);
      ctx.scale(t.scale, t.scale);

      if (t.isHeadshot) {
        // High-impact stylized HEADSHOT Badge
        ctx.font = `900 ${Math.floor(t.size * 1.2)}px Outfit, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        // Glowing border / background banner
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 25;

        ctx.fillStyle = '#ef4444';
        ctx.strokeText(t.text, 0, 0);
        ctx.lineWidth = 6;
        ctx.strokeStyle = '#450a0a';
        ctx.strokeText(t.text, 0, 0);

        ctx.fillStyle = '#fef08a'; // bright gold/yellow
        ctx.fillText(t.text, 0, 0);
      } else if (t.text.startsWith('+')) {
        // Wormate.io style rounded gold points popup (+7, +15, +8, etc.)
        ctx.font = `900 ${Math.floor(t.size * 1.15)}px Outfit, Fredoka, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineWidth = 3.8;
        ctx.strokeStyle = '#140e0a';
        ctx.strokeText(t.text, 0, 0);
        ctx.fillStyle = '#fef08a';
        ctx.shadowColor = 'rgba(250, 204, 21, 0.4)';
        ctx.shadowBlur = 6;
        ctx.fillText(t.text, 0, 0);
      } else {
        ctx.font = `bold ${t.size}px Outfit, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = t.color;
        ctx.shadowBlur = 12;
        ctx.fillStyle = t.color;
        ctx.fillText(t.text, 0, 0);
      }

      ctx.restore();
    }
  }

  // Draw Center Headshot Arena Zone with tactical concentric rings & inward runways
  private drawCenterHeadshotZone(minX: number, maxX: number, minY: number, maxY: number) {
    const ctx = this.ctx;
    const cx = MAP_SIZE / 2;
    const cy = MAP_SIZE / 2;

    // Viewport cull check (radius is ~980px)
    if (cx + 980 < minX || cx - 980 > maxX || cy + 980 < minY || cy - 980 > maxY) {
      return;
    }

    ctx.save();

    // 1. Large Ambient Floor Glow at Center
    const gradient = ctx.createRadialGradient(cx, cy, 50, cx, cy, 920);
    gradient.addColorStop(0, 'rgba(239, 68, 68, 0.22)');
    gradient.addColorStop(0.35, 'rgba(245, 158, 11, 0.12)');
    gradient.addColorStop(0.75, 'rgba(6, 182, 212, 0.05)');
    gradient.addColorStop(1, 'rgba(5, 8, 20, 0)');
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(cx, cy, 920, 0, Math.PI * 2);
    ctx.fill();

    // 2. Outer Tactical Radar Ring (r=860) with spinning dashed accents
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, 860, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
    ctx.lineWidth = 3;
    ctx.setLineDash([20, 14]);
    ctx.lineDashOffset = -this.animTime * 15;
    ctx.stroke();
    ctx.restore();

    // 3. Radial Inward Runway Arrows (8 directions pointing directly to center)
    // Guides players from all directions towards the center headshot core
    const numRunways = 8;
    for (let i = 0; i < numRunways; i++) {
      const angle = (i * Math.PI * 2) / numRunways;
      const cosA = Math.cos(angle);
      const sinA = Math.sin(angle);

      // Draw dashed runway guide line
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx + cosA * 850, cy + sinA * 850);
      ctx.lineTo(cx + cosA * 320, cy + sinA * 320);
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 8]);
      ctx.stroke();
      ctx.restore();

      // Chevrons pointing inward toward the center
      const pulsePhase = (this.animTime * 2 + i * 0.5) % 3;
      for (let c = 0; c < 3; c++) {
        const dist = 760 - c * 130;
        const chevX = cx + cosA * dist;
        const chevY = cy + sinA * dist;

        ctx.save();
        ctx.translate(chevX, chevY);
        ctx.rotate(angle + Math.PI); // Point inward toward center!

        const isHighlight = Math.floor(pulsePhase) === c;
        ctx.strokeStyle = isHighlight ? '#fef08a' : 'rgba(239, 68, 68, 0.65)';
        ctx.lineWidth = isHighlight ? 4 : 2.5;
        if (isHighlight) {
          ctx.shadowColor = '#f59e0b';
          ctx.shadowBlur = 10;
        }

        ctx.beginPath();
        ctx.moveTo(-12, -10);
        ctx.lineTo(0, 0);
        ctx.lineTo(-12, 10);
        ctx.stroke();
        ctx.restore();
      }
    }

    // 4. Middle Tactical Ring (r=520) - Labeled with HEADSHOT ARENA
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, 520, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.75)';
    ctx.lineWidth = 4;
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 15;
    ctx.stroke();
    ctx.restore();

    // Directional Text Badges around the 520px ring
    const labels = [
      { text: '💥 CABEÇADA: O MAIS PRÓXIMO DO CENTRO PERDE! 💥', angle: -Math.PI / 2 },
      { text: '⚠️ ZONA DE RISCO DE CABEÇADA • AFASTE-SE DO MEIO!', angle: 0 },
      { text: '👑 QUEM ESTÁ MAIS LONGE DO CENTRO VENCE O CHOQUE!', angle: Math.PI / 2 },
      { text: '💀 PERIGO • NUNCA DÊ CABEÇADA ESTANDO NO CENTRO!', angle: Math.PI },
    ];

    ctx.save();
    ctx.font = '900 15px Outfit, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (const label of labels) {
      const lx = cx + Math.cos(label.angle) * 520;
      const ly = cy + Math.sin(label.angle) * 520;

      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate(label.angle + Math.PI / 2);

      // Dark badge
      const tw = ctx.measureText(label.text).width;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.beginPath();
      ctx.roundRect(-tw / 2 - 10, -12, tw + 20, 24, 6);
      ctx.fill();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = '#fef08a';
      ctx.fillText(label.text, 0, 0);
      ctx.restore();
    }
    ctx.restore();

    // 5. Inner Combat Ring (r=280) with Crosshair lines
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, 280, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.85)';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Crosshair axes through center
    ctx.beginPath();
    ctx.moveTo(cx - 300, cy);
    ctx.lineTo(cx + 300, cy);
    ctx.moveTo(cx, cy - 300);
    ctx.lineTo(cx, cy + 300);
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    ctx.stroke();
    ctx.restore();

    // 6. Center Bullseye Core (r=110)
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, 110, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(239, 68, 68, 0.35)';
    ctx.fill();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 4;
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 20;
    ctx.stroke();

    // Rotating Core Crosshair
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(this.animTime * 0.8);
    ctx.beginPath();
    ctx.arc(0, 0, 65, 0, Math.PI * 2);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.setLineDash([14, 10]);
    ctx.stroke();

    // Target reticle pips
    ctx.fillStyle = '#fef08a';
    for (let a = 0; a < 4; a++) {
      ctx.fillRect(-2, -65, 4, 12);
      ctx.rotate(Math.PI / 2);
    }
    ctx.restore();

    // Center Crown/Target Skull Text
    ctx.font = '900 15px Outfit, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 15;
    ctx.fillText('💀 CENTRO', cx, cy - 8);
    ctx.font = '900 10px Outfit, sans-serif';
    ctx.fillStyle = '#f87171';
    ctx.fillText('PERDE NA CABEÇADA', cx, cy + 12);

    ctx.restore();
    ctx.restore();
  }

  // Draw Player Tactical Headshot Trajectory Guide (Targeting the Center of the Arena)
  private drawPlayerHeadshotGuide(player: Worm, worms: Worm[]) {
    const ctx = this.ctx;
    const cx = MAP_SIZE / 2;
    const cy = MAP_SIZE / 2;

    const dx = cx - player.x;
    const dy = cy - player.y;
    const distToCenter = Math.hypot(dx, dy);
    const angleToCenter = Math.atan2(dy, dx);

    // Calculate angular offset between where the head points and the center
    let angleDiff = Math.abs(player.angle - angleToCenter);
    while (angleDiff > Math.PI) angleDiff = Math.abs(angleDiff - Math.PI * 2);

    const isFacingCenter = angleDiff < Math.PI / 4; // within 45 degrees
    const isPerfectAlignment = angleDiff < Math.PI / 12; // within 15 degrees

    const headRadius = (player.segments[0]?.radius || 18) * 1.15;
    const guideLength = Math.min(420, Math.max(260, player.speed * 45));

    ctx.save();

    // 1. Forward Trajectory Line & Cutting Corridor from Player Head
    const forwardX = player.x + Math.cos(player.angle) * guideLength;
    const forwardY = player.y + Math.sin(player.angle) * guideLength;

    // Check if an enemy worm is in our forward interception path
    let enemyInPath = false;
    let interceptX = 0;
    let interceptY = 0;

    for (const w of worms) {
      if (w.isDead || w.isPlayer) continue;
      // Check distance from enemy head to our forward ray
      const edx = w.x - player.x;
      const edy = w.y - player.y;
      const enemyDist = Math.hypot(edx, edy);
      if (enemyDist < guideLength + 50) {
        const enemyAngle = Math.atan2(edy, edx);
        let rayAngleDiff = Math.abs(player.angle - enemyAngle);
        while (rayAngleDiff > Math.PI) rayAngleDiff = Math.abs(rayAngleDiff - Math.PI * 2);
        if (rayAngleDiff < 0.35) {
          enemyInPath = true;
          interceptX = w.x;
          interceptY = w.y;
          break;
        }
      }
    }

    if (isFacingCenter) {
      // THE HEAD IS POINTED TOWARDS THE ARENA CENTER!
      // Render Vibrant Flaming Headshot Trajectory Corridor
      ctx.save();

      // Glowing corridor beam
      const beamGrad = ctx.createLinearGradient(player.x, player.y, forwardX, forwardY);
      beamGrad.addColorStop(0, isPerfectAlignment ? 'rgba(239, 68, 68, 0.85)' : 'rgba(245, 158, 11, 0.75)');
      beamGrad.addColorStop(0.7, 'rgba(239, 68, 68, 0.55)');
      beamGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');

      ctx.beginPath();
      ctx.moveTo(player.x, player.y);
      ctx.lineTo(forwardX, forwardY);
      ctx.strokeStyle = beamGrad;
      ctx.lineWidth = isPerfectAlignment ? 5 : 3.5;
      ctx.shadowColor = isPerfectAlignment ? '#ef4444' : '#f59e0b';
      ctx.shadowBlur = 18;
      ctx.stroke();

      // Corridor width brackets (simulates precision cutting zone to decapitate enemy)
      const corridorWidth = headRadius * 1.8;
      const leftAngle = player.angle + Math.PI / 2;
      const lx = Math.cos(leftAngle) * corridorWidth;
      const ly = Math.sin(leftAngle) * corridorWidth;

      ctx.beginPath();
      ctx.moveTo(player.x + lx, player.y + ly);
      ctx.lineTo(forwardX + lx * 0.6, forwardY + ly * 0.6);
      ctx.moveTo(player.x - lx, player.y - ly);
      ctx.lineTo(forwardX - lx * 0.6, forwardY - ly * 0.6);
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.3)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 8]);
      ctx.stroke();
      ctx.restore();

      // Tactical Crosshairs along the corridor (at 100px, 200px, 300px)
      const checkpoints = [110, 210, 310];
      for (let i = 0; i < checkpoints.length; i++) {
        const dist = checkpoints[i];
        if (dist > guideLength) continue;

        const px = player.x + Math.cos(player.angle) * dist;
        const py = player.y + Math.sin(player.angle) * dist;

        ctx.save();
        ctx.translate(px, py);
        ctx.rotate(player.angle);

        // Reticle ring
        ctx.beginPath();
        ctx.arc(0, 0, 12, 0, Math.PI * 2);
        ctx.strokeStyle = isPerfectAlignment ? '#ef4444' : '#f59e0b';
        ctx.lineWidth = 2;
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 10;
        ctx.stroke();

        // Cross pips
        ctx.beginPath();
        ctx.moveTo(-16, 0); ctx.lineTo(-12, 0);
        ctx.moveTo(12, 0); ctx.lineTo(16, 0);
        ctx.moveTo(0, -16); ctx.lineTo(0, -12);
        ctx.moveTo(0, 12); ctx.lineTo(0, 16);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.restore();
      }

      // If an enemy is in the line of fire: SHOW LOCK-ON INTERCEPTION!
      if (enemyInPath) {
        const playerDistToCenter = Math.hypot(player.x - cx, player.y - cy);
        const enemyDistToCenter = Math.hypot(interceptX - cx, interceptY - cy);
        const playerWinsHeadClash = playerDistToCenter > enemyDistToCenter;

        ctx.save();
        ctx.translate(interceptX, interceptY);
        ctx.beginPath();
        ctx.arc(0, 0, 34, 0, Math.PI * 2);
        ctx.strokeStyle = playerWinsHeadClash ? '#10b981' : '#ef4444';
        ctx.lineWidth = 3.5;
        ctx.shadowColor = playerWinsHeadClash ? '#10b981' : '#ef4444';
        ctx.shadowBlur = 25;
        ctx.setLineDash([8, 6]);
        ctx.stroke();

        // Lock Banner
        ctx.font = '900 12px Outfit, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillStyle = playerWinsHeadClash ? '#34d399' : '#f87171';
        ctx.fillText(
          playerWinsHeadClash ? '💥 VANTAGEM! RIVAL ESTÁ MAIS NO CENTRO! 💥' : '⚠️ PERIGO! VOCÊ ESTÁ MAIS PERTO DO MEIO! ⚠️',
          0,
          -42
        );
        ctx.restore();
      }

      // Floating Tactical Banner above the trajectory
      const bannerDist = Math.min(guideLength * 0.65, 180);
      const bx = player.x + Math.cos(player.angle) * bannerDist;
      const by = player.y + Math.sin(player.angle) * bannerDist;

      ctx.save();
      ctx.translate(bx, by);
      ctx.font = '900 12px Outfit, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      const tagText = isPerfectAlignment
        ? '🎯 HEADSHOT CENTRAL • CORTE FATAL! 🎯'
        : '🎯 MIRA DE HEADSHOT (CENTRO)';

      const textW = ctx.measureText(tagText).width;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
      ctx.beginPath();
      ctx.roundRect(-textW / 2 - 8, -12, textW + 16, 24, 12);
      ctx.fill();
      ctx.strokeStyle = isPerfectAlignment ? '#ef4444' : '#f59e0b';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = isPerfectAlignment ? '#fef08a' : '#ffffff';
      ctx.fillText(tagText, 0, 0);
      ctx.restore();

    } else {
      // NOT POINTING AT CENTER: Guide the player to turn their head towards the center!
      // Draw subtle forward sightline
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(player.x, player.y);
      ctx.lineTo(player.x + Math.cos(player.angle) * 140, player.y + Math.sin(player.angle) * 140);
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.restore();

      // Draw Center Vector Arrow around Player's Head (Curved Compass Guide)
      const compassRadius = headRadius * 2.2;
      const arrowX = player.x + Math.cos(angleToCenter) * compassRadius;
      const arrowY = player.y + Math.sin(angleToCenter) * compassRadius;

      ctx.save();
      ctx.translate(arrowX, arrowY);
      ctx.rotate(angleToCenter);

      // Glowing Compass Chevron
      ctx.beginPath();
      ctx.moveTo(-10, -8);
      ctx.lineTo(6, 0);
      ctx.lineTo(-10, 8);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#f59e0b';
      ctx.shadowBlur = 12;
      ctx.stroke();

      // Tiny badge indicating turn to center
      ctx.rotate(-angleToCenter);
      ctx.font = 'bold 10px Outfit, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#fde047';
      ctx.shadowColor = '#000000';
      ctx.shadowBlur = 6;
      ctx.fillText(`➔ CENTRO (${Math.round(distToCenter)}m)`, 0, 16);
      ctx.restore();
    }

    ctx.restore();
  }
}
