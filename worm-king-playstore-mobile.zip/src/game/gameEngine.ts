import {
  Worm,
  Orb,
  PowerUp,
  Particle,
  FloatingText,
  Projectile,
  BattleRoyaleZone,
  GameMode,
  WormSkin,
  LeaderboardEntry,
  GameStats,
} from '../types';
import {
  MAP_SIZE,
  MAX_FOOD_COUNT,
  MAX_POWERUPS_COUNT,
  BOT_COUNT,
  BASE_SPEED,
  BOOST_SPEED,
  ROTATION_SPEED,
  BASE_RADIUS,
  SEGMENT_DISTANCE,
  COLOR_PALETTES,
  SKINS,
  BOT_NAMES,
} from './constants';
import { updateBotAI } from './botAI';
import { sounds } from '../audio/soundEffects';
import { recordMissionProgress, DailyMission } from './dailyMissions';
import { addXpToStats } from './playerLevel';

export class GameEngine {
  public player: Worm | null = null;
  public worms: Worm[] = [];
  public orbs: Orb[] = [];
  public powerUps: PowerUp[] = [];
  public projectiles: Projectile[] = [];
  public particles: Particle[] = [];
  public floatingTexts: FloatingText[] = [];
  public brZone: BattleRoyaleZone | null = null;

  public gameMode: GameMode = 'ffa';
  public isRunning: boolean = false;
  public screenShake: number = 0;
  public comboStreak: number = 0;
  public comboTimer: number = 0;
  public stats: GameStats = {
    gamesPlayed: 0,
    highestScore: 0,
    highestLength: 0,
    totalKills: 0,
    totalHeadshots: 0,
    coins: 0,
    battleRoyaleWins: 0,
  };

  public sessionSurvivalSeconds: number = 0;
  public sessionOrbsEaten: number = 0;
  public onMissionCompletedCallback?: (mission: DailyMission) => void;

  public playerSpeedTier: 2 | 5 | 10 = 2;
  public isPlayerCurvinha: boolean = false;

  private nextOrbId: number = 1;
  private frameCount: number = 0;
  private onGameOverCallback?: (stats: {
    score: number;
    length: number;
    kills: number;
    headshots: number;
    rank: number;
    coinsEarned: number;
    isVictory: boolean;
    deathReason?: 'head_clash_center' | 'body_collision' | 'border_collision' | 'storm';
    xpEarned?: number;
  }) => void;

  constructor() {
    this.loadStats();
  }

  public setGameOverCallback(cb: typeof this.onGameOverCallback) {
    this.onGameOverCallback = cb;
  }

  public setPlayerSpeedTier(tier: 2 | 5 | 10) {
    this.playerSpeedTier = tier;
    if (this.player && !this.player.isDead) {
      this.player.speedMultiplier = tier;
    }
  }

  public createDriftPuffs(x: number, y: number, angle: number, color: string) {
    for (let i = 0; i < 2; i++) {
      const offsetAngle = angle + Math.PI + (Math.random() - 0.5) * 1.2;
      const speed = 1.8 + Math.random() * 2.8;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 10,
        y: y + (Math.random() - 0.5) * 10,
        vx: Math.cos(offsetAngle) * speed,
        vy: Math.sin(offsetAngle) * speed,
        radius: 5.5 + Math.random() * 4.5,
        color: Math.random() > 0.4 ? '#ffffff' : color,
        alpha: 0.9,
        decay: 0.04 + Math.random() * 0.03,
        sparkle: Math.random() > 0.6,
        type: 'smoke',
        rotation: Math.random() * Math.PI * 2,
        scale: 1.0,
      });
    }
  }

  public createBoostPuffs(x: number, y: number, angle: number, color: string, isSuper: boolean = false) {
    const puffCount = isSuper ? 2 : 1;
    for (let i = 0; i < puffCount; i++) {
      const offsetAngle = angle + Math.PI + (Math.random() - 0.5) * 0.9;
      const speed = 1.2 + Math.random() * 2.4;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 8,
        y: y + (Math.random() - 0.5) * 8,
        vx: Math.cos(offsetAngle) * speed,
        vy: Math.sin(offsetAngle) * speed,
        radius: isSuper ? 7 + Math.random() * 5 : 4.5 + Math.random() * 4,
        color: Math.random() > 0.35 ? '#ffffff' : color,
        alpha: 0.85,
        decay: 0.038 + Math.random() * 0.03,
        sparkle: isSuper,
        type: isSuper && Math.random() > 0.6 ? 'star' : 'smoke',
        rotation: Math.random() * Math.PI * 2,
        scale: 1.0,
      });
    }
  }

  public setMissionCompletedCallback(cb: typeof this.onMissionCompletedCallback) {
    this.onMissionCompletedCallback = cb;
  }

  public notifyMissionCompleted(mission: DailyMission) {
    sounds.playVictory();
    if (this.player && !this.player.isDead) {
      this.floatingTexts.push({
        id: `mission-${Math.random()}`,
        text: `🎯 MISSÃO: ${mission.titlePt}! +${mission.rewardCoins} 🪙`,
        x: this.player.x,
        y: this.player.y - 75,
        vy: -1.4,
        color: '#fbbf24',
        size: 26,
        alpha: 1,
        scale: 1.15,
      });
    }
    this.onMissionCompletedCallback?.(mission);
  }

  private loadStats() {
    try {
      const saved = localStorage.getItem('wormking_stats') || localStorage.getItem('wormzilla_stats');
      if (saved) {
        this.stats = { ...this.stats, ...JSON.parse(saved) };
      }
    } catch {
      // ignore
    }
  }

  public saveStats() {
    try {
      localStorage.setItem('wormking_stats', JSON.stringify(this.stats));
    } catch {
      // ignore
    }
  }

  public startNewGame(nickname: string, skin: WormSkin, mode: GameMode) {
    this.gameMode = mode;
    this.worms = [];
    this.orbs = [];
    this.powerUps = [];
    this.projectiles = [];
    this.particles = [];
    this.floatingTexts = [];
    this.screenShake = 0;
    this.comboStreak = 0;
    this.comboTimer = 0;
    this.frameCount = 0;

    // 1. Initialize Battle Royale Zone if needed
    if (mode === 'battle_royale') {
      this.brZone = {
        centerX: MAP_SIZE / 2,
        centerY: MAP_SIZE / 2,
        radius: MAP_SIZE * 0.48,
        targetRadius: MAP_SIZE * 0.15,
        shrinkSpeed: 0.65,
        damageRate: 1.2,
        phase: 1,
        timer: 120, // 2 minutes total shrink
      };
    } else {
      this.brZone = null;
    }

    // 2. Spawn initial food orbs
    this.spawnFoodOrbs(MAX_FOOD_COUNT);

    // 3. Spawn initial power-ups
    for (let i = 0; i < MAX_POWERUPS_COUNT; i++) {
      this.spawnPowerUp();
    }

    // 4. Spawn Player in center or safe location
    const playerSpawnX = mode === 'battle_royale' ? MAP_SIZE / 2 + (Math.random() - 0.5) * 600 : MAP_SIZE / 2;
    const playerSpawnY = mode === 'battle_royale' ? MAP_SIZE / 2 + (Math.random() - 0.5) * 600 : MAP_SIZE / 2;

    this.player = this.createWorm(
      'player-1',
      nickname.trim() || 'WormKing',
      true,
      skin,
      playerSpawnX,
      playerSpawnY,
      120
    );
    this.worms.push(this.player);

    // 5. Spawn Bots
    const botCount = mode === 'battle_royale' ? 24 : BOT_COUNT;
    for (let i = 0; i < botCount; i++) {
      this.spawnBot();
    }

    this.sessionSurvivalSeconds = 0;
    this.sessionOrbsEaten = 0;
    this.isRunning = true;
    this.stats.gamesPlayed++;
    this.saveStats();

    // Track matches mission progress
    const { newlyCompleted } = recordMissionProgress('matches', 1);
    for (const m of newlyCompleted) {
      this.notifyMissionCompleted(m);
    }
  }

  // Create a worm instance
  private createWorm(
    id: string,
    name: string,
    isPlayer: boolean,
    skin: WormSkin,
    x: number,
    y: number,
    initialMass: number
  ): Worm {
    const angle = Math.random() * Math.PI * 2;
    const segmentsCount = Math.floor(initialMass / 5) + 12;
    const segments = [];

    for (let i = 0; i < segmentsCount; i++) {
      segments.push({
        x: x - Math.cos(angle) * i * SEGMENT_DISTANCE,
        y: y - Math.sin(angle) * i * SEGMENT_DISTANCE,
        radius: BASE_RADIUS,
      });
    }

    return {
      id,
      name,
      isPlayer,
      skin,
      segments,
      x,
      y,
      angle,
      targetAngle: angle,
      speed: BASE_SPEED,
      baseSpeed: BASE_SPEED,
      boostSpeed: BOOST_SPEED,
      isBoosting: false,
      length: segmentsCount,
      mass: initialMass,
      score: 0,
      kills: 0,
      headshots: 0,
      isDead: false,
      activePowerUps: {
        magnet: 0,
        curvinha: 0,
        multiplier: 0,
        plasma: 0,
        speed_x10: 0,
      },
      aiAggressiveness: 0.3 + Math.random() * 0.6,
      aiTurnTimer: 0,
      aiBoostTimer: 0,
    };
  }

  private spawnBot() {
    const randomSkin = SKINS[Math.floor(Math.random() * SKINS.length)];
    const randomName = BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)] + (Math.random() > 0.6 ? Math.floor(Math.random() * 99) : '');

    let spawnX = 200 + Math.random() * (MAP_SIZE - 400);
    let spawnY = 200 + Math.random() * (MAP_SIZE - 400);

    // If Battle Royale, spawn inside initial storm
    if (this.gameMode === 'battle_royale' && this.brZone) {
      const angle = Math.random() * Math.PI * 2;
      const r = Math.random() * (this.brZone.radius - 200);
      spawnX = this.brZone.centerX + Math.cos(angle) * r;
      spawnY = this.brZone.centerY + Math.sin(angle) * r;
    }

    // Varied starting mass for bots
    const mass = 80 + Math.floor(Math.random() * 250);
    const bot = this.createWorm(
      `bot-${Math.random().toString(36).substr(2, 9)}`,
      randomName,
      false,
      randomSkin,
      spawnX,
      spawnY,
      mass
    );

    this.worms.push(bot);
  }

  private spawnFoodOrbs(count: number) {
    const foodTypes: NonNullable<Orb['foodType']>[] = [
      'donut',
      'candy',
      'cupcake',
      'burger',
      'apple',
      'pizza',
      'star',
      'watermelon',
      'strawberry',
      'lollipop',
      'icecream',
      'cookie',
      'cherry',
      'cake',
      'croissant',
    ];
    for (let i = 0; i < count; i++) {
      const color = COLOR_PALETTES[Math.floor(Math.random() * COLOR_PALETTES.length)];
      const foodType = foodTypes[Math.floor(Math.random() * foodTypes.length)];
      this.orbs.push({
        id: this.nextOrbId++,
        x: 40 + Math.random() * (MAP_SIZE - 80),
        y: 40 + Math.random() * (MAP_SIZE - 80),
        radius: 5.5 + Math.random() * 4,
        color,
        value: 1,
        glowColor: color,
        foodType,
      });
    }
  }

  private spawnPowerUp() {
    const types: PowerUp['type'][] = ['magnet', 'curvinha', 'multiplier', 'plasma', 'speed_x10'];
    const type = types[Math.floor(Math.random() * types.length)];
    this.powerUps.push({
      id: `pw-${Math.random().toString(36).substr(2, 9)}`,
      type,
      x: 300 + Math.random() * (MAP_SIZE - 600),
      y: 300 + Math.random() * (MAP_SIZE - 600),
      radius: 22,
      pulse: Math.random() * Math.PI * 2,
      duration: type === 'curvinha' ? 10 : type === 'speed_x10' ? 8 : type === 'multiplier' ? 12 : type === 'magnet' ? 10 : 8,
    });
  }

  // Update Game Physics & Collisions with ultra-sensitive responsive steering
  public update(
    pointerAngle: number,
    isPlayerBoosting: boolean,
    isPlayerCurvinha: boolean = false,
    speedTier?: 2 | 5 | 10,
    sensitivityMultiplier: number = 1.5
  ) {
    if (!this.isRunning) return;

    if (speedTier && [2, 5, 10].includes(speedTier)) {
      this.playerSpeedTier = speedTier;
    }

    this.frameCount++;
    if (this.screenShake > 0) {
      this.screenShake = Math.max(0, this.screenShake - 0.05);
    }

    // Combo timer decay
    if (this.comboTimer > 0) {
      this.comboTimer -= 1 / 60;
      if (this.comboTimer <= 0) {
        this.comboStreak = 0;
      }
    }

    // Update Battle Royale storm
    if (this.gameMode === 'battle_royale' && this.brZone) {
      if (this.brZone.radius > this.brZone.targetRadius) {
        this.brZone.radius -= this.brZone.shrinkSpeed;
      }
      this.brZone.timer = Math.max(0, this.brZone.timer - 1 / 60);
    }

    // 1. Update Player Controls & Survival Time
    if (this.player && !this.player.isDead) {
      // Survival time tracking (1 tick per second approx)
      if (this.frameCount % 60 === 0) {
        this.sessionSurvivalSeconds += 1;
        const { newlyCompleted } = recordMissionProgress('survive_time', this.sessionSurvivalSeconds, true);
        for (const m of newlyCompleted) {
          this.notifyMissionCompleted(m);
        }
      }

      this.isPlayerCurvinha = isPlayerCurvinha || (this.player.activePowerUps.curvinha > 0);
      this.player.isCurvinha = this.isPlayerCurvinha;
      this.player.speedMultiplier = this.player.activePowerUps.speed_x10 > 0 ? 10 : this.playerSpeedTier;

      // Steer player smoothly towards target angle with dynamic responsiveness
      let diff = pointerAngle - this.player.angle;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;

      const absDiff = Math.abs(diff);
      // Adaptive dynamic turn responsiveness: accelerates turn rate on wider angles to eliminate steering lag
      const adaptiveTurnFactor = 1.0 + Math.min(1.5, absDiff * 1.1);
      
      // Curvinha allows razor-sharp instant pivot turns; boosting and normal turns are crisp and immediate
      const baseTurnMult = this.isPlayerCurvinha
        ? 4.5
        : (isPlayerBoosting ? 1.4 : 1.2) * adaptiveTurnFactor;
      const turnSpeed = ROTATION_SPEED * baseTurnMult * sensitivityMultiplier;
      
      this.player.angle += Math.sign(diff) * Math.min(absDiff, turnSpeed);
      this.player.targetAngle = pointerAngle;

      // Spawn cartoon drift particles when executing a curvinha
      if (this.isPlayerCurvinha && absDiff > 0.08 && this.frameCount % 2 === 0) {
        this.createDriftPuffs(this.player.x, this.player.y, this.player.angle, this.player.skin.accentColor);
      }

      const canBoost = isPlayerBoosting && this.player.mass > 40;
      if (canBoost !== this.player.isBoosting) {
        this.player.isBoosting = canBoost;
        if (canBoost) {
          sounds.startBoostSound();
        } else {
          sounds.stopBoostSound();
        }
      }
    }

    // 2. Update Bots AI
    for (const worm of this.worms) {
      if (worm.isPlayer || worm.isDead) continue;
      updateBotAI(worm, this.worms, this.orbs, this.powerUps, this.brZone, this.gameMode === 'battle_royale');
    }

    // 3. Move All Worms & Segments
    for (const worm of this.worms) {
      if (worm.isDead) {
        if (worm.deadAlpha !== undefined && worm.deadAlpha > 0) {
          worm.deadAlpha -= 0.04;
        }
        continue;
      }

      // Update active powerups countdown
      for (const key of Object.keys(worm.activePowerUps) as Array<keyof typeof worm.activePowerUps>) {
        if (worm.activePowerUps[key] > 0) {
          worm.activePowerUps[key] = Math.max(0, worm.activePowerUps[key] - 1 / 60);
        }
      }

      // Dynamic Speed & Multipliers (X2, X5, X10)
      const multiplier = worm.isPlayer
        ? (worm.activePowerUps.speed_x10 > 0 ? 10 : (this.playerSpeedTier || 2))
        : 2;
      const targetBoostSpeed = worm.baseSpeed * multiplier;
      const targetSpeed = worm.isBoosting ? targetBoostSpeed : worm.baseSpeed;

      // High acceleration responsiveness for swift speed tier feel
      const accelRate = worm.isBoosting
        ? (multiplier >= 10 ? 0.38 : multiplier >= 5 ? 0.28 : 0.22)
        : 0.12;
      worm.speed += (targetSpeed - worm.speed) * accelRate;

      worm.x += Math.cos(worm.angle) * worm.speed;
      worm.y += Math.sin(worm.angle) * worm.speed;

      // Boosting mass consumption & delicious comidinhas trail
      const dropInterval = multiplier >= 10 ? 4 : 5;
      if (worm.isBoosting && this.frameCount % dropInterval === 0 && worm.mass > 30) {
        worm.mass -= 1;
        // Drop cute mini treat orb behind tail
        const tail = worm.segments[worm.segments.length - 1];
        if (tail) {
          const miniTreats: NonNullable<Orb['foodType']>[] = ['candy', 'cherry', 'strawberry', 'cookie'];
          this.orbs.push({
            id: this.nextOrbId++,
            x: tail.x + (Math.random() - 0.5) * 10,
            y: tail.y + (Math.random() - 0.5) * 10,
            radius: 4.8,
            color: worm.skin.accentColor,
            value: 1,
            glowColor: worm.skin.primaryColor,
            foodType: miniTreats[Math.floor(Math.random() * miniTreats.length)],
          });
        }
      }

      // Spawn cartoon puff clouds behind tail when boosting
      if (worm.isBoosting && this.frameCount % (multiplier >= 10 ? 2 : 3) === 0) {
        const tail = worm.segments[worm.segments.length - 1] || { x: worm.x, y: worm.y };
        this.createBoostPuffs(tail.x, tail.y, worm.angle, worm.skin.primaryColor, multiplier >= 5);
      }

      // Calculate segment radius based on mass
      const segRadius = BASE_RADIUS + Math.min(24, Math.log10(Math.max(1, worm.mass / 100)) * 7);

      // Spine kinematics: First segment is head
      if (worm.segments.length === 0) {
        worm.segments.push({ x: worm.x, y: worm.y, radius: segRadius });
      } else {
        worm.segments[0].x = worm.x;
        worm.segments[0].y = worm.y;
        worm.segments[0].radius = segRadius;
      }

      // Pull succeeding segments
      for (let i = 1; i < worm.segments.length; i++) {
        const prev = worm.segments[i - 1];
        const curr = worm.segments[i];
        const dx = prev.x - curr.x;
        const dy = prev.y - curr.y;
        const dist = Math.hypot(dx, dy);

        if (dist > SEGMENT_DISTANCE) {
          const moveRatio = (dist - SEGMENT_DISTANCE) / dist;
          curr.x += dx * moveRatio;
          curr.y += dy * moveRatio;
        }
        curr.radius = segRadius;
      }

      // Desired segments based on mass
      const desiredSegments = Math.floor(worm.mass / 6) + 12;
      while (worm.segments.length < desiredSegments) {
        const last = worm.segments[worm.segments.length - 1];
        worm.segments.push({ x: last.x, y: last.y, radius: segRadius });
      }
      while (worm.segments.length > desiredSegments && worm.segments.length > 8) {
        worm.segments.pop();
      }
      worm.length = worm.segments.length;

      // Storm damage in Battle Royale
      if (this.gameMode === 'battle_royale' && this.brZone) {
        const distToCenter = Math.hypot(worm.x - this.brZone.centerX, worm.y - this.brZone.centerY);
        if (distToCenter > this.brZone.radius) {
          worm.mass -= this.brZone.damageRate;
          if (worm.isPlayer) {
            this.screenShake = Math.max(this.screenShake, 0.1);
          }
          if (worm.mass <= 10) {
            this.killWorm(worm, null, false);
            continue;
          }
        }
      }

      // Wall collision
      if (worm.x < 15 || worm.x > MAP_SIZE - 15 || worm.y < 15 || worm.y > MAP_SIZE - 15) {
        this.killWorm(worm, null, false);
        continue;
      }
    }

    // 4. Projectiles Update
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const proj = this.projectiles[i];
      proj.x += proj.vx;
      proj.y += proj.vy;
      proj.life--;

      // Check hit against worms
      let hit = false;
      for (const worm of this.worms) {
        if (worm.isDead || worm.id === proj.ownerId) continue;
        const d = Math.hypot(worm.x - proj.x, worm.y - proj.y);
        if (d < BASE_RADIUS * 2) {
          // Hit worm!
          worm.mass = Math.max(20, worm.mass - 45);
          hit = true;
          this.createExplosion(proj.x, proj.y, proj.color, 12);
          break;
        }
      }

      if (hit || proj.life <= 0) {
        this.projectiles.splice(i, 1);
      }
    }

    // 5. Food Orbs & Magnet Consumption
    this.updateOrbs();

    // 6. Power-Up Collisions
    this.updatePowerUps();

    // 7. Worm vs Worm Collisions (The core HEADSHOT mechanic!)
    this.checkWormCollisions();

    // 8. Update Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vx *= 0.94;
      p.vy *= 0.94;
      p.alpha -= p.decay;
      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
      }
    }

    // 9. Update Floating Texts
    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
      const t = this.floatingTexts[i];
      t.y += t.vy;
      t.alpha -= 0.016;
      t.scale = Math.min(1.2, t.scale + 0.02);
      if (t.alpha <= 0) {
        this.floatingTexts.splice(i, 1);
      }
    }

    // 10. Respawn food orbs & bots in FFA mode
    if (this.gameMode !== 'battle_royale') {
      if (this.orbs.length < MAX_FOOD_COUNT * 0.8) {
        this.spawnFoodOrbs(MAX_FOOD_COUNT - this.orbs.length);
      }
      const aliveBots = this.worms.filter((w) => !w.isPlayer && !w.isDead).length;
      if (aliveBots < BOT_COUNT) {
        this.spawnBot();
      }
    }

    // Clean dead worms that have faded away
    this.worms = this.worms.filter((w) => !w.isDead || (w.deadAlpha !== undefined && w.deadAlpha > 0));

    // Check Victory Royale in Battle Royale mode
    if (this.gameMode === 'battle_royale' && this.player && !this.player.isDead) {
      const aliveCount = this.worms.filter((w) => !w.isDead).length;
      if (aliveCount === 1) {
        this.triggerVictoryRoyale();
      }
    }
  }

  // Shoot Plasma Projectile (Wormzilla power)
  public firePlasma(worm: Worm) {
    if (worm.isDead) return;
    const speed = 16;
    const vx = Math.cos(worm.angle) * speed;
    const vy = Math.sin(worm.angle) * speed;

    this.projectiles.push({
      id: `p-${Math.random()}`,
      x: worm.x + Math.cos(worm.angle) * 35,
      y: worm.y + Math.sin(worm.angle) * 35,
      vx,
      vy,
      radius: 9,
      ownerId: worm.id,
      color: worm.skin.accentColor,
      life: 60,
    });

    if (worm.isPlayer) {
      sounds.playPlasmaShot();
    }
  }

  // Orbs & Magnet (High Performance Engine: AABB rejection + distSq + batch removal)
  private updateOrbs() {
    if (this.orbs.length === 0 || this.worms.length === 0) return;

    const eatenOrbIds = new Set<number>();

    for (let w = 0; w < this.worms.length; w++) {
      const worm = this.worms[w];
      if (worm.isDead) continue;
      const headRadius = worm.segments[0]?.radius || BASE_RADIUS;
      const isMagnet = worm.activePowerUps.magnet > 0;
      const magnetRadius = isMagnet ? 300 : headRadius + 18;
      const magnetRadiusSq = magnetRadius * magnetRadius;
      const has2x = worm.activePowerUps.multiplier > 0;
      const pullSpeed = isMagnet ? 14 : 7;
      const isPlayer = worm.isPlayer;

      const wx = worm.x;
      const wy = worm.y;

      for (let i = 0; i < this.orbs.length; i++) {
        const orb = this.orbs[i];
        if (eatenOrbIds.has(orb.id)) continue;

        // Fast Bounding Box (AABB) rejection - eliminates 99.5% of checks in 2 clock cycles
        const dx = orb.x - wx;
        if (dx > magnetRadius || dx < -magnetRadius) continue;
        const dy = orb.y - wy;
        if (dy > magnetRadius || dy < -magnetRadius) continue;

        // Distance squared check (avoids costly Math.hypot/sqrt)
        const distSq = dx * dx + dy * dy;
        if (distSq > magnetRadiusSq) continue;

        const dist = Math.sqrt(distSq) || 1;
        const eatRadius = headRadius + orb.radius;

        // Magnetic Attraction
        if (dist > eatRadius) {
          orb.x -= (dx / dist) * pullSpeed;
          orb.y -= (dy / dist) * pullSpeed;
        } else {
          // Eat Orb
          eatenOrbIds.add(orb.id);
          const multiplier = has2x ? 2 : 1;
          const points = orb.value * multiplier;

          worm.mass += points;
          worm.score += points * 10;

          if (isPlayer) {
            sounds.playEatOrb(orb.value);
            this.sessionOrbsEaten++;
            const { newlyCompleted } = recordMissionProgress('orbs', 1);
            for (const m of newlyCompleted) {
              this.notifyMissionCompleted(m);
            }

            // Small XP for eating doces (1 to 4 XP)
            const orbXp = orb.value >= 4 ? 4 : 1;
            this.stats.xp = (this.stats.xp || 0) + orbXp;

            // Wormate.io floating points text (+7, +15, +8, etc.)
            if (this.frameCount % 2 === 0 || orb.value >= 3) {
              const displayVal = points >= 5 ? points * 3 : (points === 1 ? (Math.random() > 0.5 ? 7 : 8) : points * 3);
              this.floatingTexts.push({
                id: `orb-${Math.random()}`,
                text: `+${displayVal}`,
                x: orb.x + (Math.random() - 0.5) * 12,
                y: orb.y - 6,
                vy: -1.2,
                color: '#fef08a',
                size: points >= 4 ? 20 : 16,
                alpha: 0.95,
                scale: 0.88,
              });
            }
          }
        }
      }
    }

    // Single-pass batch filter for eaten orbs (eliminates repeated array splice shifts)
    if (eatenOrbIds.size > 0) {
      this.orbs = this.orbs.filter((o) => !eatenOrbIds.has(o.id));
    }
  }

  // Power-Ups
  private updatePowerUps() {
    for (const p of this.powerUps) {
      p.pulse += 0.05;
    }

    for (const worm of this.worms) {
      if (worm.isDead) continue;
      const headRadius = worm.segments[0]?.radius || BASE_RADIUS;

      for (let i = this.powerUps.length - 1; i >= 0; i--) {
        const p = this.powerUps[i];
        const dist = Math.hypot(worm.x - p.x, worm.y - p.y);

        if (dist < headRadius + p.radius) {
          // Collect power-up!
          worm.activePowerUps[p.type] = p.duration;

          if (worm.isPlayer) {
            sounds.playPowerUp();
            let label = 'POWER UP!';
            if (p.type === 'magnet') label = '🧲 SUPER ÍMÃ!';
            if (p.type === 'curvinha') label = '🌀 SUPER CURVINHA!';
            if (p.type === 'speed_x10') label = '🚀 HIPER VELOCIDADE 10X!';
            if (p.type === 'multiplier') label = '⭐ 2X PONTOS!';
            if (p.type === 'plasma') label = '💥 CANHÃO DE PLASMA!';

            this.floatingTexts.push({
              id: `ft-${Math.random()}`,
              text: label,
              x: worm.x,
              y: worm.y - 45,
              vy: -1.4,
              color: '#38bdf8',
              size: 20,
              alpha: 1,
              scale: 1.0,
            });
          }

          this.createExplosion(p.x, p.y, '#38bdf8', 18);
          this.powerUps.splice(i, 1);

          // Respawn powerup elsewhere after delay
          setTimeout(() => {
            if (this.isRunning && this.powerUps.length < MAX_POWERUPS_COUNT) {
              this.spawnPowerUp();
            }
          }, 8000);
        }
      }
    }
  }

  // The CORE WORM COLLISION & HEADSHOT / HEAD CLASH MECHANIC
  private checkWormCollisions() {
    const centerX = MAP_SIZE / 2;
    const centerY = MAP_SIZE / 2;

    // 1. HEAD-TO-HEAD CLASHES (CABEÇADA)
    // REGRA DE OURO WORMZILLA: A cobrinha que estiver mais próxima do meio perde se tomar cabeçada!
    for (let i = 0; i < this.worms.length; i++) {
      const wormA = this.worms[i];
      if (wormA.isDead) continue;
      const headA = wormA.segments[0];
      if (!headA) continue;

      for (let j = i + 1; j < this.worms.length; j++) {
        const wormB = this.worms[j];
        if (wormB.isDead) continue;
        const headB = wormB.segments[0];
        if (!headB) continue;

        const headCollisionDist = (headA.radius * 0.88) + (headB.radius * 0.88);
        const dx = headA.x - headB.x;
        if (dx > headCollisionDist || dx < -headCollisionDist) continue;
        const dy = headA.y - headB.y;
        if (dy > headCollisionDist || dy < -headCollisionDist) continue;

        const headDistSq = dx * dx + dy * dy;
        if (headDistSq < headCollisionDist * headCollisionDist) {
          // CABEÇADA DETECTADA!
          const distA = Math.hypot(headA.x - centerX, headA.y - centerY);
          const distB = Math.hypot(headB.x - centerX, headB.y - centerY);

          if (distA < distB) {
            // wormA está mais próxima do meio -> wormA perde e morre!
            this.killWorm(wormA, wormB, true, true);
          } else if (distB < distA) {
            // wormB está mais próxima do meio -> wormB perde e morre!
            this.killWorm(wormB, wormA, true, true);
          } else {
            // Empate exato de distância: quem tem menor massa perde
            if (wormA.mass <= wormB.mass) {
              this.killWorm(wormA, wormB, true, true);
            } else {
              this.killWorm(wormB, wormA, true, true);
            }
          }
        }
      }
    }

    // 2. HEAD vs BODY SEGMENT COLLISIONS (Corte clássico de Wormzilla)
    for (let i = 0; i < this.worms.length; i++) {
      const victim = this.worms[i];
      if (victim.isDead) continue;
      const victimHead = victim.segments[0];
      if (!victimHead) continue;

      const vhx = victimHead.x;
      const vhy = victimHead.y;
      const vhr = victimHead.radius;

      for (let j = 0; j < this.worms.length; j++) {
        const other = this.worms[j];
        if (other.isDead || other.id === victim.id) continue;

        // Bounding box rejection: approximate max reach of other worm's body
        const maxOtherReach = other.segments.length * SEGMENT_DISTANCE + 80;
        if (Math.abs(vhx - other.x) > maxOtherReach || Math.abs(vhy - other.y) > maxOtherReach) {
          continue;
        }

        // Check victim head against other worm's body segments (from index 1 to end)
        for (let s = 1; s < other.segments.length; s++) {
          const seg = other.segments[s];
          const collisionDist = (vhr * 0.85) + (seg.radius * 0.85);

          const dx = vhx - seg.x;
          if (dx > collisionDist || dx < -collisionDist) continue;
          const dy = vhy - seg.y;
          if (dy > collisionDist || dy < -collisionDist) continue;

          const distSq = dx * dx + dy * dy;
          if (distSq < collisionDist * collisionDist) {
            // CRASH! Victim crashes into other worm's body!
            // Headshot is STRICTLY when cutting right at the neck (segment 1 or 2).
            const isHeadshot = s <= 2;

            this.killWorm(victim, other, isHeadshot, false);
            break;
          }
        }

        if (victim.isDead) break;
      }
    }
  }

  // Kill Worm & Distribute High-Value Orbs + Headshot Rewards
  private killWorm(victim: Worm, killer: Worm | null, isHeadshot: boolean, isHeadClash: boolean = false) {
    if (victim.isDead) return;
    victim.isDead = true;
    victim.deadAlpha = 1.0;

    // Explode into delicious cartoon treats & glowing mass orbs along segments
    const foodTypes: NonNullable<Orb['foodType']>[] = [
      'donut',
      'candy',
      'cupcake',
      'burger',
      'apple',
      'pizza',
      'star',
      'watermelon',
      'strawberry',
      'lollipop',
      'icecream',
      'cookie',
      'cherry',
      'cake',
      'croissant',
    ];
    for (let i = 0; i < victim.segments.length; i += 2) {
      const seg = victim.segments[i];
      const foodType = foodTypes[i % foodTypes.length];
      this.orbs.push({
        id: this.nextOrbId++,
        x: seg.x + (Math.random() - 0.5) * 18,
        y: seg.y + (Math.random() - 0.5) * 18,
        radius: 7.0 + Math.random() * 5.0,
        color: victim.skin.primaryColor,
        value: 5 + Math.floor(Math.random() * 6),
        glowColor: victim.skin.accentColor,
        foodType,
      });
    }

    // Spawn sparks explosion
    this.createExplosion(victim.x, victim.y, victim.skin.accentColor, 40);

    // If Killer exists
    if (killer && !killer.isDead) {
      killer.kills++;
      const bonusScore = isHeadClash ? 2500 : isHeadshot ? 1500 : 750;
      killer.score += bonusScore;
      killer.mass += Math.floor(victim.mass * 0.3);

      if (isHeadshot || isHeadClash) {
        killer.headshots++;
      }

      // If Player is the killer
      if (killer.isPlayer) {
        this.comboStreak++;
        this.comboTimer = 3.5; // 3.5 seconds to chain combos

        if (isHeadClash) {
          sounds.playHeadshot();
          this.screenShake = 0.95;

          this.floatingTexts.push({
            id: `hc-${Math.random()}`,
            text: '💥 CABEÇADA VENCIDA! RIVAL NO MEIO! +2500',
            x: victim.x,
            y: victim.y - 55,
            vy: -1.8,
            color: '#34d399',
            size: 30,
            alpha: 1,
            scale: 0.9,
            isHeadshot: true,
          });
        } else if (isHeadshot) {
          sounds.playHeadshot();
          this.screenShake = 0.85;

          this.floatingTexts.push({
            id: `hs-${Math.random()}`,
            text: '💥 HEADSHOT! +1500',
            x: victim.x,
            y: victim.y - 50,
            vy: -1.8,
            color: '#fef08a',
            size: 32,
            alpha: 1,
            scale: 0.8,
            isHeadshot: true,
          });
        } else {
          sounds.playKill();
          this.screenShake = 0.4;

          this.floatingTexts.push({
            id: `kl-${Math.random()}`,
            text: `⚔️ KILLED ${victim.name}! +750`,
            x: victim.x,
            y: victim.y - 40,
            vy: -1.5,
            color: '#38bdf8',
            size: 22,
            alpha: 1,
            scale: 0.9,
          });
        }

        // Multi-kill announcements
        if (this.comboStreak === 2) {
          this.floatingTexts.push({
            id: `cb-${Math.random()}`,
            text: '⚡ DOUBLE KILL! ⚡',
            x: killer.x,
            y: killer.y - 80,
            vy: -1.2,
            color: '#f97316',
            size: 26,
            alpha: 1,
            scale: 1.0,
          });
        } else if (this.comboStreak >= 3) {
          this.floatingTexts.push({
            id: `cb-${Math.random()}`,
            text: '🔥 UNSTOPPABLE RAMPAGE! 🔥',
            x: killer.x,
            y: killer.y - 80,
            vy: -1.2,
            color: '#ec4899',
            size: 28,
            alpha: 1,
            scale: 1.1,
          });
        }

        // Coins rewarded for kills
        this.stats.coins += isHeadClash ? 35 : isHeadshot ? 25 : 10;
        this.stats.totalKills++;
        if (isHeadshot || isHeadClash) this.stats.totalHeadshots++;

        // XP rewarded for kills (150 normal, 350 headshot, 500 head clash)
        const killXp = isHeadClash ? 500 : isHeadshot ? 350 : 150;
        const xpResult = addXpToStats(this.stats, killXp);
        this.stats = xpResult.stats;

        // Floating XP feedback badge
        this.floatingTexts.push({
          id: `xp-${Math.random()}`,
          text: `+${killXp} XP ${isHeadClash ? '💥' : isHeadshot ? '🎯' : '⭐'}`,
          x: killer.x,
          y: killer.y - 65,
          vy: -1.3,
          color: '#fbbf24',
          size: 19,
          alpha: 1,
          scale: 1.0,
        });

        if (xpResult.leveledUp) {
          sounds.playVictory();
          this.floatingTexts.push({
            id: `lvl-${Math.random()}`,
            text: `🎉 LEVEL UP! NÍVEL ${xpResult.newLevel}! 🎉`,
            x: killer.x,
            y: killer.y - 105,
            vy: -1.0,
            color: '#34d399',
            size: 26,
            alpha: 1,
            scale: 1.15,
          });
        }

        this.saveStats();

        // Track kills daily mission
        const { newlyCompleted: killCompletions } = recordMissionProgress('kills', 1);
        for (const m of killCompletions) {
          this.notifyMissionCompleted(m);
        }

        // Track headshots daily mission if applicable
        if (isHeadshot || isHeadClash) {
          const { newlyCompleted: hsCompletions } = recordMissionProgress('headshots', 1);
          for (const m of hsCompletions) {
            this.notifyMissionCompleted(m);
          }
        }
      }
    }

    // If victim was the player, Game Over!
    if (victim.isPlayer) {
      sounds.stopBoostSound();
      sounds.playDeath();
      this.screenShake = 0.95;

      if (isHeadClash) {
        this.floatingTexts.push({
          id: `hc-death-${Math.random()}`,
          text: '💀 PERDEU NA CABEÇADA! VOCÊ ESTAVA MAIS PERTO DO MEIO!',
          x: victim.x,
          y: victim.y - 60,
          vy: -1.2,
          color: '#f87171',
          size: 26,
          alpha: 1,
          scale: 1.0,
        });
      }

      const earnedCoins = Math.floor(victim.score / 150) + victim.kills * 10 + victim.headshots * 20;
      this.stats.coins += earnedCoins;
      this.stats.highestScore = Math.max(this.stats.highestScore, victim.score);
      this.stats.highestLength = Math.max(this.stats.highestLength, victim.length);

      const sessionXp = Math.floor(victim.score / 10) + victim.kills * 150 + victim.headshots * 200;
      const xpResult = addXpToStats(this.stats, sessionXp);
      this.stats = xpResult.stats;
      this.saveStats();

      // Trigger Game Over screen
      setTimeout(() => {
        const leaderboard = this.getLeaderboard();
        const playerRank = leaderboard.findIndex((e) => e.isPlayer) + 1;
        this.onGameOverCallback?.({
          score: victim.score,
          length: victim.length,
          kills: victim.kills,
          headshots: victim.headshots,
          rank: playerRank > 0 ? playerRank : leaderboard.length + 1,
          coinsEarned: earnedCoins,
          isVictory: false,
          deathReason: isHeadClash ? 'head_clash_center' : (killer ? 'body_collision' : 'border_collision'),
          xpEarned: sessionXp,
        });
      }, 900);
    }
  }

  // Victory Royale in Battle Royale mode
  private triggerVictoryRoyale() {
    if (!this.player || this.player.isDead) return;
    this.isRunning = false;
    sounds.playVictory();

    const earnedCoins = 300 + this.player.kills * 20;
    this.stats.coins += earnedCoins;
    this.stats.battleRoyaleWins++;

    const victoryXp = 1000 + this.player.kills * 150;
    const xpResult = addXpToStats(this.stats, victoryXp);
    this.stats = xpResult.stats;
    this.saveStats();

    this.onGameOverCallback?.({
      score: this.player.score + 5000,
      length: this.player.length,
      kills: this.player.kills,
      headshots: this.player.headshots,
      rank: 1,
      coinsEarned: earnedCoins,
      isVictory: true,
      xpEarned: victoryXp,
    });
  }

  private createExplosion(x: number, y: number, color: string, count: number) {
    // 1. Comic cartoon pop shockwave ring
    this.particles.push({
      x,
      y,
      vx: 0,
      vy: 0,
      radius: 12,
      color: '#ffffff',
      alpha: 1,
      decay: 0.05,
      type: 'pop',
      scale: 1,
    });

    // 2. Cartoon stars and burst particles
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2.5 + Math.random() * 8.5;
      const isStar = Math.random() > 0.45;
      const isSmoke = !isStar && Math.random() > 0.6;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        radius: isStar ? 5 + Math.random() * 5 : isSmoke ? 6 + Math.random() * 4 : 3 + Math.random() * 3,
        color: isSmoke ? '#ffffff' : Math.random() > 0.4 ? '#fde047' : color,
        alpha: 1,
        decay: 0.022 + Math.random() * 0.025,
        sparkle: Math.random() > 0.4,
        type: isStar ? 'star' : isSmoke ? 'smoke' : undefined,
        rotation: Math.random() * Math.PI * 2,
        scale: 1,
      });
    }
  }

  public getLeaderboard(): LeaderboardEntry[] {
    const list = this.worms
      .filter((w) => !w.isDead)
      .map((w) => ({
        id: w.id,
        name: w.name,
        score: w.score,
        length: w.length,
        kills: w.kills,
        isPlayer: w.isPlayer,
        skinColor: w.skin.primaryColor,
      }))
      .sort((a, b) => b.length - a.length);

    return list.slice(0, 10);
  }
}
