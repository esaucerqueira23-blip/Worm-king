import { PlayerBadge, PlayerLevelInfo, GameStats } from '../types';

export const PLAYER_BADGES: PlayerBadge[] = [
  {
    id: 'badge_novice',
    namePt: 'Recruta Verminho',
    nameEn: 'Novice Slither',
    descriptionPt: 'Iniciou a jornada no submundo das minhocas gigantes.',
    descriptionEn: 'Started the journey into the giant worm underground.',
    icon: '🥉',
    unlockLevel: 1,
    tier: 'bronze',
    color: '#cd7f32',
    bgGlow: 'rgba(205, 127, 50, 0.4)',
  },
  {
    id: 'badge_speed',
    namePt: 'Rastejador Veloz',
    nameEn: 'Swift Scout',
    descriptionPt: 'Alcançou o Nível 2 dominando curvas e acelerações.',
    descriptionEn: 'Reached Level 2 mastering turns and accelerations.',
    icon: '⚡',
    unlockLevel: 2,
    tier: 'bronze',
    color: '#38bdf8',
    bgGlow: 'rgba(56, 189, 248, 0.4)',
  },
  {
    id: 'badge_candy',
    namePt: 'Caçador de Doces',
    nameEn: 'Sweet Glutton',
    descriptionPt: 'Alcançou o Nível 3 devorando centenas de donuts e tortas.',
    descriptionEn: 'Reached Level 3 devouring hundreds of donuts and pies.',
    icon: '🍬',
    unlockLevel: 3,
    tier: 'silver',
    color: '#f472b6',
    bgGlow: 'rgba(244, 114, 182, 0.4)',
  },
  {
    id: 'badge_viper',
    namePt: 'Presa Venenosa',
    nameEn: 'Viper Fang',
    descriptionPt: 'Alcançou o Nível 4 eliminando oponentes com cortes letais.',
    descriptionEn: 'Reached Level 4 eliminating opponents with lethal cuts.',
    icon: '🐍',
    unlockLevel: 4,
    tier: 'silver',
    color: '#4ade80',
    bgGlow: 'rgba(74, 222, 128, 0.4)',
  },
  {
    id: 'badge_turbo',
    namePt: 'Mestre do Turbo',
    nameEn: 'Turbo Ace',
    descriptionPt: 'Alcançou o Nível 5 dominando boosts supersônicos 10X.',
    descriptionEn: 'Reached Level 5 mastering 10X supersonic boosts.',
    icon: '🚀',
    unlockLevel: 5,
    tier: 'gold',
    color: '#fbbf24',
    bgGlow: 'rgba(251, 191, 36, 0.4)',
  },
  {
    id: 'badge_headshot',
    namePt: 'Atirador de Headshot',
    nameEn: 'Headshot Marksman',
    descriptionPt: 'Alcançou o Nível 6 acertando cortes milimétricos no pescoço inimigo.',
    descriptionEn: 'Reached Level 6 landing precision cuts directly on enemy necks.',
    icon: '🎯',
    unlockLevel: 6,
    tier: 'gold',
    color: '#f87171',
    bgGlow: 'rgba(248, 113, 113, 0.4)',
  },
  {
    id: 'badge_gladiator',
    namePt: 'Gladiador da Arena',
    nameEn: 'Arena Gladiator',
    descriptionPt: 'Alcançou o Nível 7 sobrevivendo aos confrontos mais sangrentos.',
    descriptionEn: 'Reached Level 7 surviving the bloodiest arena clashes.',
    icon: '⚔️',
    unlockLevel: 7,
    tier: 'emerald',
    color: '#10b981',
    bgGlow: 'rgba(16, 185, 129, 0.4)',
  },
  {
    id: 'badge_predator',
    namePt: 'Predador Sombrio',
    nameEn: 'Shadow Predator',
    descriptionPt: 'Alcançou o Nível 8 caçando os maiores vermes do topo.',
    descriptionEn: 'Reached Level 8 hunting down the biggest worms on top.',
    icon: '🦅',
    unlockLevel: 8,
    tier: 'ruby',
    color: '#e11d48',
    bgGlow: 'rgba(225, 29, 72, 0.4)',
  },
  {
    id: 'badge_behemoth',
    namePt: 'Monstro Titânico',
    nameEn: 'Mythic Behemoth',
    descriptionPt: 'Alcançou o Nível 9 dominando a arena com tamanho colossal.',
    descriptionEn: 'Reached Level 9 dominating the arena with colossal mass.',
    icon: '🐉',
    unlockLevel: 9,
    tier: 'amethyst',
    color: '#a855f7',
    bgGlow: 'rgba(168, 85, 247, 0.4)',
  },
  {
    id: 'badge_king',
    namePt: 'Worm King Supremo',
    nameEn: 'Supreme Worm King',
    descriptionPt: 'Alcançou o Nível 10 e se consagrou a Lenda Suprema do Worm King!',
    descriptionEn: 'Reached Level 10 and was crowned the Supreme Worm King Legend!',
    icon: '👑',
    unlockLevel: 10,
    tier: 'legend',
    color: '#eab308',
    bgGlow: 'rgba(234, 179, 8, 0.6)',
  },
];

// XP required to reach each level (cumulative)
const LEVEL_XP_THRESHOLDS = [
  0,      // Level 1
  500,    // Level 2
  1200,   // Level 3
  2200,   // Level 4
  3500,   // Level 5
  5200,   // Level 6
  7500,   // Level 7
  10500,  // Level 8
  14500,  // Level 9
  20000,  // Level 10
];

const XP_PER_LEVEL_BEYOND_10 = 6000;

export function calculatePlayerLevel(totalXp: number = 0): PlayerLevelInfo {
  let level = 1;
  let currentLevelBaseXp = 0;
  let nextLevelXp = LEVEL_XP_THRESHOLDS[1];

  if (totalXp < LEVEL_XP_THRESHOLDS[1]) {
    level = 1;
    currentLevelBaseXp = 0;
    nextLevelXp = LEVEL_XP_THRESHOLDS[1];
  } else if (totalXp >= LEVEL_XP_THRESHOLDS[LEVEL_XP_THRESHOLDS.length - 1]) {
    // Level 10 or higher
    const extraXp = totalXp - LEVEL_XP_THRESHOLDS[LEVEL_XP_THRESHOLDS.length - 1];
    const extraLevels = Math.floor(extraXp / XP_PER_LEVEL_BEYOND_10);
    level = 10 + extraLevels;
    currentLevelBaseXp = LEVEL_XP_THRESHOLDS[LEVEL_XP_THRESHOLDS.length - 1] + extraLevels * XP_PER_LEVEL_BEYOND_10;
    nextLevelXp = currentLevelBaseXp + XP_PER_LEVEL_BEYOND_10;
  } else {
    for (let i = 0; i < LEVEL_XP_THRESHOLDS.length - 1; i++) {
      if (totalXp >= LEVEL_XP_THRESHOLDS[i] && totalXp < LEVEL_XP_THRESHOLDS[i + 1]) {
        level = i + 1;
        currentLevelBaseXp = LEVEL_XP_THRESHOLDS[i];
        nextLevelXp = LEVEL_XP_THRESHOLDS[i + 1];
        break;
      }
    }
  }

  const xpIntoCurrentLevel = Math.max(0, totalXp - currentLevelBaseXp);
  const xpSpanForLevel = Math.max(1, nextLevelXp - currentLevelBaseXp);
  const levelProgressPct = Math.min(100, Math.round((xpIntoCurrentLevel / xpSpanForLevel) * 100));

  // Determine highest unlocked badge or fallback
  const badgeIdx = Math.min(PLAYER_BADGES.length - 1, level - 1);
  const badge = PLAYER_BADGES[badgeIdx];

  return {
    level,
    titlePt: badge.namePt,
    titleEn: badge.nameEn,
    currentLevelXp: xpIntoCurrentLevel,
    nextLevelXp: xpSpanForLevel,
    levelProgressPct,
    percent: levelProgressPct,
    totalXp,
    badge,
  };
}

export const calculateLevelInfo = calculatePlayerLevel;

export function getBadgeById(id: string): PlayerBadge {
  return PLAYER_BADGES.find((b) => b.id === id) || PLAYER_BADGES[0];
}

export function getEquippedBadgeId(): string {
  return loadEquippedBadge() || 'badge_novice';
}

export function getEquippedBadge(totalXp: number = 0, equippedId?: string): PlayerBadge {
  const currentLevel = calculatePlayerLevel(totalXp).level;
  if (equippedId) {
    const found = PLAYER_BADGES.find((b) => b.id === equippedId);
    if (found && currentLevel >= found.unlockLevel) {
      return found;
    }
  }
  // Default to highest unlocked badge
  const badgeIdx = Math.min(PLAYER_BADGES.length - 1, currentLevel - 1);
  return PLAYER_BADGES[badgeIdx] || PLAYER_BADGES[0];
}

export function saveEquippedBadge(badgeId: string) {
  try {
    localStorage.setItem('wormking_equipped_badge', badgeId);
  } catch {
    // ignore
  }
}

export function loadEquippedBadge(): string | null {
  try {
    return localStorage.getItem('wormking_equipped_badge');
  } catch {
    return null;
  }
}

export function addXpToStats(
  stats: GameStats,
  amount: number
): { stats: GameStats; leveledUp: boolean; newLevel: number; oldLevel: number } {
  const oldXp = stats.xp || 0;
  const oldLevel = calculatePlayerLevel(oldXp).level;

  const newXp = oldXp + amount;
  const newLevel = calculatePlayerLevel(newXp).level;

  const updated: GameStats = {
    ...stats,
    xp: newXp,
  };

  return {
    stats: updated,
    leveledUp: newLevel > oldLevel,
    newLevel,
    oldLevel,
  };
}
