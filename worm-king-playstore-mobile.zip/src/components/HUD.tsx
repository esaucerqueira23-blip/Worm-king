import React, { useEffect, useRef, useMemo, useState } from 'react';
import {
  Worm,
  LeaderboardEntry,
  BattleRoyaleZone,
  GameMode,
} from '../types';
import { MAP_SIZE, TRANSLATIONS } from '../game/constants';
import {
  Trophy,
  Flame,
  Zap,
  Volume2,
  VolumeX,
  Crosshair,
  Crown,
  Users,
  AlertTriangle,
  Radio,
  Gauge,
  Compass,
  Target,
  Gift,
  CheckCircle2,
  Clock,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Award,
} from 'lucide-react';
import { VirtualJoystick } from './VirtualJoystick';
import { DailyMission, loadDailyMissions } from '../game/dailyMissions';
import { GameEngine } from '../game/gameEngine';
import { calculateLevelInfo, getBadgeById } from '../game/playerLevel';
import { SensitivityLevel } from '../game/constants';

interface HUDProps {
  player: Worm | null;
  leaderboard: LeaderboardEntry[];
  allWorms: Worm[];
  brZone: BattleRoyaleZone | null;
  gameMode: GameMode;
  lang: 'pt' | 'en';
  isMuted: boolean;
  onToggleMute: () => void;
  onFirePlasma: () => void;
  isBoosting: boolean;
  onBoostChange: (boosting: boolean) => void;
  isCurvinha?: boolean;
  onToggleCurvinha?: () => void;
  speedTier?: 2 | 5 | 10;
  onSelectSpeedTier?: (tier: 2 | 5 | 10) => void;
  sensitivity?: SensitivityLevel;
  onChangeSensitivity?: (level: SensitivityLevel) => void;
  onJoystickMove?: (angle: number, distance: number) => void;
  onJoystickEnd?: () => void;
  engine?: GameEngine;
}

export const HUD: React.FC<HUDProps> = ({
  player,
  leaderboard,
  allWorms,
  brZone,
  gameMode,
  lang,
  isMuted,
  onToggleMute,
  onFirePlasma,
  isBoosting,
  onBoostChange,
  isCurvinha = false,
  onToggleCurvinha,
  speedTier = 2,
  onSelectSpeedTier,
  sensitivity = 'high',
  onChangeSensitivity,
  onJoystickMove,
  onJoystickEnd,
  engine,
}) => {
  const minimapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const t = TRANSLATIONS[lang];

  // Daily Missions In-Game State
  const [showMissionsCard, setShowMissionsCard] = useState<boolean>(false);
  const [missionsData, setMissionsData] = useState(() => loadDailyMissions());
  const [completionBanner, setCompletionBanner] = useState<DailyMission | null>(null);

  // Sync engine mission completion event
  useEffect(() => {
    if (!engine) return;

    engine.setMissionCompletedCallback((mission) => {
      setMissionsData(loadDailyMissions());
      setCompletionBanner(mission);
      setTimeout(() => {
        setCompletionBanner((curr) => (curr?.id === mission.id ? null : curr));
      }, 4000);
    });
  }, [engine]);

  // Periodic poll of missions state to update progress bars
  useEffect(() => {
    const timer = setInterval(() => {
      setMissionsData(loadDailyMissions());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Minimap rendering
  useEffect(() => {
    const canvas = minimapCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    ctx.clearRect(0, 0, size, size);

    // Background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(0, 0, size, size);

    // Border
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(0, 0, size, size);

    const scale = size / MAP_SIZE;

    // Draw Arena Center Headshot Target on Radar
    const centerMiniX = (MAP_SIZE / 2) * scale;
    const centerMiniY = (MAP_SIZE / 2) * scale;

    ctx.save();
    // Glowing tactical center ring
    ctx.beginPath();
    ctx.arc(centerMiniX, centerMiniY, 14, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(239, 68, 68, 0.28)';
    ctx.fill();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Inner bullseye
    ctx.beginPath();
    ctx.arc(centerMiniX, centerMiniY, 5, 0, Math.PI * 2);
    ctx.fillStyle = '#f59e0b';
    ctx.shadowColor = '#ef4444';
    ctx.shadowBlur = 6;
    ctx.fill();

    // Radar crosshairs
    ctx.beginPath();
    ctx.moveTo(centerMiniX - 18, centerMiniY);
    ctx.lineTo(centerMiniX + 18, centerMiniY);
    ctx.moveTo(centerMiniX, centerMiniY - 18);
    ctx.lineTo(centerMiniX, centerMiniY + 18);
    ctx.strokeStyle = 'rgba(254, 240, 138, 0.5)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();

    // Draw Battle Royale Zone on radar
    if (gameMode === 'battle_royale' && brZone) {
      ctx.save();
      // Toxic danger area
      ctx.beginPath();
      ctx.arc(brZone.centerX * scale, brZone.centerY * scale, brZone.radius * scale, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.8)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Target shrink circle
      ctx.beginPath();
      ctx.arc(brZone.centerX * scale, brZone.centerY * scale, brZone.targetRadius * scale, 0, Math.PI * 2);
      ctx.setLineDash([2, 2]);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.stroke();
      ctx.restore();
    }

    // Draw other worms
    for (const w of allWorms) {
      if (w.isDead || w.isPlayer) continue;
      ctx.beginPath();
      ctx.arc(w.x * scale, w.y * scale, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = '#ef4444'; // red enemy dot
      ctx.fill();
    }

    // Draw #1 Crown leader on map
    if (leaderboard.length > 0) {
      const leader = allWorms.find((w) => w.id === leaderboard[0].id);
      if (leader && !leader.isDead) {
        ctx.beginPath();
        ctx.arc(leader.x * scale, leader.y * scale, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = '#fbbf24';
        ctx.fill();
      }
    }

    // Draw player with glowing beacon and headshot trajectory vector to center
    if (player && !player.isDead) {
      const pMiniX = player.x * scale;
      const pMiniY = player.y * scale;

      // Check alignment to center
      const angleToCenter = Math.atan2(centerMiniY - pMiniY, centerMiniX - pMiniX);
      let angleDiff = Math.abs(player.angle - angleToCenter);
      while (angleDiff > Math.PI) angleDiff = Math.abs(angleDiff - Math.PI * 2);
      const isFacingCenter = angleDiff < Math.PI / 4;

      // Draw dashed trajectory link to arena center
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(pMiniX, pMiniY);
      ctx.lineTo(centerMiniX, centerMiniY);
      if (isFacingCenter) {
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1.8;
        ctx.setLineDash([4, 2]);
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 6;
      } else {
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 3]);
      }
      ctx.stroke();
      ctx.restore();

      // Player radar dot
      ctx.beginPath();
      ctx.arc(pMiniX, pMiniY, 4.5, 0, Math.PI * 2);
      ctx.fillStyle = isFacingCenter ? '#facc15' : '#38bdf8';
      ctx.shadowColor = isFacingCenter ? '#ef4444' : '#38bdf8';
      ctx.shadowBlur = 8;
      ctx.fill();

      // Heading direction pointer
      ctx.beginPath();
      ctx.moveTo(pMiniX, pMiniY);
      ctx.lineTo(
        (player.x + Math.cos(player.angle) * 450) * scale,
        (player.y + Math.sin(player.angle) * 450) * scale
      );
      ctx.strokeStyle = isFacingCenter ? '#ef4444' : '#ffffff';
      ctx.lineWidth = isFacingCenter ? 2.2 : 1.5;
      ctx.stroke();
    }
  }, [player, allWorms, brZone, gameMode, leaderboard]);

  const aliveCount = allWorms.filter((w) => !w.isDead).length;

  // Player Level and equipped Badge info
  const levelInfo = useMemo(() => {
    return calculateLevelInfo(engine?.stats.xp ?? 0);
  }, [engine?.stats.xp]);

  const activeBadge = useMemo(() => {
    return getBadgeById(engine?.stats.activeBadgeId || 'rookie');
  }, [engine?.stats.activeBadgeId]);

  // Calculate real-time alignment of player head pointing towards arena center
  const isHeadAlignedToCenter = useMemo(() => {
    if (!player || player.isDead) return false;
    const cx = MAP_SIZE / 2;
    const cy = MAP_SIZE / 2;
    const dx = cx - player.x;
    const dy = cy - player.y;
    const angleToCenter = Math.atan2(dy, dx);
    let diff = Math.abs(player.angle - angleToCenter);
    while (diff > Math.PI) diff = Math.abs(diff - Math.PI * 2);
    return diff < Math.PI / 4;
  }, [player?.x, player?.y, player?.angle, player?.isDead]);

  // Real-time distance to the center of the arena
  const distToCenter = useMemo(() => {
    if (!player || player.isDead) return 9999;
    const cx = MAP_SIZE / 2;
    const cy = MAP_SIZE / 2;
    return Math.hypot(player.x - cx, player.y - cy);
  }, [player?.x, player?.y, player?.isDead]);

  // Current speed multiplier
  const speedMultiplierStr = useMemo(() => {
    if (!player) return 'x1.00';
    const baseMult = (player.speedMultiplier ?? 1);
    const boostMult = isBoosting ? baseMult * 1.5 : baseMult;
    return `x${boostMult.toFixed(2)}`;
  }, [player?.speedMultiplier, isBoosting]);

  return (
    <div className="pointer-events-none absolute inset-0 flex flex-col justify-between p-2.5 sm:p-4 font-sans select-none overflow-hidden">
      {/* Real-time Mission Completed Banner Toast */}
      {completionBanner && (
        <div className="absolute top-5 left-1/2 -translate-x-1/2 pointer-events-none z-50 animate-bounce">
          <div className="bg-gradient-to-r from-amber-500 via-rose-500 to-cyan-500 p-0.5 rounded-2xl shadow-2xl shadow-amber-500/50">
            <div className="bg-slate-900/95 px-5 py-2.5 rounded-2xl flex items-center gap-3 border border-amber-500/40">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div>
                <div className="text-[10px] font-black uppercase tracking-widest text-amber-400">
                  {lang === 'pt' ? '🎯 MISSÃO DIÁRIA CONCLUÍDA!' : '🎯 DAILY QUEST COMPLETED!'}
                </div>
                <div className="text-xs font-extrabold text-white">
                  {lang === 'pt' ? completionBanner.titlePt : completionBanner.titleEn}
                </div>
              </div>
              <div className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 font-mono font-black text-xs border border-amber-500/40">
                +{completionBanner.rewardCoins} 🪙
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TOP ROW: Circular Radar (Top-Left), Power-ups (Top-Center), Top 10 Leaderboard (Top-Right) */}
      <div className="flex items-start justify-between gap-2 sm:gap-4 w-full">
        {/* TOP-LEFT: Circular Radar & Player Combat Indicators (Screenshot style) */}
        <div className="pointer-events-auto flex flex-col gap-2">
          {/* Circular Radar Minimap */}
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-2 border-emerald-400/80 shadow-xl shadow-emerald-500/20 bg-slate-950 flex-shrink-0">
            <canvas
              ref={minimapCanvasRef}
              width={112}
              height={112}
              className="block w-full h-full"
            />
            <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[8px] font-mono text-emerald-400 font-black tracking-widest flex items-center gap-0.5 bg-slate-950/70 px-1.5 py-0.2 rounded-full border border-emerald-500/30">
              <Radio className="w-2 h-2 animate-pulse" /> RADAR
            </div>
          </div>

          {/* Under-Radar: KILL indicator, Speed Multiplier & Length Card (Screenshot style) */}
          <div className="flex flex-col gap-1 w-24 sm:w-28">
            {/* KILL Indicator in bold orange font */}
            <div className="flex items-center justify-between px-2 py-1 rounded-lg bg-slate-900/90 border border-orange-500/60 shadow-md">
              <div className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-[11px] font-black font-mono tracking-wider text-orange-400 uppercase">
                  KILL
                </span>
              </div>
              <span className="text-xs sm:text-sm font-black font-mono text-white">
                {player?.kills || 0}
              </span>
            </div>

            {/* Speed Multiplier (e.g. x1.00 or x1.50) */}
            <div className="flex items-center justify-between px-2 py-0.5 rounded-lg bg-slate-900/85 border border-slate-700/60 text-[10px] font-mono font-bold text-slate-300">
              <span className="text-slate-400">VEL</span>
              <span className={`font-black ${isBoosting ? 'text-yellow-300 animate-pulse' : 'text-cyan-300'}`}>
                {speedMultiplierStr}
              </span>
            </div>

            {/* Mass / Score Card */}
            <div className="flex items-center justify-between px-2 py-0.5 rounded-lg bg-slate-900/85 border border-slate-700/60 text-[10px] font-mono">
              <span className="text-slate-400">MASSA</span>
              <span className="font-bold text-emerald-400">
                {(player?.length || 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* TOP-CENTER: Power-up Timers & Arena Alerts */}
        <div className="pointer-events-auto flex flex-col items-center gap-1.5 max-w-md">
          {/* Active Powerups Countdown Row (Screenshot style: >> 25, ꝏ 34, x2 53) */}
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            {player && player.activePowerUps.speed_x10 > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-950/90 border border-rose-500/80 text-yellow-300 font-mono text-xs font-black shadow-md shadow-rose-900/40 animate-pulse">
                <span>&gt;&gt;</span>
                <span>{Math.ceil(player.activePowerUps.speed_x10)}s</span>
              </div>
            )}

            {(player?.activePowerUps.curvinha ?? 0) > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-cyan-950/90 border border-cyan-400/80 text-cyan-300 font-mono text-xs font-black shadow-md animate-pulse">
                <span>ꝏ</span>
                <span>{Math.ceil(player?.activePowerUps.curvinha ?? 0)}s</span>
              </div>
            )}

            {player && player.activePowerUps.multiplier > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-950/90 border border-amber-400/80 text-amber-300 font-mono text-xs font-black shadow-md animate-pulse">
                <span>x2</span>
                <span>{Math.ceil(player.activePowerUps.multiplier)}s</span>
              </div>
            )}

            {player && player.activePowerUps.magnet > 0 && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-pink-950/90 border border-pink-400/80 text-pink-300 font-mono text-xs font-black shadow-md animate-pulse">
                <span>🧲</span>
                <span>{Math.ceil(player.activePowerUps.magnet)}s</span>
              </div>
            )}
          </div>

          {/* Arena Center Warning / Advantage Banner */}
          {distToCenter < 520 ? (
            <div className="flex items-center gap-1.5 bg-rose-950/90 border border-rose-500 px-3 py-1 rounded-full text-rose-300 text-[11px] font-black shadow-lg shadow-rose-900/60 animate-pulse">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>MEIO DA ARENA ({Math.round(distToCenter)}m): PERDE NA CABEÇADA!</span>
            </div>
          ) : distToCenter < 1200 ? (
            <div className="flex items-center gap-1.5 bg-emerald-950/80 border border-emerald-500/70 px-2.5 py-0.5 rounded-full text-emerald-300 text-[10px] font-bold shadow-md">
              <span>🛡️ VANTAGEM DE CABEÇADA ({Math.round(distToCenter)}m)</span>
            </div>
          ) : null}

          {/* Battle Royale Storm Banner */}
          {gameMode === 'battle_royale' && brZone && (
            <div className="flex items-center gap-2 bg-red-950/80 border border-red-500/60 px-3 py-1 rounded-full text-red-300 text-xs font-bold shadow-md">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-bounce" />
              <span>{t.alive}: {aliveCount}</span>
              <span className="text-red-400 font-mono">| {t.stormClosing}</span>
            </div>
          )}
        </div>

        {/* TOP-RIGHT: Top 10 Leaderboard (Matching Screenshot) */}
        <div className="pointer-events-auto flex flex-col items-end gap-1.5">
          {/* Audio Mute & Missions Quick Bar */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowMissionsCard((prev) => !prev)}
              id="hud-missions-toggle-btn"
              className={`px-2 py-1 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1 shadow ${
                showMissionsCard
                  ? 'bg-amber-500/30 border-amber-400 text-amber-200'
                  : 'bg-slate-900/80 hover:bg-slate-800 border-slate-700 text-slate-300'
              }`}
              title={lang === 'pt' ? 'Missões Diárias' : 'Daily Quests'}
            >
              <Target className="w-3 h-3 text-amber-400" />
              <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-800 border border-slate-700 font-extrabold text-amber-300">
                {missionsData.missions.filter((m) => m.completed).length}/{missionsData.missions.length}
              </span>
              {showMissionsCard ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            <button
              onClick={onToggleMute}
              id="sound-toggle-btn"
              className="p-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors shadow"
              title="Toggle Sound"
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-cyan-400" />}
            </button>
          </div>

          {/* Quick Missions In-Game Dropdown Card */}
          {showMissionsCard && (
            <div className="w-56 bg-slate-900/95 backdrop-blur-md rounded-xl border border-amber-500/50 p-2.5 shadow-2xl shadow-black/60 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1.5">
                <span className="flex items-center gap-1 text-[11px] font-black uppercase tracking-wider text-amber-300">
                  <Gift className="w-3 h-3 text-amber-400" />
                  {lang === 'pt' ? 'Missões' : 'Quests'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {missionsData.missions.filter((m) => m.completed).length}/{missionsData.missions.length}
                </span>
              </div>

              <div className="flex flex-col gap-1.5">
                {missionsData.missions.map((m) => {
                  let progressVal = m.current;
                  if (m.type === 'survive_time' && engine) {
                    progressVal = Math.max(m.current, engine.sessionSurvivalSeconds);
                  }
                  const pct = Math.min(100, Math.round((progressVal / m.target) * 100));

                  return (
                    <div key={m.id} className="text-[10px]">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <span className={`truncate ${m.completed ? 'text-emerald-300 font-bold' : 'text-slate-300'}`}>
                          {m.completed && '✓ '}{lang === 'pt' ? m.titlePt : m.titleEn}
                        </span>
                        <span className="font-mono text-amber-300 flex-shrink-0">
                          +{m.rewardCoins}🪙
                        </span>
                      </div>
                      <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            m.completed ? 'bg-emerald-400' : 'bg-gradient-to-r from-amber-400 to-cyan-400'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Screenshot-Matched Top 10 Leaderboard Card */}
          <div className="w-48 sm:w-60 bg-slate-900/85 backdrop-blur-md rounded-xl border border-slate-700/60 p-2 shadow-xl shadow-black/40">
            {/* Header: "Top 10" on left, "(271 online)" on right */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1">
              <span className="text-xs font-black uppercase tracking-wider text-slate-100 flex items-center gap-1">
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span>Top 10</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                ({aliveCount + 260} online)
              </span>
            </div>

            {/* 10 Rows with Ranks, Names, and Bright Green Scores */}
            <div className="flex flex-col gap-0.5">
              {leaderboard.slice(0, 10).map((entry, index) => (
                <div
                  key={entry.id}
                  className={`flex items-center justify-between text-xs px-1.5 py-0.5 rounded transition-colors ${
                    entry.isPlayer
                      ? 'bg-emerald-950/80 text-emerald-300 font-black border border-emerald-500/60 shadow-sm'
                      : 'text-slate-300 hover:bg-slate-800/40'
                  }`}
                >
                  {/* Left: Rank & Name */}
                  <div className="flex items-center gap-1 truncate max-w-[130px] sm:max-w-[150px]">
                    <span
                      className={`font-mono text-[11px] font-bold w-4 text-left ${
                        index === 0
                          ? 'text-yellow-400 font-black'
                          : index === 1
                          ? 'text-slate-300'
                          : index === 2
                          ? 'text-amber-600'
                          : 'text-slate-500'
                      }`}
                    >
                      {index + 1}.
                    </span>

                    {/* Active player badge / flag icon */}
                    {entry.isPlayer ? (
                      <span className="text-[11px] flex-shrink-0" title={activeBadge.namePt}>
                        {activeBadge.icon} 🇧🇷
                      </span>
                    ) : (
                      <span
                        className="w-2 h-2 rounded-full flex-shrink-0"
                        style={{ backgroundColor: entry.skinColor }}
                      />
                    )}

                    <span className="truncate text-[11px] font-medium">{entry.name}</span>
                  </div>

                  {/* Right: Score in Bright Green (matching screenshot) */}
                  <span className="font-mono text-[11px] font-bold text-emerald-400 flex-shrink-0">
                    {entry.length.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM ROW: Player Level & Controls */}
      <div className="flex items-end justify-between w-full">
        {/* BOTTOM-LEFT: Player Level, Badge, XP Bar & Keyboard Shortcuts */}
        <div className="pointer-events-auto flex flex-col gap-2">
          {/* Virtual Joystick for touch / mobile */}
          {onJoystickMove && onJoystickEnd && (
            <div className="block lg:hidden">
              <VirtualJoystick onMove={onJoystickMove} onEnd={onJoystickEnd} />
            </div>
          )}

          {/* Player Level & Equipped Badge Bar */}
          <div className="flex items-center gap-3 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/60 shadow-xl shadow-black/50">
            {/* Active Badge Icon */}
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center text-xl border shadow-md flex-shrink-0"
              style={{
                backgroundColor: 'rgba(15, 23, 42, 0.9)',
                borderColor: activeBadge.color,
                boxShadow: `0 0 12px ${activeBadge.bgGlow}`,
              }}
            >
              {activeBadge.icon}
            </div>

            {/* Level & Title */}
            <div className="flex flex-col min-w-[130px] sm:min-w-[170px]">
              <div className="flex items-center justify-between text-[10px] font-mono">
                <span className="text-amber-400 font-black uppercase">
                  NÍVEL {levelInfo.level}
                </span>
                <span className="text-slate-400">
                  {levelInfo.currentLevelXp} / {levelInfo.nextLevelXp} XP
                </span>
              </div>

              {/* XP Progress Bar */}
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-0.5 border border-slate-700/40">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-400 via-emerald-400 to-cyan-400 transition-all duration-300"
                  style={{ width: `${levelInfo.percent}%` }}
                />
              </div>

              <span className="text-[10px] font-bold text-slate-300 truncate mt-0.5">
                {lang === 'pt' ? activeBadge.namePt : activeBadge.nameEn}
              </span>
            </div>
          </div>

          {/* Desktop Keyboard Controls Legend */}
          <div className="hidden sm:flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 text-[10px] text-slate-300 shadow-md">
            <span className="font-mono text-cyan-300 font-bold">Mouse / WASD</span>
            <span className="text-slate-600">|</span>
            <span className="font-mono text-rose-300 font-bold">Espaço (Turbo)</span>
            <span className="text-slate-600">|</span>
            <span className="font-mono text-cyan-300 font-bold">C (Curva)</span>
            <span className="text-slate-600">|</span>
            <span className="font-mono text-indigo-300 font-bold">F (Plasma)</span>
            <span className="text-slate-600">|</span>
            <span className="font-mono text-yellow-300 font-bold">1/2/3 (Vel)</span>
          </div>
        </div>

        {/* BOTTOM-RIGHT: Action Controls (Sensitivity, Curvinha, Plasma, Speed Tiers, Turbo Boost) */}
        <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2.5 ml-auto">
          {/* Sensitivity Selector (Normal 1.0X, Alta 1.5X, Ultra 2.2X) */}
          <div className="flex flex-col items-center gap-1 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-700 shadow-xl">
            <span className="text-[9px] font-black font-mono text-emerald-400 uppercase tracking-wider px-1">
              SENS
            </span>
            <div className="flex items-center gap-1">
              {(['normal', 'high', 'ultra'] as const).map((lvl) => {
                const isActive = sensitivity === lvl;
                const label = lvl === 'normal' ? '1.0X' : lvl === 'high' ? '1.5X' : '2.2X';
                return (
                  <button
                    key={lvl}
                    id={`sens-tier-${lvl}-btn`}
                    onClick={() => onChangeSensitivity?.(lvl)}
                    className={`px-1.5 py-1 rounded-xl text-[10px] font-mono font-black border transition-all active:scale-95 ${
                      isActive
                        ? lvl === 'ultra'
                          ? 'bg-purple-600 border-yellow-300 text-yellow-200 shadow-lg shadow-purple-500/50'
                          : lvl === 'high'
                          ? 'bg-emerald-500 border-emerald-200 text-slate-950 shadow-md shadow-emerald-500/40'
                          : 'bg-slate-700 border-slate-400 text-slate-100'
                        : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-400'
                    }`}
                    title={`Sensibilidade ${lvl === 'ultra' ? 'Ultra Rápida (2.2x)' : lvl === 'high' ? 'Alta / Ágil (1.5x - Recomendada)' : 'Normal (1.0x)'}`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Speed Tiers Selector (2X, 5X, 10X) */}
          <div className="flex flex-col items-center gap-1 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl border border-slate-700 shadow-xl">
            <span className="text-[9px] font-black font-mono text-slate-400 uppercase tracking-wider px-1">
              SPEED
            </span>
            <div className="flex items-center gap-1">
              {([2, 5, 10] as const).map((tier) => {
                const isActive = (player?.activePowerUps.speed_x10 ?? 0) > 0 ? tier === 10 : speedTier === tier;
                return (
                  <button
                    key={tier}
                    id={`speed-tier-${tier}-btn`}
                    onClick={() => onSelectSpeedTier?.(tier)}
                    className={`px-2 py-1 rounded-xl text-[11px] font-mono font-black border transition-all active:scale-95 ${
                      isActive
                        ? tier === 10
                          ? 'bg-rose-500 border-yellow-300 text-yellow-200 shadow-lg shadow-rose-500/50 animate-pulse'
                          : tier === 5
                          ? 'bg-amber-500 border-yellow-200 text-slate-950 shadow-md shadow-amber-500/40'
                          : 'bg-cyan-500 border-cyan-300 text-slate-950 shadow-md shadow-cyan-500/40'
                        : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
                    }`}
                    title={`Velocidade ${tier}X`}
                  >
                    {tier}X
                  </button>
                );
              })}
            </div>
          </div>

          {/* Curvinha Sharp Drift Turn Button */}
          <button
            id="curvinha-action-btn"
            onClick={() => onToggleCurvinha?.()}
            className={`w-13 h-13 sm:w-16 sm:h-16 rounded-2xl border-2 flex flex-col items-center justify-center font-black transition-all active:scale-90 ${
              isCurvinha || (player?.activePowerUps.curvinha ?? 0) > 0
                ? 'bg-cyan-500 border-yellow-300 shadow-lg shadow-cyan-400/60 text-slate-950 animate-pulse'
                : 'bg-slate-900/90 hover:bg-slate-800 border-cyan-400/70 shadow-md shadow-black/60 text-cyan-300'
            }`}
            title="Curvinha Rápida / Drift (Tecla: C)"
          >
            <span className="text-xl sm:text-2xl leading-none">🌀</span>
            <span className="text-[9px] uppercase tracking-wider font-mono font-black mt-0.5">CURVA</span>
          </button>

          {/* Plasma Shot Button */}
          <button
            id="plasma-action-btn"
            onClick={onFirePlasma}
            className="w-13 h-13 sm:w-16 sm:h-16 rounded-2xl bg-indigo-600 active:bg-indigo-700 hover:bg-indigo-500 border-2 border-indigo-300 shadow-lg shadow-indigo-500/30 flex flex-col items-center justify-center text-white font-extrabold transition-transform active:scale-90"
            title="Disparar Plasma (Tecla: F ou E)"
          >
            <Zap className="w-5 h-5 sm:w-6 sm:h-6" />
            <span className="text-[9px] uppercase tracking-wider font-mono font-bold">Plasma</span>
          </button>

          {/* Turbo Acceleration Boost Button */}
          <button
            id="boost-action-btn"
            onPointerDown={() => onBoostChange(true)}
            onPointerUp={() => onBoostChange(false)}
            onPointerLeave={() => onBoostChange(false)}
            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex flex-col items-center justify-center font-black border-2 transition-all select-none touch-none ${
              isBoosting
                ? 'bg-rose-600 border-yellow-300 scale-95 shadow-2xl shadow-rose-600/70 text-yellow-200'
                : 'bg-gradient-to-b from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 border-rose-400 shadow-xl shadow-rose-950/60 text-white active:scale-95'
            }`}
            title="Segure para Acelerar (Espaço, Shift ou Clique Esquerdo)"
          >
            <Flame className={`w-7 h-7 sm:w-9 sm:h-9 ${isBoosting ? 'animate-bounce text-yellow-300' : 'text-rose-200'}`} />
            <span className="text-[10px] sm:text-[11px] uppercase tracking-widest font-black leading-none mt-0.5">ACELERAR</span>
            <span className="text-[8px] sm:text-[9px] font-mono text-rose-200 opacity-80 mt-0.5">
              {(player?.activePowerUps.speed_x10 ?? 0) > 0 ? '10X SPEED' : `${speedTier}X TURBO`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
