import React, { useState, useEffect } from 'react';
import {
  X,
  Trophy,
  Clock,
  Crosshair,
  Target,
  Sparkles,
  Gamepad2,
  CheckCircle2,
  Gift,
  Coins,
  ArrowRight,
  Flame,
} from 'lucide-react';
import {
  DailyMission,
  DailyMissionsData,
  loadDailyMissions,
  claimMissionReward,
  claimAllMissionRewards,
  getTimeUntilDailyReset,
} from '../game/dailyMissions';
import { sounds } from '../audio/soundEffects';

interface DailyMissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'pt' | 'en';
  onCoinsAwarded: (amount: number) => void;
}

export const DailyMissionsModal: React.FC<DailyMissionsModalProps> = ({
  isOpen,
  onClose,
  lang,
  onCoinsAwarded,
}) => {
  const [data, setData] = useState<DailyMissionsData>(loadDailyMissions);
  const [timeUntilReset, setTimeUntilReset] = useState<string>('');
  const [claimedNotice, setClaimedNotice] = useState<number | null>(null);

  // Refresh missions state & countdown timer
  useEffect(() => {
    if (!isOpen) return;

    const refreshData = () => {
      setData(loadDailyMissions());
      setTimeUntilReset(getTimeUntilDailyReset().formatted);
    };

    refreshData();
    const interval = setInterval(refreshData, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const missions = data.missions;
  const claimableMissions = missions.filter((m) => m.completed && !m.claimed);
  const totalClaimableCoins = claimableMissions.reduce((acc, m) => acc + m.rewardCoins, 0);
  const totalCompletedCount = missions.filter((m) => m.completed).length;

  const handleClaimSingle = (mission: DailyMission) => {
    const reward = claimMissionReward(mission.id);
    if (reward > 0) {
      sounds.playPowerUp();
      onCoinsAwarded(reward);
      setData(loadDailyMissions());
      setClaimedNotice(reward);
      setTimeout(() => setClaimedNotice(null), 2500);
    }
  };

  const handleClaimAll = () => {
    const reward = claimAllMissionRewards();
    if (reward > 0) {
      sounds.playPowerUp();
      onCoinsAwarded(reward);
      setData(loadDailyMissions());
      setClaimedNotice(reward);
      setTimeout(() => setClaimedNotice(null), 2500);
    }
  };

  const getMissionIcon = (iconName: DailyMission['icon']) => {
    switch (iconName) {
      case 'Clock':
        return <Clock className="w-5 h-5 text-amber-400" />;
      case 'Crosshair':
        return <Crosshair className="w-5 h-5 text-cyan-400" />;
      case 'Target':
        return <Target className="w-5 h-5 text-rose-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-purple-400" />;
      case 'Gamepad2':
        return <Gamepad2 className="w-5 h-5 text-emerald-400" />;
      default:
        return <Flame className="w-5 h-5 text-amber-400" />;
    }
  };

  const formatProgressDisplay = (mission: DailyMission) => {
    if (mission.type === 'survive_time') {
      const curM = Math.floor(mission.current / 60);
      const curS = mission.current % 60;
      const tarM = Math.floor(mission.target / 60);
      const tarS = mission.target % 60;
      return `${curM}:${String(curS).padStart(2, '0')} / ${tarM}:${String(tarS).padStart(2, '0')} min`;
    }
    return `${mission.current} / ${mission.target}`;
  };

  return (
    <div
      id="daily-missions-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* MODAL HEADER */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-b from-slate-850 to-slate-900 border-b border-slate-800">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center shadow-lg shadow-amber-500/25">
                <Gift className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg sm:text-xl font-black uppercase tracking-wider text-white flex items-center gap-2">
                  <span>{lang === 'pt' ? 'Missões Diárias' : 'Daily Quests'}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 font-bold">
                    {totalCompletedCount}/{missions.length}
                  </span>
                </h2>
                <div className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>
                    {lang === 'pt' ? 'Renova em:' : 'Resets in:'}{' '}
                    <strong className="text-cyan-300 font-mono">{timeUntilReset || '--:--:--'}</strong>
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              id="close-missions-modal-btn"
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors border border-slate-700/60 cursor-pointer"
              title={lang === 'pt' ? 'Fechar' : 'Close'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Reward Toast Banner */}
          {claimedNotice && (
            <div className="mt-3 py-2 px-3.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-black flex items-center justify-center gap-2 animate-bounce">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>+{claimedNotice} {lang === 'pt' ? 'MOEDAS RESGATADAS COM SUCESSO!' : 'COINS CLAIMED SUCCESSFULLY!'}</span>
            </div>
          )}
        </div>

        {/* CLAIM ALL BANNER (IF APPLICABLE) */}
        {totalClaimableCoins > 0 && (
          <div className="px-5 py-3 bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-cyan-500/15 border-b border-amber-500/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-400 animate-pulse" />
              <div className="text-xs font-bold text-slate-200">
                <span>{claimableMissions.length} {lang === 'pt' ? 'recompensas prontas:' : 'rewards ready:'} </span>
                <strong className="text-amber-300 font-mono text-sm">+{totalClaimableCoins} 🪙</strong>
              </div>
            </div>

            <button
              onClick={handleClaimAll}
              id="claim-all-missions-btn"
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 active:scale-95 text-white text-xs font-black uppercase tracking-wider shadow-lg shadow-amber-500/30 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{lang === 'pt' ? 'Resgatar Todas' : 'Claim All'}</span>
            </button>
          </div>
        )}

        {/* MISSIONS LIST CONTAINER */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3 flex-1">
          {missions.map((mission) => {
            const percent = Math.min(100, Math.round((mission.current / mission.target) * 100));
            const isCompleted = mission.completed;
            const isClaimed = mission.claimed;

            return (
              <div
                key={mission.id}
                id={`mission-card-${mission.id}`}
                className={`p-3.5 sm:p-4 rounded-2xl border transition-all ${
                  isClaimed
                    ? 'bg-slate-950/40 border-slate-800/80 opacity-75'
                    : isCompleted
                    ? 'bg-gradient-to-r from-amber-950/30 via-slate-900 to-amber-950/20 border-amber-500/50 shadow-md shadow-amber-950/40'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  {/* Left: Icon & Info */}
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 border ${
                        isClaimed
                          ? 'bg-slate-800 border-slate-700'
                          : isCompleted
                          ? 'bg-amber-500/20 border-amber-500/50'
                          : 'bg-slate-800/80 border-slate-700'
                      }`}
                    >
                      {getMissionIcon(mission.icon)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-bold text-white tracking-wide truncate">
                          {lang === 'pt' ? mission.titlePt : mission.titleEn}
                        </h3>
                        {mission.isSingleMatch && (
                          <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                            {lang === 'pt' ? '1 PARTIDA' : 'SINGLE RUN'}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5 leading-snug">
                        {lang === 'pt' ? mission.descPt : mission.descEn}
                      </p>
                    </div>
                  </div>

                  {/* Right: Reward Pill or Claim Button */}
                  <div className="flex-shrink-0 flex items-center">
                    {isClaimed ? (
                      <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/90 text-emerald-400 text-xs font-bold border border-emerald-500/30">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{lang === 'pt' ? 'Resgatado' : 'Claimed'}</span>
                      </div>
                    ) : isCompleted ? (
                      <button
                        onClick={() => handleClaimSingle(mission)}
                        id={`claim-mission-btn-${mission.id}`}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-95 text-slate-950 text-xs font-black uppercase tracking-wider shadow-lg shadow-amber-500/30 flex items-center gap-1.5 cursor-pointer animate-pulse"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                        <span>{lang === 'pt' ? 'Resgatar' : 'Claim'} +{mission.rewardCoins} 🪙</span>
                      </button>
                    ) : (
                      <div className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold flex items-center gap-1">
                        <span>🪙</span>
                        <span>+{mission.rewardCoins}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Progress Bar & Indicators */}
                <div className="mt-3">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-slate-400 font-medium">
                      {isClaimed
                        ? (lang === 'pt' ? 'Objetivo cumprido' : 'Objective completed')
                        : isCompleted
                        ? (lang === 'pt' ? '🎉 Completa! Clique para resgatar' : '🎉 Complete! Click to claim')
                        : (lang === 'pt' ? 'Progresso' : 'Progress')}
                    </span>
                    <span className="font-mono font-bold text-slate-300">
                      {formatProgressDisplay(mission)} ({percent}%)
                    </span>
                  </div>

                  <div className="w-full h-2 rounded-full bg-slate-800/80 overflow-hidden border border-slate-700/50 p-0.5">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        isClaimed
                          ? 'bg-emerald-500'
                          : isCompleted
                          ? 'bg-gradient-to-r from-amber-400 to-amber-500 animate-pulse'
                          : 'bg-gradient-to-r from-cyan-500 to-blue-500'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* MODAL FOOTER */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>
              {lang === 'pt'
                ? 'Novas missões são geradas diariamente à meia-noite.'
                : 'New quests generate daily at midnight.'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            {lang === 'pt' ? 'Entendido' : 'Got it'}
          </button>
        </div>
      </div>
    </div>
  );
};
