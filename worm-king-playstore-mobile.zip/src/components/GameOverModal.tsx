import React, { useState } from 'react';
import { TRANSLATIONS } from '../game/constants';
import { Trophy, Crosshair, Flame, RefreshCw, Home, Sparkles, Crown, User, Target, Gift, CheckCircle2 } from 'lucide-react';
import { loadDailyMissions, claimMissionReward, DailyMission } from '../game/dailyMissions';
import { sounds } from '../audio/soundEffects';
import wormzillaLogo from '../assets/images/wormzilla_logo_1788893687145.jpg';

interface GameOverModalProps {
  stats: {
    score: number;
    length: number;
    kills: number;
    headshots: number;
    rank: number;
    coinsEarned: number;
    isVictory: boolean;
    deathReason?: 'head_clash_center' | 'body_collision' | 'border_collision' | 'storm';
  };
  highScore: number;
  nickname: string;
  setNickname: (val: string) => void;
  onPlayAgain: () => void;
  onMainMenu: () => void;
  onOpenSkins: () => void;
  lang: 'pt' | 'en';
  onOpenDailyMissions?: () => void;
  onCoinsAwarded?: (coins: number) => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  highScore,
  nickname,
  setNickname,
  onPlayAgain,
  onMainMenu,
  onOpenSkins,
  lang,
  onOpenDailyMissions,
  onCoinsAwarded,
}) => {
  const t = TRANSLATIONS[lang];
  const isNewHighScore = stats.score >= highScore && stats.score > 0;
  const [missionsData, setMissionsData] = useState(() => loadDailyMissions());

  const handleClaim = (missionId: string) => {
    const reward = claimMissionReward(missionId);
    if (reward > 0) {
      sounds.playPowerUp();
      setMissionsData(loadDailyMissions());
      if (onCoinsAwarded) {
        onCoinsAwarded(reward);
      }
    }
  };

  const claimableMissions = missionsData.missions.filter((m) => m.completed && !m.claimed);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md font-sans select-none animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-900/95 border-2 border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden p-6 text-center">
        {/* Top Glow Halo */}
        <div
          className={`absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 blur-3xl opacity-30 pointer-events-none rounded-full ${
            stats.isVictory ? 'bg-amber-400' : 'bg-rose-600'
          }`}
        />

        {/* Title / Banner */}
        <div className="relative z-10 mb-4 flex flex-col items-center">
          <img
            src={wormzillaLogo}
            alt="Worm King Logo"
            className="w-12 h-12 rounded-xl object-cover border-2 border-amber-400/40 shadow-lg shadow-amber-500/20 mb-2"
            referrerPolicy="no-referrer"
          />

          {stats.isVictory ? (
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 text-xs font-black uppercase tracking-widest mb-3 animate-bounce">
              <Crown className="w-4 h-4 text-amber-400" />
              {t.victoryRoyale}
            </div>
          ) : (
            <div className="text-xs font-black uppercase tracking-widest text-rose-400 mb-1 font-mono">
              WORM DESTROYED
            </div>
          )}

          <h2
            className={`text-3xl sm:text-4xl font-black uppercase tracking-wider ${
              stats.isVictory ? 'text-amber-400' : 'text-white'
            }`}
          >
            {stats.isVictory ? t.victoryRoyale : t.gameOver}
          </h2>

          {isNewHighScore && (
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/20 border border-cyan-400 text-cyan-300 text-xs font-bold animate-pulse">
              <Sparkles className="w-3.5 h-3.5" /> {t.highScore}
            </div>
          )}

          {stats.deathReason === 'head_clash_center' && (
            <div className="mt-3 px-3 py-2 rounded-xl bg-rose-500/20 border border-rose-500/50 text-rose-300 text-xs font-bold leading-relaxed shadow-lg">
              💥 Perdeu na Cabeçada! Você estava mais perto do meio da arena do que o adversário.
            </div>
          )}
        </div>

        {/* Rank Placement Badge */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 mb-4 flex items-center justify-around">
          <div>
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
              Classificação
            </div>
            <div className="text-2xl font-black text-cyan-400 font-mono">
              #{stats.rank}
            </div>
          </div>

          <div className="h-9 w-[1px] bg-slate-800" />

          <div>
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
              Pontuação
            </div>
            <div className="text-2xl font-black text-white font-mono">
              {stats.score.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Combat Metrics Grid */}
        <div className="grid grid-cols-3 gap-2.5 mb-5">
          {/* Length */}
          <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-2.5 flex flex-col items-center">
            <Trophy className="w-5 h-5 text-cyan-400 mb-1" />
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Tamanho</span>
            <span className="text-base font-black text-white font-mono">{stats.length}</span>
          </div>

          {/* Headshots */}
          <div className="bg-rose-950/30 border border-rose-800/60 rounded-xl p-2.5 flex flex-col items-center">
            <Crosshair className="w-5 h-5 text-rose-400 mb-1" />
            <span className="text-[10px] text-rose-400 uppercase font-bold">Headshots</span>
            <span className="text-base font-black text-rose-200 font-mono">{stats.headshots}</span>
          </div>

          {/* Kills */}
          <div className="bg-amber-950/30 border border-amber-800/60 rounded-xl p-2.5 flex flex-col items-center">
            <Flame className="w-5 h-5 text-amber-400 mb-1" />
            <span className="text-[10px] text-amber-400 uppercase font-bold">Kills</span>
            <span className="text-base font-black text-amber-200 font-mono">{stats.kills}</span>
          </div>
        </div>

        {/* Coins Earned Bar */}
        <div className="bg-amber-500/10 border border-amber-500/40 rounded-xl px-4 py-2.5 flex items-center justify-between mb-3">
          <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
            {t.earnedCoins}
          </span>
          <span className="text-base font-black text-amber-400 font-mono flex items-center gap-1">
            🪙 +{stats.coinsEarned}
          </span>
        </div>

        {/* Daily Missions Progression & Direct Claim */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-4 text-left">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-amber-300">
              <Target className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'pt' ? 'Missões Diárias' : 'Daily Quests'}</span>
            </div>
            {onOpenDailyMissions && (
              <button
                onClick={onOpenDailyMissions}
                id="gameover-view-missions-btn"
                className="text-[11px] text-cyan-400 hover:text-cyan-300 font-bold hover:underline cursor-pointer"
              >
                {lang === 'pt' ? 'Ver Todas →' : 'View All →'}
              </button>
            )}
          </div>

          {claimableMissions.length > 0 ? (
            <div className="flex flex-col gap-2">
              {claimableMissions.map((m) => (
                <div
                  key={m.id}
                  className="bg-amber-500/15 border border-amber-400/60 rounded-lg p-2 flex items-center justify-between gap-2"
                >
                  <div className="truncate text-xs">
                    <span className="text-white font-bold block truncate">
                      {lang === 'pt' ? m.titlePt : m.titleEn}
                    </span>
                    <span className="text-[10px] text-amber-300 font-mono">
                      {lang === 'pt' ? 'Objetivo concluído!' : 'Goal reached!'}
                    </span>
                  </div>
                  <button
                    onClick={() => handleClaim(m.id)}
                    id={`gameover-claim-mission-${m.id}`}
                    className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center gap-1 shadow-md shadow-amber-500/30 cursor-pointer active:scale-95 transition-all flex-shrink-0 animate-pulse"
                  >
                    <Gift className="w-3.5 h-3.5" />
                    +{m.rewardCoins} 🪙
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {missionsData.missions.slice(0, 2).map((m) => {
                const pct = Math.min(100, Math.round((m.current / m.target) * 100));
                return (
                  <div key={m.id} className="bg-slate-900 border border-slate-800 rounded-lg p-1.5">
                    <div className="flex items-center justify-between text-[10px] mb-0.5">
                      <span className="truncate text-slate-300">{lang === 'pt' ? m.titlePt : m.titleEn}</span>
                      <span className="text-amber-400 font-mono font-bold">+{m.rewardCoins}🪙</span>
                    </div>
                    <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${m.completed ? 'bg-emerald-400' : 'bg-gradient-to-r from-amber-400 to-cyan-400'}`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Nickname Editor for Next Round */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-xl px-3.5 py-2 flex items-center justify-between gap-2 mb-5">
          <label htmlFor="gameover-nickname-input" className="flex items-center gap-1.5 text-xs font-bold text-slate-300 uppercase tracking-wider">
            <User className="w-3.5 h-3.5 text-cyan-400" />
            <span>Nickname:</span>
          </label>
          <div className="relative flex-1 max-w-[190px]">
            <input
              type="text"
              id="gameover-nickname-input"
              value={nickname}
              onChange={(e) => setNickname(e.target.value.slice(0, 16))}
              onFocus={(e) => e.target.select()}
              placeholder="Nickname..."
              maxLength={16}
              className="w-full bg-slate-900 border border-slate-700 focus:border-cyan-400 rounded-lg px-2.5 py-1 text-xs font-mono font-black text-cyan-300 text-center focus:outline-none transition-colors"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            onClick={onPlayAgain}
            id="play-again-btn"
            className="w-full py-3.5 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 active:scale-98 text-white font-black text-base uppercase tracking-wider shadow-lg shadow-cyan-600/40 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <RefreshCw className="w-5 h-5 animate-spin-reverse" />
            {t.respawn}
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={onOpenSkins}
              id="gameover-skins-btn"
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              <Sparkles className="w-4 h-4 text-cyan-400" />
              {t.skins}
            </button>

            <button
              onClick={onMainMenu}
              id="gameover-main-menu-btn"
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
            >
              <Home className="w-4 h-4" />
              {t.mainMenu}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
