import React, { useRef, useCallback, useState, useEffect } from 'react';

interface VirtualJoystickProps {
  onMove: (angle: number, distance: number) => void;
  onEnd: () => void;
}

export const VirtualJoystick: React.FC<VirtualJoystickProps> = ({ onMove, onEnd }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [touchPos, setTouchPos] = useState<{ x: number; y: number } | null>(null);
  const [knobOffset, setKnobOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isActive, setIsActive] = useState<boolean>(false);
  const activeTouchIdRef = useRef<number | null>(null);

  const radius = 55; // outer radius in px

  const handleTouchStart = (e: React.TouchEvent) => {
    if (activeTouchIdRef.current !== null) return;
    const touch = e.changedTouches[0];
    activeTouchIdRef.current = touch.identifier;

    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = touch.clientX - centerX;
    const dy = touch.clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const angle = Math.atan2(dy, dx);
    const clampedDist = Math.min(dist, radius);

    setKnobOffset({
      x: Math.cos(angle) * clampedDist,
      y: Math.sin(angle) * clampedDist,
    });
    setIsActive(true);
    onMove(angle, clampedDist / radius);
  };

  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (activeTouchIdRef.current === null || !containerRef.current) return;

    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === activeTouchIdRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const dx = touch.clientX - centerX;
        const dy = touch.clientY - centerY;
        const dist = Math.hypot(dx, dy);
        const angle = Math.atan2(dy, dx);
        const clampedDist = Math.min(dist, radius);

        setKnobOffset({
          x: Math.cos(angle) * clampedDist,
          y: Math.sin(angle) * clampedDist,
        });
        onMove(angle, clampedDist / radius);
        break;
      }
    }
  }, [onMove]);

  const handleTouchEnd = useCallback((e: TouchEvent) => {
    if (activeTouchIdRef.current === null) return;

    for (let i = 0; i < e.changedTouches.length; i++) {
      const touch = e.changedTouches[i];
      if (touch.identifier === activeTouchIdRef.current) {
        activeTouchIdRef.current = null;
        setKnobOffset({ x: 0, y: 0 });
        setIsActive(false);
        onEnd();
        break;
      }
    }
  }, [onEnd]);

  useEffect(() => {
    window.addEventListener('touchmove', handleTouchMove, { passive: false });
    window.addEventListener('touchend', handleTouchEnd);
    window.addEventListener('touchcancel', handleTouchEnd);
    return () => {
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('touchcancel', handleTouchEnd);
    };
  }, [handleTouchMove, handleTouchEnd]);

  return (
    <div
      ref={containerRef}
      id="virtual-joystick"
      onTouchStart={handleTouchStart}
      className={`relative w-28 h-28 sm:w-32 sm:h-32 rounded-full flex items-center justify-center select-none touch-none transition-opacity ${
        isActive ? 'opacity-95' : 'opacity-75 hover:opacity-90'
      }`}
      style={{
        background: 'radial-gradient(circle, rgba(15, 23, 42, 0.75) 0%, rgba(2, 6, 23, 0.9) 100%)',
        border: '2px solid rgba(56, 189, 248, 0.45)',
        boxShadow: isActive
          ? '0 0 25px rgba(56, 189, 248, 0.5), inset 0 0 15px rgba(56, 189, 248, 0.3)'
          : '0 8px 20px rgba(0, 0, 0, 0.6), inset 0 0 10px rgba(255, 255, 255, 0.05)',
      }}
    >
      {/* Outer directional indicators */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/40 absolute top-2" />
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/40 absolute bottom-2" />
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/40 absolute left-2" />
        <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/40 absolute right-2" />
        <div className="w-12 h-12 rounded-full border border-dashed border-cyan-400/20" />
      </div>

      {/* Center stick knob */}
      <div
        className="absolute w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center pointer-events-none transition-transform"
        style={{
          transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
          background: isActive
            ? 'radial-gradient(circle, #38bdf8 0%, #0284c7 100%)'
            : 'radial-gradient(circle, #64748b 0%, #334155 100%)',
          border: isActive ? '2px solid #ffffff' : '2px solid rgba(255, 255, 255, 0.3)',
          boxShadow: isActive
            ? '0 0 18px #38bdf8, inset 0 2px 4px rgba(255, 255, 255, 0.6)'
            : '0 4px 10px rgba(0, 0, 0, 0.5)',
        }}
      >
        <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-white' : 'bg-slate-400/60'}`} />
      </div>

      <div className="absolute -bottom-5 text-[10px] font-mono uppercase tracking-widest text-cyan-400/80 font-bold pointer-events-none">
        DIREÇÃO
      </div>
    </div>
  );
};
