import React, { useEffect, useRef, useState } from 'react';
import { WormSkin } from '../types';
import { SKINS, COLOR_PALETTES, TRANSLATIONS } from '../game/constants';
import {
  X,
  Check,
  Lock,
  Sparkles,
  Palette,
  Shield,
  Upload,
  Image as ImageIcon,
  Trash2,
  Eye,
  EyeOff,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Smartphone,
  Monitor,
  Camera,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { sounds } from '../audio/soundEffects';

interface SkinSelectorModalProps {
  currentSkin: WormSkin;
  coins: number;
  onSelectSkin: (skin: WormSkin) => void;
  onUnlockSkin: (skinId: string, cost: number) => boolean;
  onClose: () => void;
  lang: 'pt' | 'en';
}

function drawFittedSkinImage(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  cx: number,
  cy: number,
  radius: number,
  skin: WormSkin
) {
  const iw = img.naturalWidth || 100;
  const ih = img.naturalHeight || 100;
  const fit = skin.customImageFit || 'cover';
  const scale = Math.max(0.3, Math.min(3.0, skin.customImageScale ?? 1.0));
  const rotation = ((((skin.customImageRotation ?? 0) % 360) + 360) % 360) * (Math.PI / 180);
  const offsetX = (skin.customImageOffsetX ?? 0) * radius;
  const offsetY = (skin.customImageOffsetY ?? 0) * radius;

  ctx.save();
  ctx.translate(cx + offsetX, cy + offsetY);
  if (rotation !== 0) {
    ctx.rotate(rotation);
  }

  if (fit === 'contain') {
    const maxDim = Math.max(iw, ih);
    const dw = (iw / maxDim) * radius * 2.2 * scale;
    const dh = (ih / maxDim) * radius * 2.2 * scale;
    ctx.drawImage(img, -dw / 2, -dh / 2, dw, dh);
  } else {
    // Cover: maintain 1:1 circle proportion for both vertical mobile photos (9:16 / 3:4) and horizontal PC images (16:9 / 4:3)
    const minDim = Math.min(iw, ih) / scale;
    const sx = Math.max(0, Math.min(iw - minDim, (iw - minDim) / 2));
    const sy = Math.max(0, Math.min(ih - minDim, (ih - minDim) / 2));
    const targetSize = radius * 2.25;
    ctx.drawImage(
      img,
      sx,
      sy,
      minDim,
      minDim,
      -targetSize / 2,
      -targetSize / 2,
      targetSize,
      targetSize
    );
  }
  ctx.restore();
}

const SAMPLE_CUSTOM_IMAGES = [
  {
    name: 'Cyber Skull',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Neon Galaxy',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Fire Dragon',
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=200&auto=format&fit=crop&q=80',
  },
  {
    name: 'Pixel Monster',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=60',
  },
];

export const SkinSelectorModal: React.FC<SkinSelectorModalProps> = ({
  currentSkin,
  coins,
  onSelectSkin,
  onUnlockSkin,
  onClose,
  lang,
}) => {
  const t = TRANSLATIONS[lang];
  const [activeTab, setActiveTab] = useState<'presets' | 'image_lab' | 'color_lab'>('presets');

  // Custom Color Lab Skin
  const [customSkin, setCustomSkin] = useState<WormSkin>({
    id: 'custom-color-worm',
    name: 'Custom Colors',
    primaryColor: currentSkin.primaryColor || '#06b6d4',
    secondaryColor: currentSkin.secondaryColor || '#3b82f6',
    accentColor: currentSkin.accentColor || '#38bdf8',
    pattern: currentSkin.pattern || 'cyber',
    accessory: currentSkin.accessory,
    isUnlocked: true,
    cost: 0,
    rarity: 'epic',
  });

  // Custom Image Skin
  const [imageSkin, setImageSkin] = useState<WormSkin>(() => {
    if (currentSkin.customImageUrl) {
      return {
        ...currentSkin,
        customImageFit: currentSkin.customImageFit || 'cover',
        customImageScale: currentSkin.customImageScale ?? 1.0,
        customImageRotation: currentSkin.customImageRotation ?? 0,
        customImageOffsetX: currentSkin.customImageOffsetX ?? 0,
        customImageOffsetY: currentSkin.customImageOffsetY ?? 0,
      };
    }
    return {
      id: `custom-img-${Date.now()}`,
      name: 'Minha Skin Particular',
      primaryColor: '#0ea5e9',
      secondaryColor: '#6366f1',
      accentColor: '#38bdf8',
      pattern: 'custom_image',
      accessory: currentSkin.accessory,
      isUnlocked: true,
      cost: 0,
      rarity: 'legendary',
      customImageUrl: '',
      customImageApplyMode: 'head_and_body',
      customImageFit: 'cover',
      customImageScale: 1.0,
      customImageRotation: 0,
      customImageOffsetX: 0,
      customImageOffsetY: 0,
      showEyes: true,
    };
  });

  const [imageUrlInput, setImageUrlInput] = useState<string>(imageSkin.customImageUrl || '');
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [previewMode, setPreviewMode] = useState<'canvas' | 'image'>('image');
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);

  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageCacheRef = useRef<Map<string, HTMLImageElement>>(new Map());

  const getCachedImage = (url?: string): HTMLImageElement | null => {
    if (!url) return null;
    const cache = imageCacheRef.current;
    if (cache.has(url)) {
      const img = cache.get(url)!;
      return img.complete && img.naturalWidth > 0 ? img : null;
    }
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.referrerPolicy = 'no-referrer';
    img.src = url;
    cache.set(url, img);
    return null;
  };

  const handleFileUpload = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        const testImg = new Image();
        testImg.onload = () => {
          const isMobilePortrait = testImg.naturalHeight > testImg.naturalWidth * 1.15;
          setImageSkin((prev) => ({
            ...prev,
            customImageUrl: result,
            name: file.name.split('.')[0]?.slice(0, 18) || 'Skin Particular',
            customImageFit: 'cover',
            customImageScale: isMobilePortrait ? 1.15 : 1.0,
            customImageOffsetY: isMobilePortrait ? -0.1 : 0,
            customImageOffsetX: 0,
            customImageRotation: 0,
          }));
        };
        testImg.src = result;
        setImageUrlInput(result);
        sounds.playPowerUp();
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  // Animated skin preview on canvas
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const renderPreview = () => {
      time += 0.05;
      const w = canvas.width;
      const h = canvas.height;

      ctx.clearRect(0, 0, w, h);

      // Cyber preview background
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, w, h);

      // Grid lines
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.12)';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      const skinToRender =
        activeTab === 'image_lab'
          ? imageSkin
          : activeTab === 'color_lab'
          ? customSkin
          : currentSkin;

      const customImg = getCachedImage(skinToRender.customImageUrl);
      const applyToBody =
        customImg &&
        (!skinToRender.customImageApplyMode ||
          skinToRender.customImageApplyMode === 'head_and_body' ||
          skinToRender.customImageApplyMode === 'body_only');
      const applyToHead =
        customImg &&
        (!skinToRender.customImageApplyMode ||
          skinToRender.customImageApplyMode === 'head_and_body' ||
          skinToRender.customImageApplyMode === 'head_only');

      const segCount = 14;
      const baseR = 18;

      // Calculate smooth snake wave spine
      const segments: { x: number; y: number; r: number }[] = [];
      const headX = w * 0.7;
      const headY = h * 0.5 + Math.sin(time) * 15;

      for (let i = 0; i < segCount; i++) {
        const segX = headX - i * 16;
        const wave = Math.sin(time * 2 - i * 0.45) * 14;
        segments.push({
          x: segX,
          y: headY + wave,
          r: baseR,
        });
      }

      // Draw segments tail to neck (Cartoon Graphic Style)
      for (let i = segments.length - 1; i >= 0; i--) {
        const seg = segments[i];
        const isAlt = (i % 4) < 2;
        const color = isAlt ? skinToRender.primaryColor : skinToRender.secondaryColor;

        ctx.save();
        ctx.beginPath();
        ctx.arc(seg.x, seg.y, seg.r, 0, Math.PI * 2);

        if (applyToBody && customImg) {
          ctx.fillStyle = color;
          ctx.fill();
          ctx.clip();
          drawFittedSkinImage(ctx, customImg, seg.x, seg.y, seg.r, skinToRender);

          // Cartoon Cel-shading underside
          ctx.beginPath();
          ctx.arc(seg.x + seg.r * 0.22, seg.y + seg.r * 0.26, seg.r * 0.95, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
          ctx.fill();

          // Cartoon Pop-Highlight
          ctx.save();
          ctx.translate(seg.x - seg.r * 0.32, seg.y - seg.r * 0.32);
          ctx.rotate(-Math.PI / 4);
          ctx.beginPath();
          ctx.ellipse(0, 0, seg.r * 0.3, seg.r * 0.14, 0, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
          ctx.fill();
          ctx.beginPath();
          ctx.arc(seg.r * 0.22, seg.r * 0.18, seg.r * 0.08, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.fill();
          ctx.restore();
        } else if (skinToRender.pattern === 'patriota') {
          // Dark titanium segment body
          ctx.fillStyle = isAlt ? '#0c1017' : '#161e2e';
          ctx.fill();

          // Vibrant Neon Green glowing rim
          ctx.save();
          ctx.beginPath();
          ctx.arc(seg.x, seg.y, seg.r * 0.93, 0, Math.PI * 2);
          ctx.strokeStyle = '#22c55e';
          ctx.lineWidth = Math.max(2.6, seg.r * 0.16);
          ctx.shadowColor = '#22c55e';
          ctx.shadowBlur = 8;
          ctx.stroke();
          ctx.restore();

          // Brazilian Flag 🇧🇷 or Golden Trophy 🏆
          if (i % 5 === 2) {
            ctx.save();
            ctx.translate(seg.x, seg.y);
            const flagR = seg.r * 0.44;
            ctx.fillStyle = '#16a34a';
            ctx.fillRect(-flagR, -flagR * 0.7, flagR * 2, flagR * 1.4);
            ctx.fillStyle = '#facc15';
            ctx.beginPath();
            ctx.moveTo(0, -flagR * 0.6);
            ctx.lineTo(flagR * 0.8, 0);
            ctx.lineTo(0, flagR * 0.6);
            ctx.lineTo(-flagR * 0.8, 0);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = '#1d4ed8';
            ctx.beginPath();
            ctx.arc(0, 0, flagR * 0.32, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          } else if (i % 5 === 4) {
            ctx.save();
            ctx.translate(seg.x, seg.y);
            ctx.font = `${Math.floor(seg.r * 0.7)}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('🏆', 0, 0);
            ctx.restore();
          }
        } else {
          // Vibrant cartoon base
          ctx.fillStyle = color;
          ctx.fill();

          // Cartoon Cel-Shading underside crescent
          ctx.save();
          ctx.clip();
          ctx.beginPath();
          ctx.arc(seg.x + seg.r * 0.2, seg.y + seg.r * 0.28, seg.r * 0.95, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
          ctx.fill();

          // Cartoon ventral belly stripe
          if (i % 2 === 0) {
            ctx.beginPath();
            ctx.arc(seg.x, seg.y + seg.r * 0.58, seg.r * 0.5, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
            ctx.fill();
            ctx.strokeStyle = 'rgba(9, 13, 22, 0.4)';
            ctx.lineWidth = 1;
            ctx.stroke();
          }
          ctx.restore();

          // Cartoon Pop-Highlight (candy / vinyl toy shine)
          ctx.save();
          ctx.translate(seg.x - seg.r * 0.32, seg.y - seg.r * 0.32);
          ctx.rotate(-Math.PI / 4);
          ctx.beginPath();
          ctx.ellipse(0, 0, seg.r * 0.32, seg.r * 0.15, 0, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
          ctx.fill();
          ctx.beginPath();
          ctx.arc(seg.r * 0.24, seg.r * 0.18, seg.r * 0.08, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.fill();
          ctx.restore();
        }

        // Bold Cartoon Ink Outline
        ctx.beginPath();
        ctx.arc(seg.x, seg.y, seg.r, 0, Math.PI * 2);
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2.4;
        ctx.stroke();

        // Tail tip bead
        if (i === segments.length - 1) {
          ctx.beginPath();
          ctx.arc(seg.x, seg.y, seg.r * 0.6, 0, Math.PI * 2);
          ctx.fillStyle = skinToRender.accentColor;
          ctx.fill();
          ctx.strokeStyle = '#090d16';
          ctx.lineWidth = 2;
          ctx.stroke();
        }

        ctx.restore();
      }

      // Head (Cartoony Graphic Style)
      const head = segments[0];
      const headRadius = baseR * 1.15;

      // Animated Cute Forked Tongue (Linguinha fofa cartunada)
      const tongueWave = Math.sin(time * 6);
      if (tongueWave > -0.2) {
        const tongueExt = Math.max(4, (tongueWave + 1) * 8);
        const tWiggle = Math.sin(time * 18) * 1.5;
        const tx = head.x + headRadius * 0.88;
        const ty = head.y;

        ctx.save();
        ctx.translate(tx, ty);
        ctx.beginPath();
        ctx.moveTo(0, -2.5);
        ctx.lineTo(tongueExt * 0.65, -2 + tWiggle);
        ctx.lineTo(tongueExt, -6 + tWiggle);
        ctx.lineTo(tongueExt * 0.68, tWiggle);
        ctx.lineTo(tongueExt, 6 + tWiggle);
        ctx.lineTo(tongueExt * 0.65, 2 + tWiggle);
        ctx.lineTo(0, 2.5);
        ctx.closePath();
        ctx.fillStyle = '#f43f5e';
        ctx.fill();
        ctx.lineWidth = 1.4;
        ctx.strokeStyle = '#090d16';
        ctx.stroke();
        ctx.restore();
      }

      ctx.save();
      if (applyToHead && customImg) {
        ctx.beginPath();
        ctx.arc(head.x, head.y, headRadius, 0, Math.PI * 2);
        ctx.fillStyle = skinToRender.primaryColor;
        ctx.fill();
        ctx.clip();

        drawFittedSkinImage(ctx, customImg, head.x, head.y, headRadius, skinToRender);

        // Underside cel-shadow
        ctx.beginPath();
        ctx.arc(head.x + headRadius * 0.2, head.y + headRadius * 0.25, headRadius * 0.95, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
        ctx.fill();

        // Glossy Pop-Highlight Bean
        ctx.save();
        ctx.translate(head.x - headRadius * 0.35, head.y - headRadius * 0.35);
        ctx.rotate(-Math.PI / 4);
        ctx.beginPath();
        ctx.ellipse(0, 0, headRadius * 0.36, headRadius * 0.16, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.fill();
        ctx.restore();
      } else {
        // Base vibrant head
        ctx.beginPath();
        ctx.arc(head.x, head.y, headRadius, 0, Math.PI * 2);
        ctx.fillStyle = skinToRender.primaryColor;
        ctx.fill();

        // Cel-shading underside crescent
        ctx.save();
        ctx.clip();
        ctx.beginPath();
        ctx.arc(head.x + headRadius * 0.2, head.y + headRadius * 0.25, headRadius * 0.95, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.24)';
        ctx.fill();
        ctx.restore();

        // Glossy Pop-Highlight Bean
        ctx.save();
        ctx.translate(head.x - headRadius * 0.35, head.y - headRadius * 0.35);
        ctx.rotate(-Math.PI / 4);
        ctx.beginPath();
        ctx.ellipse(0, 0, headRadius * 0.36, headRadius * 0.16, 0, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(headRadius * 0.25, headRadius * 0.2, headRadius * 0.09, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.fill();
        ctx.restore();
      }

      // Head Bold Cartoon Ink Outline
      ctx.beginPath();
      ctx.arc(head.x, head.y, headRadius, 0, Math.PI * 2);
      ctx.lineWidth = 3.2;
      ctx.strokeStyle = '#090d16';
      ctx.stroke();

      // Rosy Cartoon Cheeks (Bochechinhas)
      ctx.save();
      ctx.fillStyle = 'rgba(251, 113, 133, 0.5)';
      ctx.beginPath();
      ctx.ellipse(head.x + 4, head.y - 14, 5, 3.2, Math.PI / 12, 0, Math.PI * 2);
      ctx.ellipse(head.x + 4, head.y + 14, 5, 3.2, -Math.PI / 12, 0, Math.PI * 2);
      ctx.fill();
      // Cheek blush slashes
      ctx.strokeStyle = '#e11d48';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(head.x + 3, head.y - 15);
      ctx.lineTo(head.x + 5, head.y - 13);
      ctx.moveTo(head.x + 3, head.y + 13);
      ctx.lineTo(head.x + 5, head.y + 15);
      ctx.stroke();
      ctx.restore();

      // Cute Cartoon Smile
      ctx.save();
      ctx.strokeStyle = '#090d16';
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(head.x + 8, head.y, 8, -Math.PI / 4, Math.PI / 4);
      ctx.stroke();
      ctx.restore();

      ctx.restore();

      // Big Cute Cartoon Eyes
      if (skinToRender.showEyes !== false) {
        const eyeR = 7.5;
        const eyeOffsetX = head.x + 9;
        const eyeOffsetY1 = head.y - 9;
        const eyeOffsetY2 = head.y + 9;

        // White Sclera with Bold Ink Outlines
        [eyeOffsetY1, eyeOffsetY2].forEach((ey) => {
          ctx.beginPath();
          ctx.arc(eyeOffsetX, ey, eyeR, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();
          ctx.lineWidth = 2;
          ctx.strokeStyle = '#090d16';
          ctx.stroke();

          // Iris
          ctx.beginPath();
          ctx.arc(eyeOffsetX + 2, ey, eyeR * 0.7, 0, Math.PI * 2);
          ctx.fillStyle = skinToRender.accentColor || '#06b6d4';
          ctx.fill();
          ctx.lineWidth = 1;
          ctx.strokeStyle = '#090d16';
          ctx.stroke();

          // Black Pupil
          ctx.beginPath();
          ctx.arc(eyeOffsetX + 3, ey, eyeR * 0.45, 0, Math.PI * 2);
          ctx.fillStyle = '#090d16';
          ctx.fill();

          // Triple Sparkles
          ctx.beginPath();
          ctx.arc(eyeOffsetX + 4, ey - 2.5, 2, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();
          ctx.beginPath();
          ctx.arc(eyeOffsetX + 1.5, ey + 2.5, 1.2, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(eyeOffsetX + 5, ey + 1, 0.7, 0, Math.PI * 2);
          ctx.fill();
        });

        // Expressive Cartoon Eyebrows
        ctx.save();
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2.2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(eyeOffsetX - 1, eyeOffsetY1 - 5, 5, Math.PI * 1.1, Math.PI * 1.9);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(eyeOffsetX - 1, eyeOffsetY2 + 1, 5, Math.PI * 1.1, Math.PI * 1.9);
        ctx.stroke();
        ctx.restore();
      }

      // Accessory preview (Cartoon Style)
      if (skinToRender.accessory === 'crown') {
        ctx.save();
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.moveTo(head.x - 5, head.y - 14);
        ctx.lineTo(head.x - 2, head.y - 28);
        ctx.lineTo(head.x + 5, head.y - 20);
        ctx.lineTo(head.x + 12, head.y - 28);
        ctx.lineTo(head.x + 15, head.y - 14);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2.2;
        ctx.stroke();

        // Ruby in center of crown
        ctx.beginPath();
        ctx.arc(head.x + 5, head.y - 17, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = '#ef4444';
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      } else if (skinToRender.accessory === 'visor') {
        ctx.save();
        ctx.beginPath();
        ctx.roundRect(head.x + 5, head.y - 14, 8, 28, 4);
        ctx.fillStyle = '#0f172a';
        ctx.fill();
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2.2;
        ctx.stroke();

        // Cartoon reflection glints
        ctx.save();
        ctx.clip();
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.moveTo(head.x + 5, head.y - 10);
        ctx.lineTo(head.x + 13, head.y - 4);
        ctx.lineTo(head.x + 13, head.y - 1);
        ctx.lineTo(head.x + 5, head.y - 7);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        ctx.restore();
      } else if (skinToRender.accessory === 'horns') {
        ctx.save();
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.moveTo(head.x - 4, head.y - 12);
        ctx.quadraticCurveTo(head.x + 4, head.y - 22, head.x + 10, head.y - 28);
        ctx.quadraticCurveTo(head.x + 6, head.y - 16, head.x + 4, head.y - 12);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2.2;
        ctx.stroke();
        // Horn tip
        ctx.beginPath();
        ctx.moveTo(head.x + 7, head.y - 24);
        ctx.lineTo(head.x + 10, head.y - 28);
        ctx.lineTo(head.x + 5, head.y - 20);
        ctx.closePath();
        ctx.fillStyle = '#fef3c7';
        ctx.fill();
        ctx.restore();
      } else if (skinToRender.accessory === 'halo') {
        ctx.save();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.ellipse(head.x + 4, head.y - 22, 14, 4.5, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2.2;
        ctx.stroke();
        ctx.restore();
      } else if (skinToRender.accessory === 'bandana') {
        ctx.save();
        ctx.fillStyle = '#dc2626';
        ctx.fillRect(head.x - 6, head.y - 13, 22, 6);
        ctx.strokeStyle = '#090d16';
        ctx.lineWidth = 2;
        ctx.strokeRect(head.x - 6, head.y - 13, 22, 6);
        // Ribbon knot
        ctx.beginPath();
        ctx.arc(head.x - 7, head.y - 10, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
      } else if (skinToRender.accessory === 'owl_mask') {
        ctx.save();
        // Ear tufts on top & bottom
        [-1, 1].forEach((dir) => {
          ctx.save();
          ctx.translate(head.x - 2, head.y + dir * (headRadius * 0.75));
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(-9, dir * 9);
          ctx.lineTo(4, dir * 3);
          ctx.closePath();
          ctx.fillStyle = '#f59e0b';
          ctx.fill();
          ctx.strokeStyle = '#78350f';
          ctx.lineWidth = 1.8;
          ctx.stroke();
          ctx.restore();
        });

        // Golden hooked beak in front
        ctx.beginPath();
        ctx.moveTo(head.x + headRadius * 0.45, head.y - 4.5);
        ctx.lineTo(head.x + headRadius * 1.25, head.y);
        ctx.lineTo(head.x + headRadius * 0.45, head.y + 4.5);
        ctx.closePath();
        ctx.fillStyle = '#f59e0b';
        ctx.fill();
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Beak shine
        ctx.beginPath();
        ctx.moveTo(head.x + headRadius * 0.55, head.y - 2);
        ctx.lineTo(head.x + headRadius * 1.05, head.y);
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      animId = requestAnimationFrame(renderPreview);
    };

    renderPreview();
    return () => cancelAnimationFrame(animId);
  }, [currentSkin, customSkin, imageSkin, activeTab]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-fade-in font-sans">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white uppercase tracking-wider">
                {t.skins}
              </h2>
              <div className="text-xs text-slate-400 font-mono flex items-center gap-1.5">
                <span className="text-amber-400 font-bold">🪙 {coins}</span> {t.coins}
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            id="close-skins-modal-btn"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Preview Area (Image HD or Canvas) */}
        <div className="relative w-full h-44 sm:h-52 border-b border-slate-800 bg-slate-950 flex items-center justify-center overflow-hidden">
          {activeTab === 'presets' && currentSkin.previewImageUrl && previewMode === 'image' ? (
            <div className="relative w-full h-full flex items-center justify-center bg-radial from-slate-900 to-slate-950 p-2 group">
              <img
                src={currentSkin.previewImageUrl}
                alt={currentSkin.name}
                referrerPolicy="no-referrer"
                className="max-h-full max-w-full object-contain rounded-xl shadow-2xl border border-emerald-500/40 cursor-pointer transition-transform hover:scale-105"
                onClick={() => setZoomedImage(currentSkin.previewImageUrl || null)}
              />
              <button
                onClick={() => setZoomedImage(currentSkin.previewImageUrl || null)}
                className="absolute top-3 left-4 px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-1.5 backdrop-blur-sm transition-all"
              >
                <ZoomIn className="w-3.5 h-3.5 text-emerald-400" />
                <span>Ampliar Imagem</span>
              </button>
            </div>
          ) : (
            <canvas
              ref={previewCanvasRef}
              width={520}
              height={160}
              className="w-full h-full object-contain"
            />
          )}

          {/* Mode toggle when preview image is available */}
          {activeTab === 'presets' && currentSkin.previewImageUrl && (
            <div className="absolute top-3 right-4 flex items-center bg-slate-900/90 rounded-lg p-1 border border-slate-700 shadow-md">
              <button
                onClick={() => setPreviewMode('image')}
                className={`px-2.5 py-1 text-xs font-bold rounded flex items-center gap-1.5 transition-colors ${
                  previewMode === 'image'
                    ? 'bg-emerald-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                Imagem HD
              </button>
              <button
                onClick={() => setPreviewMode('canvas')}
                className={`px-2.5 py-1 text-xs font-bold rounded flex items-center gap-1.5 transition-colors ${
                  previewMode === 'canvas'
                    ? 'bg-cyan-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                Movimento 2D
              </button>
            </div>
          )}

          <div className="absolute bottom-2 left-4 text-xs font-mono font-bold text-slate-300 bg-slate-900/90 px-3 py-1 rounded-md border border-slate-700 flex items-center gap-2">
            <span>
              {activeTab === 'image_lab'
                ? imageSkin.name || 'Skin Particular'
                : activeTab === 'color_lab'
                ? customSkin.name
                : currentSkin.name}
            </span>
            {activeTab === 'presets' && currentSkin.rarity === 'legendary' && (
              <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-1.5 py-0.5 rounded uppercase font-black">
                Lendária
              </span>
            )}
            {activeTab === 'image_lab' && imageSkin.customImageUrl && (
              <span className="text-[10px] bg-cyan-500/20 text-cyan-400 px-1.5 py-0.5 rounded uppercase font-black">
                Custom Foto
              </span>
            )}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex-1 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'presets'
                ? 'border-cyan-500 text-cyan-400 bg-slate-900/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-4 h-4" /> Presets ({SKINS.length})
          </button>

          <button
            onClick={() => setActiveTab('image_lab')}
            className={`flex-1 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'image_lab'
                ? 'border-pink-500 text-pink-400 bg-slate-900/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-4 h-4" /> Imagem Particular
          </button>

          <button
            onClick={() => setActiveTab('color_lab')}
            className={`flex-1 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'color_lab'
                ? 'border-cyan-500 text-cyan-400 bg-slate-900/60'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-4 h-4" /> Cores
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
          {activeTab === 'presets' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {SKINS.map((skin) => {
                const isSelected = currentSkin.id === skin.id;
                const isLocked = !skin.isUnlocked;

                return (
                  <div
                    key={skin.id}
                    onClick={() => {
                      if (!isLocked) {
                        onSelectSkin(skin);
                        sounds.playEatOrb(3);
                      }
                    }}
                    className={`relative p-3 rounded-xl border-2 transition-all cursor-pointer flex flex-col justify-between min-h-[95px] ${
                      isSelected
                        ? 'border-cyan-400 bg-cyan-950/40 shadow-lg shadow-cyan-900/40'
                        : isLocked
                        ? 'border-slate-800 bg-slate-900/50 opacity-80 hover:opacity-100'
                        : 'border-slate-800 bg-slate-900/90 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-white truncate max-w-[100px]">
                        {skin.name}
                      </span>
                      {isSelected ? (
                        <div className="p-1 rounded-full bg-cyan-500 text-slate-950">
                          <Check className="w-3 h-3" />
                        </div>
                      ) : isLocked ? (
                        <div className="p-1 rounded-full bg-slate-800 text-slate-400">
                          <Lock className="w-3 h-3" />
                        </div>
                      ) : null}
                    </div>

                    {/* Color Swatch / Image Preview Line */}
                    <div className="flex items-center gap-1.5 my-2">
                      {skin.previewImageUrl ? (
                        <div className="w-7 h-7 rounded-lg overflow-hidden border border-emerald-400/60 shadow-sm flex-shrink-0 bg-slate-950">
                          <img
                            src={skin.previewImageUrl}
                            alt={skin.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ) : (
                        <>
                          <div
                            className="w-4 h-4 rounded-full border border-white/20"
                            style={{ backgroundColor: skin.primaryColor }}
                          />
                          <div
                            className="w-4 h-4 rounded-full border border-white/20"
                            style={{ backgroundColor: skin.secondaryColor }}
                          />
                          <div
                            className="w-4 h-4 rounded-full border border-white/20"
                            style={{ backgroundColor: skin.accentColor }}
                          />
                        </>
                      )}
                      {skin.accessory && (
                        <span className="text-xs ml-auto">
                          {skin.accessory === 'crown'
                            ? '👑'
                            : skin.accessory === 'visor'
                            ? '👓'
                            : skin.accessory === 'horns'
                            ? '😈'
                            : skin.accessory === 'halo'
                            ? '😇'
                            : skin.accessory === 'owl_mask'
                            ? '🦉'
                            : '🧣'}
                        </span>
                      )}
                    </div>

                    {/* Button / Action */}
                    {isLocked ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onUnlockSkin(skin.id, skin.cost)) {
                            sounds.playPowerUp();
                            onSelectSkin(skin);
                          }
                        }}
                        className={`w-full py-1.5 px-2 rounded-lg text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-1 transition-colors ${
                          coins >= skin.cost
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        🪙 {skin.cost}
                      </button>
                    ) : (
                      <div className="text-[10px] uppercase font-bold text-cyan-400">
                        {isSelected ? t.unlocked : t.selectSkin}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : activeTab === 'image_lab' ? (
            /* Custom Image Lab */
            <div className="space-y-4">
              {/* Image Upload Area */}
              <div>
                <label className="text-xs font-bold text-pink-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Carregar Imagem Particular</span>
                  <span className="text-[11px] text-slate-400 font-normal">Celular ou Computador</span>
                </label>

                {/* Quick Action Buttons for Mobile & PC */}
                <div className="grid grid-cols-2 gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => cameraInputRef.current?.click()}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-pink-900/40 border border-slate-700 hover:border-pink-500/60 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
                  >
                    <Camera className="w-4 h-4 text-pink-400" />
                    <span>Câmera do Celular</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-cyan-900/40 border border-slate-700 hover:border-cyan-500/60 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
                  >
                    <Upload className="w-4 h-4 text-cyan-400" />
                    <span>Escolher Arquivo</span>
                  </button>
                </div>

                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragActive(true);
                  }}
                  onDragLeave={() => setDragActive(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1.5 ${
                    dragActive
                      ? 'border-pink-400 bg-pink-950/40 text-pink-300'
                      : imageSkin.customImageUrl
                      ? 'border-emerald-500/60 bg-emerald-950/20 text-slate-300'
                      : 'border-slate-700 bg-slate-950/40 hover:border-pink-500/60 hover:bg-slate-900 text-slate-400'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(e.target.files[0]);
                      }
                    }}
                  />

                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*"
                    capture="user"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(e.target.files[0]);
                      }
                    }}
                  />

                  <div className="w-9 h-9 rounded-full bg-pink-500/20 text-pink-400 flex items-center justify-center">
                    <Upload className="w-4 h-4" />
                  </div>

                  <div className="text-xs font-bold text-white">
                    {imageSkin.customImageUrl
                      ? 'Imagem carregada! Clique para trocar de foto.'
                      : 'Arraste a foto ou clique para selecionar do PC/Celular'}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Fotos verticais de celular ou horizontais de PC são ajustadas automaticamente
                  </div>
                </div>
              </div>

              {/* URL Input */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 block">
                  Ou cole o Link / URL da Imagem
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="https://exemplo.com/minha-imagem.png"
                    value={imageUrlInput}
                    onChange={(e) => setImageUrlInput(e.target.value)}
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500"
                  />
                  <button
                    onClick={() => {
                      if (imageUrlInput.trim()) {
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageUrl: imageUrlInput.trim(),
                        }));
                        sounds.playPowerUp();
                      }
                    }}
                    className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold rounded-xl transition-colors"
                  >
                    Aplicar
                  </button>
                  {imageSkin.customImageUrl && (
                    <button
                      onClick={() => {
                        setImageSkin((prev) => ({ ...prev, customImageUrl: '' }));
                        setImageUrlInput('');
                      }}
                      title="Remover Imagem"
                      className="p-2 bg-slate-800 hover:bg-red-900/60 text-slate-300 hover:text-red-400 rounded-xl transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Sample Images to Try */}
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">
                  Exemplos para testar
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {SAMPLE_CUSTOM_IMAGES.map((sample) => (
                    <button
                      key={sample.name}
                      onClick={() => {
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageUrl: sample.url,
                          name: sample.name,
                        }));
                        setImageUrlInput(sample.url);
                        sounds.playPowerUp();
                      }}
                      className="group relative overflow-hidden rounded-xl border border-slate-700 hover:border-pink-400 transition-all text-left p-1.5 bg-slate-950"
                    >
                      <div className="w-full h-12 rounded-lg overflow-hidden mb-1 bg-slate-800">
                        <img
                          src={sample.url}
                          alt={sample.name}
                          crossOrigin="anonymous"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                        />
                      </div>
                      <div className="text-[10px] font-bold text-slate-300 truncate text-center">
                        {sample.name}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* IMAGE ADJUSTMENT CONTROLS FOR MOBILE & PC */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-pink-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Ajuste da Imagem (Celular & PC)
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setImageSkin((prev) => ({
                        ...prev,
                        customImageFit: 'cover',
                        customImageScale: 1.0,
                        customImageRotation: 0,
                        customImageOffsetX: 0,
                        customImageOffsetY: 0,
                      }));
                      sounds.playPowerUp();
                    }}
                    className="text-[11px] text-slate-400 hover:text-pink-300 flex items-center gap-1 transition-colors"
                  >
                    <RefreshCw className="w-3 h-3" /> Redefinir
                  </button>
                </div>

                {/* Quick Device Optimization Presets */}
                <div>
                  <div className="text-[11px] text-slate-400 font-semibold mb-1.5 flex items-center justify-between">
                    <span>Otimização Rápida:</span>
                    <span className="text-[10px] text-slate-500">Adaptação automática ao formato</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageFit: 'cover',
                          customImageScale: 1.15,
                          customImageOffsetY: -0.12,
                          customImageOffsetX: 0,
                          customImageRotation: 0,
                        }));
                        sounds.playPowerUp();
                      }}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-pink-950/40 border border-slate-700 hover:border-pink-500/60 text-left transition-all group"
                    >
                      <div className="flex items-center gap-1.5 text-xs font-bold text-pink-300 mb-0.5">
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>Otimizar Celular</span>
                      </div>
                      <div className="text-[10px] text-slate-400 group-hover:text-slate-300">
                        Foto vertical / retrato (foco no assunto central)
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageFit: 'cover',
                          customImageScale: 1.0,
                          customImageOffsetY: 0,
                          customImageOffsetX: 0,
                          customImageRotation: 0,
                        }));
                        sounds.playPowerUp();
                      }}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-cyan-950/40 border border-slate-700 hover:border-cyan-500/60 text-left transition-all group"
                    >
                      <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-300 mb-0.5">
                        <Monitor className="w-3.5 h-3.5" />
                        <span>Otimizar PC</span>
                      </div>
                      <div className="text-[10px] text-slate-400 group-hover:text-slate-300">
                        Foto horizontal / wallpaper (proporção 16:9)
                      </div>
                    </button>
                  </div>
                </div>

                {/* Fit Mode: Cover vs Contain */}
                <div>
                  <div className="text-[11px] text-slate-400 font-semibold mb-1.5">
                    Modo de Encaixe no Círculo:
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageFit: 'cover',
                        }))
                      }
                      className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all ${
                        (imageSkin.customImageFit || 'cover') === 'cover'
                          ? 'border-pink-500 bg-pink-950/60 text-pink-300 shadow-sm'
                          : 'border-slate-800 bg-slate-900 text-slate-400'
                      }`}
                    >
                      Preencher Círculo (Cover)
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageFit: 'contain',
                        }))
                      }
                      className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all ${
                        imageSkin.customImageFit === 'contain'
                          ? 'border-pink-500 bg-pink-950/60 text-pink-300 shadow-sm'
                          : 'border-slate-800 bg-slate-900 text-slate-400'
                      }`}
                    >
                      Foto Completa (Contain)
                    </button>
                  </div>
                </div>

                {/* Zoom / Scale Slider */}
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-300 font-semibold mb-1">
                    <span className="flex items-center gap-1">
                      <ZoomIn className="w-3.5 h-3.5 text-cyan-400" />
                      Zoom / Escala da Imagem
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-cyan-400 font-bold text-xs">
                        {Math.round((imageSkin.customImageScale ?? 1.0) * 100)}%
                      </span>
                      <div className="flex gap-1">
                        <button
                          type="button"
                          onClick={() =>
                            setImageSkin((prev) => ({
                              ...prev,
                              customImageScale: Math.max(0.5, (prev.customImageScale ?? 1.0) - 0.1),
                            }))
                          }
                          className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-xs flex items-center justify-center text-slate-200"
                        >
                          -
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setImageSkin((prev) => ({
                              ...prev,
                              customImageScale: Math.min(2.5, (prev.customImageScale ?? 1.0) + 0.1),
                            }))
                          }
                          className="w-5 h-5 rounded bg-slate-800 hover:bg-slate-700 text-xs flex items-center justify-center text-slate-200"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="2.5"
                    step="0.05"
                    value={imageSkin.customImageScale ?? 1.0}
                    onChange={(e) =>
                      setImageSkin((prev) => ({
                        ...prev,
                        customImageScale: parseFloat(e.target.value),
                      }))
                    }
                    className="w-full accent-pink-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                </div>

                {/* Vertical Offset (Y) & Horizontal Offset (X) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <div className="flex items-center justify-between text-[11px] text-slate-300 font-semibold mb-1">
                      <span>Posição Vertical (Subir / Descer)</span>
                      <span className="font-mono text-slate-400 text-[10px]">
                        {Math.round((imageSkin.customImageOffsetY ?? 0) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="-0.5"
                      max="0.5"
                      step="0.02"
                      value={imageSkin.customImageOffsetY ?? 0}
                      onChange={(e) =>
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageOffsetY: parseFloat(e.target.value),
                        }))
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-[11px] text-slate-300 font-semibold mb-1">
                      <span>Posição Horizontal (Esq / Dir)</span>
                      <span className="font-mono text-slate-400 text-[10px]">
                        {Math.round((imageSkin.customImageOffsetX ?? 0) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="-0.5"
                      max="0.5"
                      step="0.02"
                      value={imageSkin.customImageOffsetX ?? 0}
                      onChange={(e) =>
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageOffsetX: parseFloat(e.target.value),
                        }))
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>

                {/* Rotation Button */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                  <div className="text-[11px] text-slate-400 font-semibold flex items-center gap-1.5">
                    <RotateCw className="w-3.5 h-3.5 text-pink-400" />
                    <span>Girar Orientação da Foto:</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setImageSkin((prev) => ({
                        ...prev,
                        customImageRotation: ((prev.customImageRotation ?? 0) + 90) % 360,
                      }));
                      sounds.playPowerUp();
                    }}
                    className="py-1 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 flex items-center gap-1.5 transition-colors border border-slate-700"
                  >
                    <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Girar 90° ({imageSkin.customImageRotation ?? 0}°)</span>
                  </button>
                </div>
              </div>

              {/* Mode of application: Head & Body / Head Only / Body Only */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Onde aplicar a imagem na cobrinha?
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'head_and_body', label: 'Cabeça e Corpo' },
                    { id: 'head_only', label: 'Apenas Cabeça' },
                    { id: 'body_only', label: 'Apenas Corpo' },
                  ].map((mode) => (
                    <button
                      key={mode.id}
                      onClick={() =>
                        setImageSkin((prev) => ({
                          ...prev,
                          customImageApplyMode: mode.id as any,
                        }))
                      }
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all text-center ${
                        imageSkin.customImageApplyMode === mode.id ||
                        (!imageSkin.customImageApplyMode && mode.id === 'head_and_body')
                          ? 'border-pink-500 bg-pink-950/60 text-pink-300 shadow-md shadow-pink-900/30'
                          : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      {mode.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggle Wormzilla Eyes */}
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="flex items-center gap-2.5">
                  {imageSkin.showEyes !== false ? (
                    <Eye className="w-5 h-5 text-cyan-400" />
                  ) : (
                    <EyeOff className="w-5 h-5 text-slate-500" />
                  )}
                  <div>
                    <div className="text-xs font-bold text-white">Olhos Expressivos da Cobrinha</div>
                    <div className="text-[10px] text-slate-400">
                      Desative se sua imagem já tiver rosto próprio
                    </div>
                  </div>
                </div>
                <button
                  onClick={() =>
                    setImageSkin((prev) => ({
                      ...prev,
                      showEyes: prev.showEyes === false ? true : false,
                    }))
                  }
                  className={`px-3 py-1 rounded-lg text-xs font-black transition-colors ${
                    imageSkin.showEyes !== false
                      ? 'bg-cyan-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {imageSkin.showEyes !== false ? 'ATIVADO' : 'DESATIVADO'}
                </button>
              </div>

              {/* Accent Color / Border Glow */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Cor de Contorno & Brilho
                </label>
                <div className="flex flex-wrap gap-2">
                  {COLOR_PALETTES.map((c) => (
                    <button
                      key={c}
                      onClick={() =>
                        setImageSkin((prev) => ({
                          ...prev,
                          accentColor: c,
                          primaryColor: c,
                        }))
                      }
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        imageSkin.accentColor === c ? 'scale-125 border-white shadow-md' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Accessory */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Acessório de Cabeça
                </label>
                <div className="grid grid-cols-6 gap-1.5">
                  {[
                    { id: undefined, label: 'Nenhum', icon: '❌' },
                    { id: 'crown', label: 'Coroa', icon: '👑' },
                    { id: 'visor', label: 'Visor', icon: '👓' },
                    { id: 'horns', label: 'Chifres', icon: '😈' },
                    { id: 'halo', label: 'Auréola', icon: '😇' },
                    { id: 'bandana', label: 'Faixa', icon: '🧣' },
                  ].map((acc) => (
                    <button
                      key={acc.label}
                      onClick={() => setImageSkin((prev) => ({ ...prev, accessory: acc.id as any }))}
                      className={`p-2 rounded-xl border text-[11px] font-bold flex flex-col items-center gap-0.5 transition-all ${
                        imageSkin.accessory === acc.id
                          ? 'border-pink-500 bg-pink-950/60 text-pink-300'
                          : 'border-slate-800 bg-slate-950 text-slate-400'
                      }`}
                    >
                      <span className="text-base">{acc.icon}</span>
                      <span>{acc.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Equip Custom Image Skin Button */}
              <button
                onClick={() => {
                  const finalSkin: WormSkin = {
                    ...imageSkin,
                    id: imageSkin.id || `custom-img-${Date.now()}`,
                    pattern: 'custom_image',
                    isUnlocked: true,
                  };
                  onSelectSkin(finalSkin);
                  sounds.playPowerUp();
                  onClose();
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-600 to-cyan-600 hover:from-pink-500 hover:to-cyan-500 active:scale-98 text-white font-black uppercase tracking-wider shadow-lg shadow-pink-600/30 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5" /> EQUIPAR SKIN PARTICULAR
              </button>
            </div>
          ) : (
            /* Custom Color Creator */
            <div className="space-y-4">
              {/* Primary Color */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Cor Primária
                </label>
                <div className="flex flex-wrap gap-2">
                  {COLOR_PALETTES.map((c) => (
                    <button
                      key={c}
                      onClick={() => setCustomSkin({ ...customSkin, primaryColor: c })}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        customSkin.primaryColor === c ? 'scale-125 border-white shadow-md' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Secondary Color */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Cor Secundária
                </label>
                <div className="flex flex-wrap gap-2">
                  {COLOR_PALETTES.map((c) => (
                    <button
                      key={c}
                      onClick={() => setCustomSkin({ ...customSkin, secondaryColor: c })}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        customSkin.secondaryColor === c ? 'scale-125 border-white shadow-md' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Accent Color */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Cor de Destaque / Contorno
                </label>
                <div className="flex flex-wrap gap-2">
                  {COLOR_PALETTES.map((c) => (
                    <button
                      key={c}
                      onClick={() => setCustomSkin({ ...customSkin, accentColor: c })}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        customSkin.accentColor === c ? 'scale-125 border-white shadow-md' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Accessory */}
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 block">
                  Acessório de Cabeça
                </label>
                <div className="grid grid-cols-7 gap-1.5">
                  {[
                    { id: undefined, label: 'Nenhum', icon: '❌' },
                    { id: 'crown', label: 'Coroa', icon: '👑' },
                    { id: 'visor', label: 'Visor', icon: '👓' },
                    { id: 'horns', label: 'Chifres', icon: '😈' },
                    { id: 'halo', label: 'Auréola', icon: '😇' },
                    { id: 'bandana', label: 'Faixa', icon: '🧣' },
                    { id: 'owl_mask', label: 'Coruja', icon: '🦉' },
                  ].map((acc) => (
                    <button
                      key={acc.label}
                      onClick={() => setCustomSkin({ ...customSkin, accessory: acc.id as any })}
                      className={`p-2 rounded-xl border text-[10px] font-bold flex flex-col items-center gap-0.5 transition-all ${
                        customSkin.accessory === acc.id
                          ? 'border-cyan-400 bg-cyan-950/60 text-cyan-300'
                          : 'border-slate-800 bg-slate-900 text-slate-400'
                      }`}
                    >
                      <span className="text-base">{acc.icon}</span>
                      <span className="truncate">{acc.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  onSelectSkin(customSkin);
                  sounds.playPowerUp();
                  onClose();
                }}
                className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 active:scale-98 text-white font-black uppercase tracking-wider shadow-lg shadow-cyan-600/40"
              >
                EQUIPAR SKIN CUSTOMIZADA
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Fullscreen Image Lightbox Modal */}
      {zoomedImage && (
        <div
          className="fixed inset-0 z-60 bg-black/95 flex flex-col items-center justify-center p-4 animate-fade-in"
          onClick={() => setZoomedImage(null)}
        >
          <div
            className="relative max-w-xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-lg">🦉</span>
                <span className="text-sm font-black text-white">{currentSkin.name}</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-black uppercase tracking-wider">
                  Skin Oficial HD
                </span>
              </div>
              <button
                onClick={() => setZoomedImage(null)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative w-full aspect-square bg-slate-950 flex items-center justify-center p-4">
              <img
                src={zoomedImage}
                alt={currentSkin.name}
                referrerPolicy="no-referrer"
                className="max-w-full max-h-full object-contain rounded-xl shadow-2xl border border-emerald-500/30"
              />
            </div>

            <div className="px-5 py-3 bg-slate-950/80 border-t border-slate-800 text-xs text-slate-300 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">Detalhes da Skin:</span>
                <span className="text-emerald-400 font-bold">Resolução Máxima 3D</span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Máscara de coruja/águia mítica com bico dourado e penugem realçada, corpo de titânio escuro com anéis de neon verde brilhante, brasões da bandeira do Brasil 🇧🇷 e troféus de campeão 🏆.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
