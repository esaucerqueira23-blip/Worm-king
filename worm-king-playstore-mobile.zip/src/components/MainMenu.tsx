import React, { useState } from 'react';
import { GameMode, WormSkin, GameStats } from '../types';
import { TRANSLATIONS } from '../game/constants';
import {
  Play,
  Sparkles,
  Trophy,
  Flame,
  Crosshair,
  Volume2,
  VolumeX,
  Music,
  Globe,
  Dices,
  Shield,
  Radio,
  Zap,
  User,
  X,
  Target,
  Gift,
  CheckCircle2,
  Clock,
  Award,
  ZoomIn,
  Eye,
  Image as ImageIcon,
} from 'lucide-react';
import { sounds } from '../audio/soundEffects';
import { loadDailyMissions } from '../game/dailyMissions';
import { calculateLevelInfo, getBadgeById } from '../game/playerLevel';
import wormzillaBanner from '../assets/images/wormzilla_banner_1788893675039.jpg';
import wormzillaLogo from '../assets/images/wormzilla_logo_1788893687145.jpg';

interface MainMenuProps {
  nickname: string;
  setNickname: (val: string) => void;
  selectedMode: GameMode;
  setSelectedMode: (mode: GameMode) => void;
  selectedSkin: WormSkin;
  onOpenSkins: () => void;
  onStartGame: () => void;
  stats: GameStats;
  lang: 'pt' | 'en';
  setLang: (l: 'pt' | 'en') => void;
  isMuted: boolean;
  setIsMuted: (m: boolean) => void;
  musicEnabled: boolean;
  setMusicEnabled: (m: boolean) => void;
  onOpenDailyMissions?: () => void;
  onOpenBadges?: () => void;
}

const RANDOM_NICKNAMES = [
  'WormKing', 'MegaCobra', 'TitanSnake', 'HeadshotPro',
  'NeonStriker', 'ShadowViper', 'DoomWorm', 'CyberPredator',
  'ToxicVenom', 'HyperKing', 'GlitchBite', 'ApexHunter'
];

export const MainMenu: React.FC<MainMenuProps> = ({
  nickname,
  setNickname,
  selectedMode,
  setSelectedMode,
  selectedSkin,
  onOpenSkins,
  onStartGame,
  stats,
  lang,
  setLang,
  isMuted,
  setIsMuted,
  musicEnabled,
  setMusicEnabled,
  onOpenDailyMissions,
  onOpenBadges,
}) => {
  const t = TRANSLATIONS[lang];
  const [showStatsModal, setShowStatsModal] = useState(false);
  const [showSkinImageModal, setShowSkinImageModal] = useState(false);
  const missionsData = loadDailyMissions();
  const claimableCount = missionsData.missions.filter((m) => m.completed && !m.claimed).length;

  const levelInfo = calculateLevelInfo(stats.xp ?? 0);
  const activeBadge = getBadgeById(stats.activeBadgeId || 'rookie');

  const handleRandomizeNick = () => {
    const random = RANDOM_NICKNAMES[Math.floor(Math.random() * RANDOM_NICKNAMES.length)];
    setNickname(random);
    sounds.playEatOrb(2);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-between p-4 sm:p-6 select-none bg-slate-950 font-sans text-white overflow-y-auto">
      {/* Dynamic Cyber Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-cyan-600/15 blur-[120px] rounded-full" />
        <div className="absolute -bottom-40 right-10 w-[500px] h-[400px] bg-rose-600/15 blur-[120px] rounded-full" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b12_1px,transparent_1px),linear-gradient(to_bottom,#1e293b12_1px,transparent_1px)] bg-[size:32px_32px]" />
      </div>

      {/* TOP BAR: Audio, Language & Stats */}
      <header className="relative z-10 w-full max-w-4xl flex items-center justify-between gap-3">
        {/* Left: Brand Badge */}
        <div className="flex items-center gap-2.5">
          <img
            src={wormzillaLogo}
            alt="Worm King Mascot"
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl object-cover border-2 border-emerald-400/50 shadow-lg shadow-emerald-500/30"
            referrerPolicy="no-referrer"
          />
          <div>
            <div className="text-sm font-black tracking-wider uppercase flex items-center gap-1.5">
              WORM <span className="text-emerald-400">KING</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                ARENA
              </span>
            </div>
            <div className="text-[9px] text-slate-400 uppercase font-mono tracking-wider">
              {lang === 'pt' ? 'Arena Oficial' : 'Official Arena'}
            </div>
          </div>
        </div>

        {/* Right: Settings & Coins */}
        <div className="flex items-center gap-2">
          {/* Coin Counter */}
          <div className="bg-slate-900/90 border border-amber-500/40 px-3 py-1.5 rounded-xl text-xs font-mono font-bold text-amber-300 flex items-center gap-1.5 shadow-sm">
            <span>🪙</span>
            <span>{stats.coins}</span>
          </div>

          {/* Language Toggle */}
          <button
            onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')}
            id="lang-toggle-btn"
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold uppercase transition-colors flex items-center gap-1"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span>{lang.toUpperCase()}</span>
          </button>

          {/* Music Toggle */}
          <button
            onClick={() => {
              const next = !musicEnabled;
              setMusicEnabled(next);
              sounds.setMusicEnabled(next);
            }}
            id="music-toggle-btn"
            className={`p-2 rounded-xl border transition-colors ${
              musicEnabled
                ? 'bg-cyan-950/80 border-cyan-500/60 text-cyan-300'
                : 'bg-slate-900/90 border-slate-700 text-slate-500'
            }`}
            title="Toggle Music"
          >
            <Music className="w-4 h-4" />
          </button>

          {/* Sound FX Toggle */}
          <button
            onClick={() => {
              const next = !isMuted;
              setIsMuted(next);
              sounds.setMuted(next);
            }}
            id="menu-sound-btn"
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors"
            title="Toggle Sound Effects"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Daily Missions Button */}
          <button
            onClick={onOpenDailyMissions}
            id="open-daily-missions-btn"
            className="relative p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors cursor-pointer"
            title={lang === 'pt' ? 'Missões Diárias' : 'Daily Quests'}
          >
            <Target className="w-4 h-4 text-amber-400" />
            {claimableCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-slate-950 font-black text-[10px] rounded-full flex items-center justify-center animate-bounce shadow">
                {claimableCount}
              </span>
            )}
          </button>

          {/* Badges / Insígnias Button */}
          <button
            onClick={onOpenBadges}
            id="open-badges-btn"
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-amber-500/40 text-amber-300 transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
            title={lang === 'pt' ? 'Insígnias & Nível de Jogador' : 'Player Badges & Level'}
          >
            <span className="text-sm">{activeBadge.icon}</span>
            <span className="text-[10px] font-mono font-black">NV.{levelInfo.level}</span>
          </button>

          {/* Career Stats Button */}
          <button
            onClick={() => setShowStatsModal(true)}
            id="open-stats-btn"
            className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-300 transition-colors"
            title="Career Stats"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </header>

      {/* CENTER STAGE */}
      <main className="relative z-10 w-full max-w-md my-auto flex flex-col items-center text-center py-4">
        {/* Game Banner Artwork Card */}
        <div className="relative w-full overflow-hidden rounded-2xl border-2 border-emerald-500/50 shadow-2xl shadow-emerald-500/25 mb-4 group bg-slate-900">
          <img
            src={wormzillaBanner}
            alt="Worm King Game Arena"
            className="w-full h-36 sm:h-44 object-cover object-center group-hover:scale-105 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/25 to-transparent flex flex-col justify-end p-3 pointer-events-none">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-300 drop-shadow flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                WORM KING ARENA
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-900/90 text-emerald-400 border border-emerald-400/50 font-bold">
                BATTLE ROYALE
              </span>
            </div>
          </div>
        </div>

        {/* Game Title with Cyber Glow */}
        <div className="mb-4 relative">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-black uppercase tracking-widest mb-1.5 animate-pulse">
            <Crosshair className="w-3.5 h-3.5 text-emerald-400" /> PRECISION HEADSHOT ARENA
          </div>

          <h1 className="text-4xl sm:text-5xl font-black uppercase tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-white via-emerald-100 to-emerald-400 drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)] font-sans">
            WORM <span className="text-emerald-400">KING</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-400 max-w-xs mx-auto mt-0.5">
            {t.tagline}
          </p>
        </div>

        {/* Player Level & Equipped Badge Bar */}
        <div
          onClick={onOpenBadges}
          id="mainmenu-level-badge-card"
          className="w-full bg-slate-900/90 hover:bg-slate-800/90 border border-slate-700/80 hover:border-amber-400/70 p-3 rounded-2xl shadow-xl flex items-center justify-between gap-3 cursor-pointer transition-all mb-4 group"
        >
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center text-2xl border shadow-md flex-shrink-0"
              style={{
                backgroundColor: 'rgba(15, 23, 42, 0.9)',
                borderColor: activeBadge.color,
                boxShadow: `0 0 12px ${activeBadge.bgGlow}`,
              }}
            >
              {activeBadge.icon}
            </div>
            <div className="text-left">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-mono font-black px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  NÍVEL {levelInfo.level}
                </span>
                <span className="text-xs sm:text-sm font-black text-white group-hover:text-amber-300 transition-colors">
                  {lang === 'pt' ? activeBadge.namePt : activeBadge.nameEn}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-28 sm:w-36 h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700/40">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-amber-400 via-emerald-400 to-cyan-400 transition-all duration-300"
                    style={{ width: `${levelInfo.percent}%` }}
                  />
                </div>
                <span className="text-[10px] font-mono text-slate-400">
                  {levelInfo.currentLevelXp} / {levelInfo.nextLevelXp} XP
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 px-2.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-400/40 group-hover:bg-amber-500/20 transition-colors flex-shrink-0">
            <Award className="w-4 h-4" />
            <span>{lang === 'pt' ? 'Insígnias' : 'Badges'}</span>
          </div>
        </div>

        {/* Player Profile & Equipped Skin Preview Card */}
        <div className="w-full bg-slate-900/90 border border-slate-700/80 rounded-2xl p-4 shadow-xl mb-4 backdrop-blur-md">
          {/* Nickname Header & Character Counter */}
          <div className="flex items-center justify-between mb-2 px-0.5">
            <label htmlFor="player-nickname-input" className="text-xs font-black text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-cyan-400" />
              <span>{lang === 'pt' ? 'Nome do Verme (Nickname)' : 'Worm Nickname'}</span>
            </label>
            <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
              {nickname.length}/16
            </span>
          </div>

          {/* Nickname Input & Controls */}
          <div className="flex items-center gap-2 mb-2.5">
            <div className="relative flex-1 flex items-center">
              <input
                type="text"
                id="player-nickname-input"
                value={nickname}
                onChange={(e) => setNickname(e.target.value.slice(0, 16))}
                onFocus={(e) => e.target.select()}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    onStartGame();
                  }
                }}
                placeholder={lang === 'pt' ? 'Digite seu nickname...' : 'Enter your nickname...'}
                maxLength={16}
                className="w-full bg-slate-950/90 border-2 border-slate-700 rounded-xl pl-3.5 pr-8 py-2.5 text-sm font-black text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 tracking-wider font-mono transition-all shadow-inner"
              />
              {nickname.length > 0 && (
                <button
                  type="button"
                  onClick={() => setNickname('')}
                  className="absolute right-2.5 p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title={lang === 'pt' ? 'Limpar nome' : 'Clear nickname'}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <button
              onClick={handleRandomizeNick}
              id="randomize-nick-btn"
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-200 transition-all border border-slate-700 flex items-center gap-1.5 text-xs font-bold shadow-sm cursor-pointer"
              title={lang === 'pt' ? 'Gerar Nickname Aleatório' : 'Randomize Nickname'}
            >
              <Dices className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">{lang === 'pt' ? 'Aleatório' : 'Random'}</span>
            </button>
          </div>

          {/* Quick Preset Nickname Chips */}
          <div className="flex flex-wrap items-center gap-1.5 mb-3">
            <span className="text-[10px] text-slate-400 uppercase font-semibold mr-0.5">
              {lang === 'pt' ? 'Sugestões:' : 'Presets:'}
            </span>
            {['MegaCobra', 'Titan', 'HeadshotPro', 'ApexViper', 'DoomWorm', 'NeonStriker'].map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => {
                  setNickname(preset);
                  sounds.playEatOrb(1);
                }}
                className={`text-[10px] sm:text-[11px] px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                  nickname === preset
                    ? 'bg-cyan-500/25 border-cyan-400 text-cyan-300 font-extrabold shadow-sm'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>

          {/* Equipped Skin Spotlight Showcase Card */}
          {selectedSkin.previewImageUrl ? (
            <div
              id="select-skin-banner-card"
              className="p-3 rounded-2xl bg-gradient-to-b from-slate-900/90 to-slate-950/90 border border-emerald-500/40 hover:border-emerald-400 shadow-xl shadow-emerald-950/20 transition-all flex flex-col gap-2.5"
            >
              {/* Card Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs">🦉</span>
                  <span className="text-xs font-black text-white tracking-wide">
                    {selectedSkin.name}
                  </span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.2 rounded font-black uppercase tracking-wider">
                    Lendária 🇧🇷
                  </span>
                </div>
                <button
                  onClick={onOpenSkins}
                  className="text-[11px] font-bold text-cyan-400 hover:text-cyan-300 uppercase tracking-wider flex items-center gap-1 transition-colors"
                >
                  <Sparkles className="w-3 h-3" />
                  Mudar
                </button>
              </div>

              {/* Skin Artwork Image Display */}
              <div
                onClick={() => setShowSkinImageModal(true)}
                className="relative w-full h-36 rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center cursor-pointer group shadow-inner"
              >
                <img
                  src={selectedSkin.previewImageUrl}
                  alt={selectedSkin.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                {/* Badges on bottom */}
                <div className="absolute bottom-2 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
                  <div className="text-[11px] font-mono text-emerald-300 font-bold bg-slate-950/80 backdrop-blur-sm px-2 py-0.5 rounded border border-emerald-500/30">
                    ✨ Arte Oficial 3D
                  </div>
                  <div className="text-[11px] font-bold text-white bg-emerald-600/90 backdrop-blur-sm px-2 py-0.5 rounded flex items-center gap-1 shadow">
                    <ZoomIn className="w-3 h-3" />
                    Ampliar Imagem
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Standard Skin Pill */
            <div
              onClick={onOpenSkins}
              id="select-skin-banner-btn"
              className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-cyan-500/50 cursor-pointer transition-all group"
            >
              <div className="flex items-center gap-2.5">
                {selectedSkin.customImageUrl ? (
                  <div className="w-7 h-7 rounded-full overflow-hidden border border-cyan-400 shadow-sm relative bg-slate-800 flex-shrink-0">
                    <img
                      src={selectedSkin.customImageUrl}
                      alt="Skin Particular"
                      crossOrigin="anonymous"
                      referrerPolicy="no-referrer"
                      className="w-full h-full"
                      style={{
                        objectFit: selectedSkin.customImageFit || 'cover',
                        transform: `scale(${selectedSkin.customImageScale || 1}) rotate(${selectedSkin.customImageRotation || 0}deg)`,
                      }}
                    />
                  </div>
                ) : (
                  <div className="flex -space-x-1.5 flex-shrink-0">
                    <div
                      className="w-4 h-4 rounded-full border-2 border-slate-950 shadow-sm relative overflow-hidden"
                      style={{ backgroundColor: selectedSkin.primaryColor }}
                    >
                      <div className="absolute top-0.5 left-0.5 w-1.5 h-0.5 bg-white/80 rounded-full -rotate-45" />
                    </div>
                    <div
                      className="w-4 h-4 rounded-full border-2 border-slate-950 shadow-sm relative overflow-hidden"
                      style={{ backgroundColor: selectedSkin.secondaryColor }}
                    >
                      <div className="absolute top-0.5 left-0.5 w-1.5 h-0.5 bg-white/80 rounded-full -rotate-45" />
                    </div>
                    <div
                      className="w-4 h-4 rounded-full border-2 border-slate-950 shadow-sm relative overflow-hidden"
                      style={{ backgroundColor: selectedSkin.accentColor }}
                    >
                      <div className="absolute top-0.5 left-0.5 w-1.5 h-0.5 bg-white/80 rounded-full -rotate-45" />
                    </div>
                  </div>
                )}
                <span className="text-xs font-bold text-slate-200 group-hover:text-cyan-300 transition-colors">
                  {selectedSkin.name} {selectedSkin.accessory ? '👑' : ''}
                </span>
              </div>

              <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {t.skins}
              </span>
            </div>
          )}
        </div>

        {/* Game Mode Selector */}
        <div className="w-full grid grid-cols-3 gap-2 mb-5">
          {/* Classic FFA */}
          <button
            onClick={() => {
              setSelectedMode('ffa');
              sounds.playEatOrb(1);
            }}
            id="mode-ffa-btn"
            className={`p-2.5 rounded-xl border-2 flex flex-col items-center gap-1 transition-all cursor-pointer ${
              selectedMode === 'ffa'
                ? 'border-cyan-400 bg-cyan-950/50 shadow-lg shadow-cyan-950/50 text-white'
                : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className={`w-5 h-5 ${selectedMode === 'ffa' ? 'text-cyan-400' : ''}`} />
            <span className="text-xs font-black uppercase tracking-wider">Clássico</span>
          </button>

          {/* Battle Royale */}
          <button
            onClick={() => {
              setSelectedMode('battle_royale');
              sounds.playEatOrb(2);
            }}
            id="mode-br-btn"
            className={`p-2.5 rounded-xl border-2 flex flex-col items-center gap-1 transition-all cursor-pointer ${
              selectedMode === 'battle_royale'
                ? 'border-rose-400 bg-rose-950/50 shadow-lg shadow-rose-950/50 text-white'
                : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className={`w-5 h-5 ${selectedMode === 'battle_royale' ? 'text-rose-400 animate-pulse' : ''}`} />
            <span className="text-xs font-black uppercase tracking-wider">Royale</span>
          </button>

          {/* Headshot Rush */}
          <button
            onClick={() => {
              setSelectedMode('headshot_rush');
              sounds.playEatOrb(3);
            }}
            id="mode-rush-btn"
            className={`p-2.5 rounded-xl border-2 flex flex-col items-center gap-1 transition-all cursor-pointer ${
              selectedMode === 'headshot_rush'
                ? 'border-amber-400 bg-amber-950/50 shadow-lg shadow-amber-950/50 text-white'
                : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className={`w-5 h-5 ${selectedMode === 'headshot_rush' ? 'text-amber-400' : ''}`} />
            <span className="text-xs font-black uppercase tracking-wider">Rush 3X</span>
          </button>
        </div>

        {/* Selected Mode Description */}
        <div className="text-xs text-slate-400 mb-4 max-w-sm">
          {selectedMode === 'ffa' && t.classicDesc}
          {selectedMode === 'battle_royale' && t.battleRoyaleDesc}
          {selectedMode === 'headshot_rush' && t.headshotRushDesc}
        </div>

        {/* Daily Missions Quick Teaser Card */}
        <div
          onClick={onOpenDailyMissions}
          id="mainmenu-missions-teaser"
          className="w-full bg-slate-900/90 hover:bg-slate-850 border border-amber-500/40 hover:border-amber-400 rounded-2xl p-3 mb-4 shadow-lg backdrop-blur-md cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-amber-300">
              <Target className="w-4 h-4 text-amber-400 group-hover:rotate-45 transition-transform" />
              <span>{lang === 'pt' ? 'Missões Diárias' : 'Daily Quests'}</span>
              {claimableCount > 0 ? (
                <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black uppercase tracking-wider animate-bounce">
                  {claimableCount} {lang === 'pt' ? 'Prontas!' : 'Ready!'}
                </span>
              ) : (
                <span className="text-[10px] text-slate-400 font-mono">
                  {missionsData.missions.filter((m) => m.completed).length}/{missionsData.missions.length}
                </span>
              )}
            </div>
            <span className="text-[11px] text-cyan-400 font-bold group-hover:underline">
              {lang === 'pt' ? 'Ver todas →' : 'View all →'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-left">
            {missionsData.missions.slice(0, 2).map((m) => {
              const pct = Math.min(100, Math.round((m.current / m.target) * 100));
              return (
                <div key={m.id} className="bg-slate-950/70 border border-slate-800 rounded-xl p-2">
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="truncate text-slate-300 font-semibold">{lang === 'pt' ? m.titlePt : m.titleEn}</span>
                    <span className="text-amber-400 font-mono text-[10px] font-bold">+{m.rewardCoins}🪙</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        m.completed ? 'bg-emerald-400' : 'bg-gradient-to-r from-amber-400 to-cyan-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono mt-0.5 text-right">
                    {m.current} / {m.target} {m.completed ? '✓' : ''}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* PLAY BUTTON */}
        <button
          onClick={onStartGame}
          id="play-game-main-btn"
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-600 to-cyan-500 hover:from-amber-400 hover:to-cyan-400 active:scale-98 text-white font-black text-lg uppercase tracking-widest shadow-2xl shadow-rose-600/40 flex items-center justify-center gap-3 transition-all cursor-pointer border-t border-white/20"
        >
          <Play className="w-6 h-6 fill-current" />
          {t.play}
        </button>

        {/* CONTROLS & ACCELERATION TIP PILLS */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-[11px] text-slate-400">
          <span className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 flex items-center gap-1.5 text-slate-300">
            <span className="text-cyan-400 font-bold">🎮 Controle:</span> Mouse, Joystick ou WASD
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 flex items-center gap-1.5 text-slate-300">
            <span className="text-rose-400 font-bold">⚡ Aceleração:</span> Espaço, Shift ou Botão Turbo
          </span>
        </div>
      </main>

      {/* FOOTER: Quick Summary */}
      <footer className="relative z-10 w-full max-w-4xl flex items-center justify-between text-xs text-slate-500 border-t border-slate-900 pt-3">
        <div className="flex items-center gap-4">
          <span>🏆 Recorde: <strong className="text-slate-300 font-mono">{stats.highestScore.toLocaleString()}</strong></span>
          <span>⚔️ Kills: <strong className="text-slate-300 font-mono">{stats.totalKills}</strong></span>
          <span>💥 Headshots: <strong className="text-rose-400 font-mono">{stats.totalHeadshots}</strong></span>
        </div>
        <div className="text-[11px] font-mono">
          v2.4.0 • 60 FPS Engine
        </div>
      </footer>

      {/* CAREER STATS MODAL */}
      {showStatsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl">
            <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-400" />
                {t.stats}
              </h3>
              <button
                onClick={() => setShowStatsModal(false)}
                id="close-stats-btn"
                className="text-slate-400 hover:text-white text-xs font-bold uppercase"
              >
                Fechar
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between p-2 rounded-lg bg-slate-950/60">
                <span className="text-slate-400">Partidas Jogadas</span>
                <span className="font-mono font-bold text-white">{stats.gamesPlayed}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-slate-950/60">
                <span className="text-slate-400">Maior Pontuação</span>
                <span className="font-mono font-bold text-cyan-400">{stats.highestScore.toLocaleString()}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-slate-950/60">
                <span className="text-slate-400">Maior Tamanho</span>
                <span className="font-mono font-bold text-white">{stats.highestLength}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-slate-950/60">
                <span className="text-slate-400">Total de Eliminações</span>
                <span className="font-mono font-bold text-amber-400">{stats.totalKills}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-slate-950/60">
                <span className="text-slate-400">Total de Headshots</span>
                <span className="font-mono font-bold text-rose-400">{stats.totalHeadshots}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-slate-950/60">
                <span className="text-slate-400">Vitórias Battle Royale</span>
                <span className="font-mono font-bold text-yellow-300">👑 {stats.battleRoyaleWins}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Skin Artwork Lightbox Modal */}
      {showSkinImageModal && selectedSkin.previewImageUrl && (
        <div
          className="fixed inset-0 z-60 bg-black/95 flex flex-col items-center justify-center p-4 animate-fade-in"
          onClick={() => setShowSkinImageModal(false)}
        >
          <div
            className="relative max-w-xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xl">🦉</span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-black text-white">{selectedSkin.name}</h3>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-black uppercase tracking-wider">
                      Lendária 🇧🇷
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">Visual Oficial 3D em Alta Definição</span>
                </div>
              </div>
              <button
                onClick={() => setShowSkinImageModal(false)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Image View */}
            <div className="relative w-full aspect-square bg-slate-950 flex items-center justify-center p-4">
              <img
                src={selectedSkin.previewImageUrl}
                alt={selectedSkin.name}
                referrerPolicy="no-referrer"
                className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl border border-emerald-500/40"
              />
            </div>

            {/* Modal Description */}
            <div className="px-5 py-4 bg-slate-950 border-t border-slate-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200">Componentes de Estilo:</span>
                <span className="text-emerald-400 font-bold">100% Fiel à Imagem do Jogo</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                  <span className="text-base">🦉</span>
                  <span>Máscara de Coruja com bico dourado e penugem</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                  <span className="text-base">🇧🇷</span>
                  <span>Brasão da Bandeira do Brasil nos gomos</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                  <span className="text-base">🏆</span>
                  <span>Troféus de campeão gravados em ouro</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 flex items-center gap-2">
                  <span className="text-base">⚡</span>
                  <span>Anéis de Neon Verde fluorescente brilhante</span>
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  onClick={() => {
                    setShowSkinImageModal(false);
                    onOpenSkins();
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
                >
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  Abrir Galeria de Skins
                </button>
                <button
                  onClick={() => setShowSkinImageModal(false)}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-600/30 transition-colors"
                >
                  Confirmar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
