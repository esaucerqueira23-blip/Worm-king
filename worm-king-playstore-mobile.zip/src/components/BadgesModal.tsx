import React from 'react';
import { PlayerBadge, PlayerLevelInfo } from '../types';
import { PLAYER_BADGES, saveEquippedBadge } from '../game/playerLevel';
import { X, Award, CheckCircle2, Lock, Sparkles, Flame, Crosshair, Trophy } from 'lucide-react';
import { sounds } from '../audio/soundEffects';

interface BadgesModalProps {
  isOpen: boolean;
  onClose: () => void;
  levelInfo: PlayerLevelInfo;
  equippedBadgeId: string;
  onSelectBadge: (badgeId: string) => void;
  lang: 'pt' | 'en';
}

export const BadgesModal: React.FC<BadgesModalProps> = ({
  isOpen,
  onClose,
  levelInfo,
  equippedBadgeId,
  onSelectBadge,
  lang,
}) => {
  if (!isOpen) return null;

  const handleEquip = (badge: PlayerBadge) => {
    if (levelInfo.level < badge.unlockLevel) return;
    onSelectBadge(badge.id);
    saveEquippedBadge(badge.id);
    sounds.playEatOrb(3);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl shadow-black/80 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 text-xl shadow-lg shadow-amber-500/20">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                <span>{lang === 'pt' ? 'Insígnias & Nível de Jogador' : 'Player Badges & Level'}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono font-bold border border-amber-500/40">
                  XP
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {lang === 'pt'
                  ? 'Evolua eliminando cobras e vença partidas para ostentar insígnias raras!'
                  : 'Level up by eliminating enemies and winning matches to unlock rare badges!'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            id="close-badges-modal-btn"
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Level Hero Card */}
        <div className="p-4 sm:p-5 bg-gradient-to-b from-slate-800/60 to-slate-900/60 border-b border-slate-800">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl border-2 shadow-xl"
                style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.9)',
                  borderColor: levelInfo.badge.color,
                  boxShadow: `0 0 20px ${levelInfo.badge.bgGlow}`,
                }}
              >
                {levelInfo.badge.icon}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-black px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                    NÍVEL {levelInfo.level}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    {levelInfo.totalXp.toLocaleString()} Total XP
                  </span>
                </div>
                <div className="text-base sm:text-lg font-black text-white mt-0.5">
                  {lang === 'pt' ? levelInfo.titlePt : levelInfo.titleEn}
                </div>
              </div>
            </div>

            {/* XP Bar to Next Level */}
            <div className="w-full sm:w-64 flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">{lang === 'pt' ? 'Próximo Nível' : 'Next Level'}</span>
                <span className="text-amber-300 font-bold">
                  {levelInfo.currentLevelXp.toLocaleString()} / {levelInfo.nextLevelXp.toLocaleString()} XP
                </span>
              </div>
              <div className="w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-700/60 p-0.5">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 via-orange-400 to-yellow-300 transition-all duration-500 shadow-sm shadow-amber-500"
                  style={{ width: `${levelInfo.levelProgressPct}%` }}
                />
              </div>
              <div className="text-right text-[10px] text-slate-400 font-mono">
                {levelInfo.levelProgressPct}% {lang === 'pt' ? 'concluído' : 'completed'}
              </div>
            </div>
          </div>

          {/* XP Rewards Quick Guide */}
          <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <div className="text-amber-400 font-mono font-black">+150 XP</div>
              <div className="text-[10px] text-slate-400">{lang === 'pt' ? 'Abate Normal' : 'Enemy Kill'}</div>
            </div>
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <div className="text-rose-400 font-mono font-black">+350 XP</div>
              <div className="text-[10px] text-slate-400">{lang === 'pt' ? 'Headshot' : 'Headshot Kill'}</div>
            </div>
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <div className="text-purple-400 font-mono font-black">+500 XP</div>
              <div className="text-[10px] text-slate-400">{lang === 'pt' ? 'Cabeçada Clash' : 'Head Clash Win'}</div>
            </div>
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <div className="text-emerald-400 font-mono font-black">+1000 XP</div>
              <div className="text-[10px] text-slate-400">{lang === 'pt' ? 'Vitória Royale' : 'Match Victory'}</div>
            </div>
          </div>
        </div>

        {/* Badges List */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 flex flex-col gap-3">
          <div className="text-xs font-black uppercase tracking-wider text-slate-400">
            {lang === 'pt' ? 'Galeria de Insígnias' : 'Badges Showcase'}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {PLAYER_BADGES.map((badge) => {
              const isUnlocked = levelInfo.level >= badge.unlockLevel;
              const isEquipped = equippedBadgeId === badge.id;

              return (
                <div
                  key={badge.id}
                  className={`relative p-3.5 rounded-2xl border transition-all flex items-start gap-3.5 ${
                    isEquipped
                      ? 'bg-slate-800/90 border-amber-400 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400/50'
                      : isUnlocked
                      ? 'bg-slate-800/50 hover:bg-slate-800/80 border-slate-700/80'
                      : 'bg-slate-950/50 border-slate-800 opacity-60'
                  }`}
                >
                  {/* Badge Icon */}
                  <div
                    className="w-12 h-12 rounded-xl flex-shrink-0 flex items-center justify-center text-2xl border transition-transform"
                    style={{
                      backgroundColor: 'rgba(15, 23, 42, 0.9)',
                      borderColor: isUnlocked ? badge.color : '#334155',
                      boxShadow: isUnlocked ? `0 0 14px ${badge.bgGlow}` : 'none',
                    }}
                  >
                    {isUnlocked ? badge.icon : <Lock className="w-5 h-5 text-slate-500" />}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-xs font-black text-white truncate">
                        {lang === 'pt' ? badge.namePt : badge.nameEn}
                      </span>
                      <span
                        className="text-[9px] uppercase font-mono px-1.5 py-0.2 rounded font-extrabold"
                        style={{
                          backgroundColor: `${badge.color}25`,
                          color: badge.color,
                          border: `1px solid ${badge.color}50`,
                        }}
                      >
                        Nív. {badge.unlockLevel}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                      {lang === 'pt' ? badge.descriptionPt : badge.descriptionEn}
                    </p>

                    {/* Action button */}
                    <div className="mt-2.5 flex items-center justify-between">
                      {isUnlocked ? (
                        isEquipped ? (
                          <span className="text-[10px] font-bold text-amber-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                            {lang === 'pt' ? 'EQUIPADO' : 'EQUIPPED'}
                          </span>
                        ) : (
                          <button
                            onClick={() => handleEquip(badge)}
                            id={`equip-badge-${badge.id}-btn`}
                            className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[10px] font-bold transition-colors cursor-pointer"
                          >
                            {lang === 'pt' ? 'Equipar' : 'Equip'}
                          </button>
                        )
                      ) : (
                        <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          {lang === 'pt' ? `Libera no Nível ${badge.unlockLevel}` : `Unlocks at Level ${badge.unlockLevel}`}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {lang === 'pt'
                ? 'Insígnias equipadas aparecem ao lado do seu apelido na arena!'
                : 'Equipped badges appear next to your nickname in the arena!'}
            </span>
          </div>
          <button
            onClick={onClose}
            id="badges-modal-close-action-btn"
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
          >
            {lang === 'pt' ? 'Fechar' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
