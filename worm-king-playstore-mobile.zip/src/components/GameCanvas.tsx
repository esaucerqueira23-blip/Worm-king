import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from '../game/gameEngine';
import { GameRenderer } from '../game/renderer';
import { Worm, LeaderboardEntry, BattleRoyaleZone, GameMode } from '../types';
import { SensitivityLevel, SENSITIVITY_MULTIPLIERS } from '../game/constants';
import { HUD } from './HUD';

interface GameCanvasProps {
  engine: GameEngine;
  onGameOver: (stats: any) => void;
  lang: 'pt' | 'en';
  isMuted: boolean;
  onToggleMute: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  engine,
  onGameOver,
  lang,
  isMuted,
  onToggleMute,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rendererRef = useRef<GameRenderer | null>(null);

  // Live HUD states refreshed each frame or throttled
  const [playerState, setPlayerState] = useState<Worm | null>(engine.player);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [allWorms, setAllWorms] = useState<Worm[]>([]);
  const [brZone, setBrZone] = useState<BattleRoyaleZone | null>(null);

  // Input states
  const pointerAngleRef = useRef<number>(0);
  const isBoostingRef = useRef<boolean>(false);
  const [isBoosting, setIsBoosting] = useState<boolean>(false);

  // Curvinha and Speed Tiers (x2, x5, x10)
  const isCurvinhaRef = useRef<boolean>(false);
  const [isCurvinha, setIsCurvinha] = useState<boolean>(false);
  const speedTierRef = useRef<2 | 5 | 10>(2);
  const [speedTier, setSpeedTier] = useState<2 | 5 | 10>(2);

  // Sensitivity State (Alta 1.5x default for instantaneous responsiveness)
  const [sensitivity, setSensitivity] = useState<SensitivityLevel>('high');
  const sensitivityRef = useRef<SensitivityLevel>('high');

  const handleSensitivityChange = useCallback((level: SensitivityLevel) => {
    setSensitivity(level);
    sensitivityRef.current = level;
  }, []);

  const handleBoostChange = useCallback((boosting: boolean) => {
    isBoostingRef.current = boosting;
    setIsBoosting(boosting);
  }, []);

  const handleToggleCurvinha = useCallback(() => {
    setIsCurvinha((prev) => {
      const next = !prev;
      isCurvinhaRef.current = next;
      return next;
    });
  }, []);

  const handleSelectSpeedTier = useCallback((tier: 2 | 5 | 10) => {
    setSpeedTier(tier);
    speedTierRef.current = tier;
  }, []);

  const handleFirePlasma = useCallback(() => {
    if (engine.player) {
      engine.firePlasma(engine.player);
    }
  }, [engine]);

  // Set up game over callback
  useEffect(() => {
    engine.setGameOverCallback(onGameOver);
  }, [engine, onGameOver]);

  // Track active directional keys (WASD / Arrows)
  const activeKeysRef = useRef<Set<string>>(new Set());

  // Keyboard controls (WASD/Arrows for steering, Space/Shift for boost, C for Curvinha, 1/2/3 for Speed, F/E for plasma)
  useEffect(() => {
    const updateAngleFromKeys = () => {
      const keys = activeKeysRef.current;
      let dx = 0;
      let dy = 0;

      if (keys.has('KeyA') || keys.has('ArrowLeft')) dx -= 1;
      if (keys.has('KeyD') || keys.has('ArrowRight')) dx += 1;
      if (keys.has('KeyW') || keys.has('ArrowUp')) dy -= 1;
      if (keys.has('KeyS') || keys.has('ArrowDown')) dy += 1;

      if (dx !== 0 || dy !== 0) {
        pointerAngleRef.current = Math.atan2(dy, dx);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Acceleration Boost keys: Space, ShiftLeft, ShiftRight
      if (e.code === 'Space' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        e.preventDefault();
        handleBoostChange(true);
      } else if (e.code === 'KeyF' || e.code === 'KeyE') {
        e.preventDefault();
        handleFirePlasma();
      } else if (e.code === 'KeyC' || e.code === 'KeyQ') {
        e.preventDefault();
        handleToggleCurvinha();
      } else if (e.code === 'Digit1') {
        e.preventDefault();
        handleSelectSpeedTier(2);
      } else if (e.code === 'Digit2') {
        e.preventDefault();
        handleSelectSpeedTier(5);
      } else if (e.code === 'Digit3') {
        e.preventDefault();
        handleSelectSpeedTier(10);
      }

      // Directional keys
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        activeKeysRef.current.add(e.code);
        updateAngleFromKeys();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
        e.preventDefault();
        handleBoostChange(false);
      }

      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
        activeKeysRef.current.delete(e.code);
        updateAngleFromKeys();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleBoostChange, handleFirePlasma, handleToggleCurvinha, handleSelectSpeedTier]);

  // Handle touch joystick steering
  const handleJoystickMove = useCallback((angle: number) => {
    pointerAngleRef.current = angle;
  }, []);

  const handleJoystickEnd = useCallback(() => {
    // Keep angle, no-op
  }, []);

  // Canvas resize and render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    const renderer = new GameRenderer(ctx);
    rendererRef.current = renderer;

    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
      renderer.setDimensions(width, height);
    };

    handleResize();
    window.addEventListener('resize', handleResize);

    // Mouse / Pointer Move
    const handlePointerMove = (e: PointerEvent) => {
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      const dx = e.clientX - centerX;
      const dy = e.clientY - centerY;
      pointerAngleRef.current = Math.atan2(dy, dx);
    };

    const handlePointerDown = (e: PointerEvent) => {
      if (e.button === 0) {
        // Left click can boost or start tracking
        handleBoostChange(true);
      } else if (e.button === 2) {
        // Right click fires plasma
        e.preventDefault();
        handleFirePlasma();
      }
    };

    const handlePointerUp = (e: PointerEvent) => {
      if (e.button === 0) {
        handleBoostChange(false);
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    // Touch events for immediate and smooth steering on touchscreens
    const updatePointerFromTouch = (touch: Touch) => {
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      const dx = touch.clientX - centerX;
      const dy = touch.clientY - centerY;
      pointerAngleRef.current = Math.atan2(dy, dx);
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        updatePointerFromTouch(e.touches[0]);
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        updatePointerFromTouch(e.touches[0]);
      }
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchmove', handleTouchMove, { passive: true });

    let animationFrameId: number;
    let lastHudUpdate = 0;

    const loop = (timestamp: number) => {
      if (engine.isRunning) {
        // 1. Update Game Engine with curvinha, speed tier and sensitivity multiplier
        engine.update(
          pointerAngleRef.current,
          isBoostingRef.current,
          isCurvinhaRef.current,
          speedTierRef.current,
          SENSITIVITY_MULTIPLIERS[sensitivityRef.current]
        );

        // 2. Update Camera Tracking Player (with dynamic speed zoom)
        if (engine.player && !engine.player.isDead) {
          const activeSpeedMult =
            engine.player.speedMultiplier ||
            (engine.player.activePowerUps.speed_x10 > 0 ? 10 : speedTierRef.current);
          renderer.updateCamera(
            engine.player.x,
            engine.player.y,
            engine.player.mass,
            activeSpeedMult
          );
        }

        // 3. Render Canvas
        renderer.render(
          engine.player,
          engine.worms,
          engine.orbs,
          engine.powerUps,
          engine.projectiles,
          engine.particles,
          engine.floatingTexts,
          engine.brZone,
          engine.gameMode,
          engine.screenShake
        );

        // 4. Update HUD state throttled to ~15fps to reduce React render overhead
        if (timestamp - lastHudUpdate > 65) {
          lastHudUpdate = timestamp;
          setPlayerState(engine.player ? { ...engine.player } : null);
          setLeaderboard(engine.getLeaderboard());
          setAllWorms([...engine.worms]);
          setBrZone(engine.brZone ? { ...engine.brZone } : null);
        }
      }

      animationFrameId = requestAnimationFrame(loop);
    };

    animationFrameId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchmove', handleTouchMove);
    };
  }, [engine, handleBoostChange, handleFirePlasma]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none">
      <canvas
        ref={canvasRef}
        id="worm-canvas"
        className="absolute inset-0 block w-full h-full cursor-crosshair touch-none"
      />

      <HUD
        player={playerState}
        leaderboard={leaderboard}
        allWorms={allWorms}
        brZone={brZone}
        gameMode={engine.gameMode}
        lang={lang}
        isMuted={isMuted}
        onToggleMute={onToggleMute}
        onFirePlasma={handleFirePlasma}
        isBoosting={isBoosting}
        onBoostChange={handleBoostChange}
        isCurvinha={isCurvinha}
        onToggleCurvinha={handleToggleCurvinha}
        speedTier={speedTier}
        onSelectSpeedTier={handleSelectSpeedTier}
        sensitivity={sensitivity}
        onChangeSensitivity={handleSensitivityChange}
        onJoystickMove={handleJoystickMove}
        onJoystickEnd={handleJoystickEnd}
        engine={engine}
      />
    </div>
  );
};
