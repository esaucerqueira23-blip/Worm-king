export type GameMode = 'ffa' | 'battle_royale' | 'headshot_rush';

export type PowerUpType = 'magnet' | 'curvinha' | 'multiplier' | 'plasma' | 'speed_x10';

export interface PowerUp {
  id: string;
  type: PowerUpType;
  x: number;
  y: number;
  radius: number;
  pulse: number;
  duration: number; // effect duration in seconds
}

export interface ActivePowerUp {
  type: PowerUpType;
  remainingTime: number;
  totalTime: number;
}

export interface Orb {
  id: number;
  x: number;
  y: number;
  radius: number;
  color: string;
  value: number;
  glowColor: string;
  vx?: number;
  vy?: number;
  foodType?:
    | 'candy'
    | 'donut'
    | 'cupcake'
    | 'burger'
    | 'apple'
    | 'pizza'
    | 'star'
    | 'watermelon'
    | 'strawberry'
    | 'lollipop'
    | 'icecream'
    | 'cookie'
    | 'cherry'
    | 'cake'
    | 'croissant';
}

export interface WormSegment {
  x: number;
  y: number;
  radius: number;
}

export interface WormSkin {
  id: string;
  name: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  pattern: 'stripes' | 'rings' | 'scales' | 'cyber' | 'galaxy' | 'lava' | 'gold' | 'patriota' | 'custom_image';
  accessory?: 'crown' | 'visor' | 'horns' | 'halo' | 'bandana' | 'owl_mask';
  isUnlocked: boolean;
  cost: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  previewImageUrl?: string;
  customImageUrl?: string;
  customImageApplyMode?: 'head_and_body' | 'head_only' | 'body_only';
  customImageFit?: 'cover' | 'contain';
  customImageScale?: number;
  customImageRotation?: number;
  customImageOffsetX?: number;
  customImageOffsetY?: number;
  showEyes?: boolean;
}

export interface Worm {
  id: string;
  name: string;
  isPlayer: boolean;
  skin: WormSkin;
  segments: WormSegment[];
  x: number;
  y: number;
  angle: number;
  targetAngle: number;
  speed: number;
  baseSpeed: number;
  boostSpeed: number;
  isBoosting: boolean;
  isCurvinha?: boolean;
  speedMultiplier?: number;
  length: number;
  mass: number;
  score: number;
  kills: number;
  headshots: number;
  isDead: boolean;
  deadAlpha?: number;
  activePowerUps: Record<PowerUpType, number>; // remaining seconds
  // Bot AI state
  targetOrbId?: number;
  targetWormId?: string;
  aiAggressiveness?: number;
  aiTurnTimer?: number;
  aiBoostTimer?: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  alpha: number;
  decay: number;
  sparkle?: boolean;
  type?: 'smoke' | 'sparkle' | 'star' | 'pop';
  rotation?: number;
  scale?: number;
}

export interface FloatingText {
  id: string;
  text: string;
  x: number;
  y: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  scale: number;
  isHeadshot?: boolean;
}

export interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  ownerId: string;
  color: string;
  life: number;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  score: number;
  length: number;
  kills: number;
  isPlayer: boolean;
  skinColor: string;
}

export interface GameStats {
  gamesPlayed: number;
  highestScore: number;
  highestLength: number;
  totalKills: number;
  totalHeadshots: number;
  coins: number;
  battleRoyaleWins: number;
  xp?: number;
  activeBadgeId?: string;
}

export interface PlayerBadge {
  id: string;
  namePt: string;
  nameEn: string;
  descriptionPt: string;
  descriptionEn: string;
  icon: string;
  unlockLevel: number;
  tier: 'bronze' | 'silver' | 'gold' | 'emerald' | 'ruby' | 'amethyst' | 'legend';
  color: string;
  bgGlow: string;
}

export interface PlayerLevelInfo {
  level: number;
  titlePt: string;
  titleEn: string;
  currentLevelXp: number;
  nextLevelXp: number;
  levelProgressPct: number;
  percent: number;
  totalXp: number;
  badge: PlayerBadge;
}

export interface BattleRoyaleZone {
  centerX: number;
  centerY: number;
  radius: number;
  targetRadius: number;
  shrinkSpeed: number;
  damageRate: number;
  phase: number;
  timer: number;
}

export interface GameOverData {
  score: number;
  length: number;
  kills: number;
  headshots: number;
  rank: number;
  coinsEarned: number;
  isVictory: boolean;
  deathReason?: 'head_clash_center' | 'body_collision' | 'border_collision' | 'storm';
  xpEarned?: number;
}
