import React, { useState, useEffect, useMemo } from 'react';
import { GameMode, WormSkin } from './types';
import { SKINS } from './game/constants';
import { GameEngine } from './game/gameEngine';
import { MainMenu } from './components/MainMenu';
import { GameCanvas } from './components/GameCanvas';
import { SkinSelectorModal } from './components/SkinSelectorModal';
import { GameOverModal } from './components/GameOverModal';
import { DailyMissionsModal } from './components/DailyMissionsModal';
import { BadgesModal } from './components/BadgesModal';
import { calculateLevelInfo, getEquippedBadgeId } from './game/playerLevel';
import { sounds } from './audio/soundEffects';
import { App as CapacitorApp } from '@capacitor/app';

type AppScreen = 'menu' | 'playing' | 'game_over';

export default function App() {
  const engine = useMemo(() => new GameEngine(), []);

  const [screen, setScreen] = useState<AppScreen>('menu');
  const [coins, setCoins] = useState<number>(() => engine.stats.coins);
  const [nickname, setNickname] = useState<string>(() => {
    return localStorage.getItem('wormking_nickname') || localStorage.getItem('wormzilla_nickname') || 'WormKing';
  });

  const [skins, setSkins] = useState<WormSkin[]>(() => {
    try {
      const savedUnlocked = localStorage.getItem('wormking_unlocked_skins') || localStorage.getItem('wormzilla_unlocked_skins');
      let list = [...SKINS];
      const customData = localStorage.getItem('wormking_custom_skin_data');
      if (customData) {
        try {
          const parsedCustom: WormSkin = JSON.parse(customData);
          list = [parsedCustom, ...list];
        } catch {
          // ignore
        }
      }
      if (savedUnlocked) {
        const unlockedIds: string[] = JSON.parse(savedUnlocked);
        return list.map((s) => ({
          ...s,
          isUnlocked: s.isUnlocked || unlockedIds.includes(s.id),
        }));
      }
      return list;
    } catch {
      // ignore
    }
    return SKINS;
  });

  const [selectedSkin, setSelectedSkin] = useState<WormSkin>(() => {
    try {
      const savedSkinId = localStorage.getItem('wormking_selected_skin') || localStorage.getItem('wormzilla_selected_skin');
      if (savedSkinId?.startsWith('custom')) {
        const customData = localStorage.getItem('wormking_custom_skin_data');
        if (customData) {
          return JSON.parse(customData);
        }
      }
      if (savedSkinId) {
        const found = SKINS.find((s) => s.id === savedSkinId);
        if (found) return found;
      }
    } catch {
      // ignore
    }
    return SKINS[0];
  });

  const [selectedMode, setSelectedMode] = useState<GameMode>('ffa');
  const [showSkinModal, setShowSkinModal] = useState<boolean>(false);
  const [showMissionsModal, setShowMissionsModal] = useState<boolean>(false);
  const [showBadgesModal, setShowBadgesModal] = useState<boolean>(false);
  const [equippedBadgeId, setEquippedBadgeId] = useState<string>(() => engine.stats.activeBadgeId || getEquippedBadgeId());
  const [lang, setLang] = useState<'pt' | 'en'>('pt');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(false);

  const [gameOverStats, setGameOverStats] = useState<{
    score: number;
    length: number;
    kills: number;
    headshots: number;
    rank: number;
    coinsEarned: number;
    isVictory: boolean;
    deathReason?: 'head_clash_center' | 'body_collision' | 'border_collision' | 'storm';
  } | null>(null);

  // Android system back button: return to menu instead of closing the game immediately.
  useEffect(() => {
    let listener: { remove: () => Promise<void> } | null = null;
    CapacitorApp.addListener('backButton', ({ canGoBack }) => {
      if (screen === 'playing' || screen === 'game_over') {
        setScreen('menu');
      } else if (canGoBack) {
        window.history.back();
      }
    }).then((handle) => { listener = handle; });
    return () => { listener?.remove(); };
  }, [screen]);

  // Sync nickname to localStorage
  useEffect(() => {
    localStorage.setItem('wormking_nickname', nickname);
  }, [nickname]);

  // Sync skin to localStorage
  const handleSelectSkin = (skin: WormSkin) => {
    setSelectedSkin(skin);
    localStorage.setItem('wormking_selected_skin', skin.id);
    if (skin.id.startsWith('custom') || skin.customImageUrl) {
      localStorage.setItem('wormking_custom_skin_data', JSON.stringify(skin));
      setSkins((prev) => {
        const filtered = prev.filter((s) => s.id !== skin.id);
        return [skin, ...filtered];
      });
    }
  };

  // Coins awarded from missions or events
  const handleCoinsAwarded = (amount: number) => {
    engine.stats.coins += amount;
    engine.saveStats();
    setCoins(engine.stats.coins);
  };

  // Unlock skin using coins
  const handleUnlockSkin = (skinId: string, cost: number): boolean => {
    if (engine.stats.coins >= cost) {
      engine.stats.coins -= cost;
      engine.saveStats();
      setCoins(engine.stats.coins);

      setSkins((prev) => {
        const updated = prev.map((s) => (s.id === skinId ? { ...s, isUnlocked: true } : s));
        const unlockedIds = updated.filter((s) => s.isUnlocked).map((s) => s.id);
        localStorage.setItem('wormking_unlocked_skins', JSON.stringify(unlockedIds));
        return updated;
      });

      return true;
    }
    return false;
  };

  const handleStartGame = () => {
    sounds.playPowerUp();
    engine.startNewGame(nickname, selectedSkin, selectedMode);
    setScreen('playing');
  };

  const handleGameOver = (stats: any) => {
    setGameOverStats(stats);
    setCoins(engine.stats.coins);
    setScreen('game_over');
  };

  const handlePlayAgain = () => {
    sounds.playEatOrb(2);
    engine.startNewGame(nickname, selectedSkin, selectedMode);
    setScreen('playing');
  };

  const handleMainMenu = () => {
    setCoins(engine.stats.coins);
    setScreen('menu');
  };

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sounds.setMuted(next);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans">
      {screen === 'menu' && (
        <MainMenu
          nickname={nickname}
          setNickname={setNickname}
          selectedMode={selectedMode}
          setSelectedMode={setSelectedMode}
          selectedSkin={selectedSkin}
          onOpenSkins={() => setShowSkinModal(true)}
          onStartGame={handleStartGame}
          stats={engine.stats}
          lang={lang}
          setLang={setLang}
          isMuted={isMuted}
          setIsMuted={setIsMuted}
          musicEnabled={musicEnabled}
          setMusicEnabled={setMusicEnabled}
          onOpenDailyMissions={() => setShowMissionsModal(true)}
          onOpenBadges={() => setShowBadgesModal(true)}
        />
      )}

      {(screen === 'playing' || screen === 'game_over') && (
        <GameCanvas
          engine={engine}
          onGameOver={handleGameOver}
          lang={lang}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {screen === 'game_over' && gameOverStats && (
        <GameOverModal
          stats={gameOverStats}
          highScore={engine.stats.highestScore}
          nickname={nickname}
          setNickname={setNickname}
          onPlayAgain={handlePlayAgain}
          onMainMenu={handleMainMenu}
          onOpenSkins={() => setShowSkinModal(true)}
          lang={lang}
          onOpenDailyMissions={() => setShowMissionsModal(true)}
          onCoinsAwarded={handleCoinsAwarded}
        />
      )}

      {showSkinModal && (
        <SkinSelectorModal
          currentSkin={selectedSkin}
          coins={coins}
          onSelectSkin={handleSelectSkin}
          onUnlockSkin={handleUnlockSkin}
          onClose={() => setShowSkinModal(false)}
          lang={lang}
        />
      )}

      {showMissionsModal && (
        <DailyMissionsModal
          isOpen={showMissionsModal}
          onClose={() => {
            setShowMissionsModal(false);
            setCoins(engine.stats.coins);
          }}
          onCoinsAwarded={handleCoinsAwarded}
          lang={lang}
        />
      )}

      {showBadgesModal && (
        <BadgesModal
          isOpen={showBadgesModal}
          onClose={() => setShowBadgesModal(false)}
          levelInfo={calculateLevelInfo(engine.stats.xp ?? 0)}
          equippedBadgeId={equippedBadgeId}
          onSelectBadge={(badgeId) => {
            setEquippedBadgeId(badgeId);
            engine.stats.activeBadgeId = badgeId;
            engine.saveStats();
          }}
          lang={lang}
        />
      )}
    </div>
  );
}
