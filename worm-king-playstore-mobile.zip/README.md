# Worm King

Jogo web React/TypeScript preparado para distribuição como aplicativo Android usando Capacitor.

## Desenvolvimento web

```bash
npm install
npm run dev
```

## Android / Google Play

Consulte `PLAY_STORE.md` para o procedimento de empacotamento, assinatura e publicação.

Package ID: `com.wormking.game`
